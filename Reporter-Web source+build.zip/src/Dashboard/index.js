import React, { Component } from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import { PageLoader } from "../PageLoader";
import moment from "moment";
import HeaderDashboard from "./App/HeaderDashboard";
import StatusBar from "./App/StatusBar";
import { toast } from "react-toastify";
import { UserInfo } from "./App/UserInfo";
import Pagination from "../Helpers/pagination";
import ReactTooltip from 'react-tooltip';
import "./admin.css";

const GET_USER_ARTICLES = gql`
query UserPostedArticleByStatus($token: String!) {
  getDashboardArticles(token: $token, sortby: "desc", orderby: "createdDate") {
    articletitle
    articledescription
    id
    modifiedAt
    article {
      id
      isLocked
       lockedBy {
        username
      }
      articleType
      articlestatusSet {
        globalStatus
        publisherstatus
        editorstatus
      }
      user {
        email
        isVerifiedByAdmin
        firstName
        profilephoto
        groups {
          name
        }
        username
      }
    }
    category {
      categoryname
    }
    subcategory {
      subcategoryname
    }
    attachmentsSet {
      path
      isFeaturedImage
    }
  }
}

`;

var userVerified = UserInfo().verified;
var userEmail = UserInfo().email;
var isReporter = true;
if (UserInfo().group != "Reporter") {
  isReporter = false;
}

var articleList = [];
var totalRecords;

if (userVerified === "false") {
  toast.info(
    "Your account has not yet been activated. Please contact the site admin"
  );
}

class Dashbaord extends Component {
  constructor() {
    super();
  }

  render() {
    return (
      <Query
        query={GET_USER_ARTICLES}
        variables={{ token: window.localStorage.getItem("token") }}
        pollInterval={1000000000000}
      >
        {({ loading, error, data }) => {
          if (loading) return <PageLoader />;
          if (!data.getDashboardArticles.length) {
            return (
              <div className="container-fluid no-padding">
                <div className="row no-margin">
                  <HeaderDashboard />

                  <div className="main-content" id="tglmcdisplay">
                    <StatusBar />
                    <span className="page-header">
                      <span className="article-header">Dashboard</span>
                      <span className="ca-link">
                        <a href="/add/article">Create Article</a>
                      </span>
                    </span>
                    <div className="row no-margin" id="main">
                      <div className="col-sm-12 col-md-12 well" id="content">
                        <div className="container-fluid">
                          <div className="row no-margin">
                            <div classname="col-md-12">
                              No Aticles to display
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          }

          totalRecords = data.getDashboardArticles.length;

          return <DashbaordArticles articlelist={data.getDashboardArticles} />;
        }}
      </Query>
    );
  }
}

const StatusIcon = ({ status }) => {
  if (status === "DRAFT") {
    return (
      <span className="article-status-badge status-draft">
        <span className="badge">D</span>
      </span>
    );
  } else if (status === "REWORK") {
    return (
      <span className="article-status-badge status-rework">
        <span className="badge">R</span>
      </span>
    );
  } else if (status === "PENDING") {
    return (
      <span className="article-status-badge status-pending">
        <span className="badge">P</span>
      </span>
    );
  } else if (status === "REJECTED") {
    return (
      <span className="article-status-badge status-rejected">
        <span className="badge">R</span>
      </span>
    );
  } else {
    return (
      <span className="article-status-badge status-published">
        <span className="badge">P</span>
      </span>
    );
  }
};

const AttachmentIcon = ({ data }) => {
  if (data.length > 0) {
    data = data.filter(function(value, index, arr) {
      return value.isFeaturedImage === false;
    });

    return (
      <span className="attachmentStatus">
        <i className="fas fa-paperclip"></i>
      </span>
    );
  } else {
    return null;
  }
};

class DashbaordArticles extends Component {
  constructor(props) {
    super(props);

    this.state = {
      currentData: (articleList = this.props.articlelist)
    };
  }

  componentDidMount() {
    this.setState({ currentData: articleList });
  }

  onPageChange = data => {
    const { currentPage, totalPages, pageLimit } = data;

    const offset = (currentPage - 1) * pageLimit;

    const currentList = articleList.slice(offset, offset + pageLimit);

    this.setState({ currentData: currentList });
  };

  render() {
    var currentData = this.state;

    console.log(currentData);

    return (
      <div className="container-fluid no-padding">
        <div className="row no-margin">
          <HeaderDashboard />

          <div className="main-content" id="tglmcdisplay">
            <StatusBar />
            <span className="page-header">
              <span className="article-header">Dashboard</span>
              <span className="ca-link">
                <a href="/add/article">Create Article</a>
              </span>
            </span>
            <div className="row no-margin" id="main">
              <div className="col-sm-12 col-md-12 well" id="content">
                <div className="container-fluid">
                  <div className="row no-margin">
                    {currentData.currentData.map((article, index) => (
                      <div className="col-md-4 article-card" key={index}>
                        <div className="card-body no-padding">
                          <div className="col-md-12 card-details plr15">
                            <div className="d-flex dash-articles-header">
                              {!isReporter && (
                                <div className="col-md-2 no-padding">
                                  <span className="pro-img">
                                    <img
                                      src={
                                        "https://i.pravatar.cc/150?u=" +
                                        article.article.user.firstName
                                      }
                                      alt={article.article.user.firstName}
                                    />
                                  </span>
                                </div>
                              )}
                              <div className="col no-padding">
                                <span className="article-date-user">
                                  <p>
                                    <span>
                                      {moment(article.modifiedAt).format(
                                        "DD/MM/YYYY"
                                      )}
                                    </span>

                                    <span className="article-category">
                                      {article.category.categoryname}
                                    </span>

                                    <AttachmentIcon
                                      data={article.attachmentsSet}
                                    />

                                    {article.article.user.isVerifiedByAdmin && (
                                      <span className="userStatus verified">
                                        <i
                                          className="fas fa-user-check"
                                          title="Verified Author"
                                        ></i>
                                      </span>
                                    )}
                                    {article.article.isLocked && (
                                      <span className="article-locked">
                                        <i
                                          className="fas fa-lock"
                                          data-tip={"The article is being edited by "+article.article.lockedBy.username}
                                        ></i>
                                      </span>
                                    )}
                                  </p>
                                  {!isReporter && (
                                    <p>
                                      <strong>{article.article.user.username}</strong>,{" "}
                                      {article.article.user.groups[0].name}
                                    </p>
                                  )}
                                </span>
                              </div>
                              <div className="col-md-1 no-padding">
                                <p className="p-t-5">
                                  <StatusIcon
                                    status={
                                      article.article.articlestatusSet[0].globalStatus
                                    }
                                  />
                                </p>
                              </div>
                            </div>
                          </div>
                          <div className="article-details plr15">
                            <h6 className="card-title">
                              {article.articletitle}
                            </h6>

                            <p
                              className="text__limit"
                              dangerouslySetInnerHTML={{
                                __html: article.articledescription
                              }}
                            />
                          </div>
                          <span className="edit-view-controller">
                            <span className="article-type">
                              {article.article.articleType.toLowerCase()}
                            </span>
                            {(() => {
                              let status =
                                article.article.articlestatusSet[0].globalStatus;

                              let estatus =
                                article.article.articlestatusSet[0].editorstatus;

                              let pstatus =
                                article.article.articlestatusSet[0].publisherstatus;

                              let lockStatus = article.article.isLocked;

                              let userRole = UserInfo().group;
                              let ownArticle = false;
                              if (userEmail === article.article.user.email) {
                                ownArticle = true;
                              }

                              if (lockStatus && !ownArticle) {
                                return null;
                              }


                              if (
                                isReporter &&
                                (status === "PENDING" ||
                                  status === "REJECTED" ||
                                  status === "PUBLISHED")
                              ) {
                                return null;
                              } else if (
                                userRole === "Content Editor" &&
                                ((ownArticle &&
                                  (status === "PENDING" ||
                                    status === "REJECTED" ||
                                    status === "PUBLISHED")) ||
                                  (!ownArticle &&
                                    (status === "REJECTED" ||
                                      status === "PUBLISHED" 
                                     )))
                              ) {
                                if (estatus==='REWORK'){
                                  return (
                                  <span>
                                    <Link
                                      to={`/edit/${article.article.articleType.toLowerCase()}/${
                                        article.article.id
                                      }`}
                                      className=""
                                    >
                                      Edit
                                    </Link>{" "}
                                    /{" "}
                                  </span>
                                );
                                }
                                return null;

                                
                              } else if (
                                userRole === "Publisher" &&
                                ((ownArticle &&
                                  (status === "PENDING" ||
                                    status === "REJECTED" ||
                                    status === "PUBLISHED")) ||
                                  (!ownArticle && status === "REWORK"))
                              ) {
                                return null;
                              } else {
                                return (
                                  <span>
                                    <Link
                                      to={`/edit/${article.article.articleType.toLowerCase()}/${
                                        article.article.id
                                      }`}
                                      className=""
                                    >
                                      Edit
                                    </Link>{" "}
                                    /{" "}
                                  </span>
                                );
                              }
                            })()}
                            <Link to={`/view/${article.article.id}`} className="">
                              View
                            </Link>
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="row no-margin">
                    <div className="col-md-12">
                      <Pagination
                        totalRecords={totalRecords}
                        pageLimit={18}
                        pageNeighbours={1}
                        onPageChanged={this.onPageChange}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <ReactTooltip />
      </div>
    );
  }
}

export default Dashbaord;
