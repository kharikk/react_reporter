import React from 'react';
import spinnerImg from  './spinner.gif'


export const Spinner = () => (

    <img src={spinnerImg} alt="Spinner"/>
 
)