

import React from 'react';
import gql from 'graphql-tag';
import { extendObservable } from 'mobx'
import { Query, graphql, Mutation } from 'react-apollo';
// import  { Loader } from '../../Loader';
import { observer } from 'mobx-react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import { Redirect } from 'react-router-dom';



const REVOKE = gql`
mutation Logout($token:String!){
    revokeToken(refreshToken:$token){
     revoked
   }
   }
`;

// export default class Logout extends React.Component {
//   constructor(props) {
//     super(props);
//   }

//   onSubmit = async () => {
   

//     try {
//       const response = await this.props.mutate({
//         variables: { token:window.localStorage.getItem('token') },
//       });
//       console.log(response);
//       const { ok, token } = response.data.tokenAuth.token;
//       if (response.data) {
//         localStorage.clear()
//         window.location.href = "/login";
        
//       }
//     } catch (error) {
//       alert("Please entet valid credentails");
//     }



//   };
 
// onChange = e => {
//   const { name, value } = e.target;
//   this[name] = value;
// };




// render() {

//   //const {  } = this.state;
//   // const { editorState } = this.state;
 
//   return (

    


//   );
// }
// }



// Logout = graphql(LogoutMutation)(observer(Logout));




const Logout = () => (

    <Mutation mutation={REVOKE} variables={{token:window.localStorage.getItem('token')}}>
    
      

     {({ loading, error, data }) => {
        //   if (loading) return <Loader />
          if (error) return <div>Error Loading Data</div>
         // console.log(data.data.revokeToken.revoked);
          window.location.href = "/login";
          window.localStorage.clear();
          return (
           <div></div>
          );
        }}
  </Mutation>

);
export default Logout;