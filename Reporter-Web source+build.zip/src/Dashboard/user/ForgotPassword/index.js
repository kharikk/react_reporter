// import React, {Component, useRef} from "react";
import React from "react";
import gql from "graphql-tag";
import { Query, graphql } from "react-apollo";
import { toast } from "react-toastify";
import { compose } from "react-apollo";
import { Spinner } from "../../Spinner";
import Joi from "joi";
import strategy from "joi-validation-strategy";
import validation from "react-validation-mixin";

const generateOtp = gql`
  mutation GetOtp($mobile: String!, $country: String!) {
    generateOtp(mobile: $mobile, country: $country, isForgot: true) {
      generateOtp {
        isSuccess
        message
      }
    }
  }
`;

const verifyOtp = gql`
  mutation VerifyOtp($mobile: String!, $otp: String!) {
    verifyOtp(mobile: $mobile, otp: $otp, isForgot: true) {
      verifyOtp {
        isSuccess
        message
      }
    }
  }
`;

const resetPassword = gql`
  mutation ResetPassword($mobile: String!, $newPassword: String!) {
    resetPassword(mobile: $mobile, newPassword: $newPassword) {
      resetPassword {
        message
        isSuccess
      }
    }
  }
`;

const options = {
  language: {
    any: {
      required: "{{key}} custom required message."
    }
  }
};

class ForgotPassword extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentStep: 1,
      mobile: "",
      otp: "",
      password: "",
      cpassword: "",
      otpv: false,
      showSpinner: false,
      showSpinner1: false,
      message: ""
    };

    this.validatorTypes = {
      mobile: Joi.string()
        .required()
        .label("mobile")
        .error(errors => {
          return {
            message: "Please enter a valid email id / mobile number"
          };
        }),
      password: Joi.string()
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$^+=!*()@%&]).{8,}$/)
        .required()
        .label("password")
        .error(errors => {
          return {
            message:
              "Try using  minimum of 8 characters and a combination of UPPERCASE, lowercase, digits(0-9) and special characters"
          };
        }),

      cpassword: Joi.string()
        .valid(Joi.ref("password"))
        .required()
        .label("cpassword")
        .error(errors => {
          return {
            message: "Confirm password doesn't match with password"
          };
        })
    };
    this.getOTP = this.getOTP.bind(this);
    this.validateOTP = this.validateOTP.bind(this);
  }

  handleChange = event => {
   const { name, value } = event.target;

    if(name === 'otp' && isNaN(value)){

    return;

    }

    if(name === 'mobile'){

      this.setState({otpv: false});
    }

    
    this.setState({
      [name]: value
    });


  };

  _next = () => {
    let currentStep = this.state.currentStep;
    currentStep = currentStep >= 2 ? 3 : currentStep + 1;
    this.setState({
      currentStep: currentStep
    });
  };

  _prev = () => {
    let currentStep = this.state.currentStep;
    currentStep = currentStep <= 1 ? 1 : currentStep - 1;
    this.setState({
      currentStep: currentStep
    });
  };

  getOTP = async () => {
    console.log(this.props.isValid("mobile"));
    if (!this.props.isValid("mobile") || this.state.mobile === "") {
      this.setState({
        message: "Could not generate One-Time Password. Please try agin."
      });
      setTimeout(
        function() {
          this.setState({ message: "" });
        }.bind(this),
        5000
      );
      return;
    }
    this.setState({
      showSpinner: true
    });

    try {
      const response = await this.props.otpgeneratemutate({
        variables: { mobile: this.state.mobile, country: "" }
      });
      console.log(response);
      if (response.data.generateOtp.generateOtp.isSuccess) {
        let tempMessage =
          "A One-Time Password has been sent to " + this.state.mobile;

        this.setState({ message: tempMessage });
        this.setState({
          showSpinner: false
        });
      }

      setTimeout(
        function() {
          this.setState({ message: "" });
        }.bind(this),
        8000
      );
    } catch (error) {
      this.setState({
        message: error.graphQLErrors[0].message
      });
      setTimeout(
        function() {
          this.setState({ message: "" });
        }.bind(this),
        5000
      );
      this.setState({
        showSpinner: false
      });
      // console.log(error);
    }
  };

  validateOTP = async () => {
    this.setState({
      showSpinner1: true
    });

    try {
      const response = await this.props.otpverifymutate({
        variables: { mobile: this.state.mobile, otp: this.state.otp }
      });

      if (response.data.verifyOtp.verifyOtp.isSuccess) {
        let tempMessage = "OTP verified successfully";

        this.setState({ message: tempMessage });
        this.setState({
          showSpinner1: false
        });
        this.setState({
          otpv: true
        });

        this._next();
      }

      setTimeout(
        function() {
          this.setState({ message: "" });
        }.bind(this),
        5000
      );
    } catch (error) {
      this.setState({
        message: "Could not verify OTP"
      });
      setTimeout(
        function() {
          this.setState({ message: "" });
        }.bind(this),
        5000
      );
      this.setState({
        showSpinner1: false
      });
    }
  };

  handleUpdatePassword = () => {
    this.props.validate(
      async function(error) {
        if (error) {
          console.log(this.props.errors);

          let tempMessage = "Please fix the errors and try again ";

          this.setState({ message: tempMessage });
          return;
        } else {
          const mobile = this.state.mobile;
          const newPassword = this.state.password;

          this.setState({
            showSpinner: true
          });

          try {
            const response = await this.props.resetpasswordmutate({
              variables: { mobile, newPassword }
            });
            console.log(response);
            if (response.data) {
              toast.success("Password Changed Successfully");
              this.setState({
                showSpinner: false
              });
              window.location.href = "/login";
            }
          } catch (error) {
            toast.error(error.graphQLErrors[0].message);
            this.setState({
              showSpinner: false
            });
          }
        }
      }.bind(this)
    );
  };

  // The "next" and "previous" button functions
  previousButton() {
    let currentStep = this.state.currentStep;
    // If the current step is not 1, then render the "previous" button
    if (currentStep !== 1) {
      return (
        <i className="fas fa-long-arrow-alt-left" onClick={this._prev}></i>
      );
    }
    // ...else return nothing
    return null;
  }

  nextButton() {
    let currentStep = this.state.currentStep;
    let otpv = this.state.otpv;
    // If the current step is not 3, then render the "next" button
    if (currentStep < 2 && otpv) {
      return (
        <i className="fas fa-long-arrow-alt-right" onClick={this._next}></i>
      );
    }
    // ...else render nothing
    return null;
  }
  renderHelpText = message => {
    return <span className="help-block">{message}</span>;
  };

  getValidatorData() {
    return this.state;
  }
  render() {
    return (
      <React.Fragment>
        <div className="login-bg">
          <div className="login-form">
            <div className="card">
              <div className="prev-next-form">
                <span className="back-arrow"> {this.previousButton()}</span>
                <span className="next-arrow"> {this.nextButton()}</span>
              </div>
              <div className="card-logo">
                <img
                  src="https://cdn.worldvectorlogo.com/logos/ikon-1.svg"
                  alt="bg"
                ></img>
              </div>

              <div className="card-form">
                <Step1
                  currentStep={this.state.currentStep}
                  handleChange={this.handleChange}
                  mobile={this.state.mobile}
                  otp={this.state.otp}
                  getOTP={this.getOTP}
                  validateOTP={this.validateOTP}
                  showSpinner={this.state.showSpinner}
                  showSpinner1={this.state.showSpinner1}
                  message={this.state.message}
                  otpv={this.state.otpv}
                  renderHelpM={this.renderHelpText(
                    this.props.getValidationMessages("mobile")
                  )}
                  onBlurM={this.props.handleValidation("mobile")}
                />

                <Step2
                  currentStep={this.state.currentStep}
                  handleChange={this.handleChange}
                  handleUpdatePassword={this.handleUpdatePassword}
                  password={this.state.password}
                  cpassword={this.state.cpassword}
                  otpv={this.state.otpv}
                  onBlurP={this.props.handleValidation("password")}
                  onBlurCp={this.props.handleValidation("cpassword")}
                  renderHelpP={this.renderHelpText(
                    this.props.getValidationMessages("password")
                  )}
                  renderHelpCp={this.renderHelpText(
                    this.props.getValidationMessages("cpassword")
                  )}
                />

                <div className="container reg-border">
                  <div className="row">
                    <div className="col-sm-6">
                      <div className="text-left">
                        <span className="text-muted">
                          <a href="/login">Login</a>
                        </span>
                      </div>
                    </div>

                    <div className="col-sm-6">
                      <div className="text-right">
                        <span className="text-muted">
                          <a href="/register">Register</a>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}
function Step1(props) {
  if (props.currentStep !== 1) {
    return null;
  }

  return (
    <React.Fragment>
      <div className="form-group text-center">
        <p className="messageContainer">{props.message}</p>
        <p> {props.renderHelpM}</p>
      </div>
      <div className="card-inputs">
      <div className="form-group ">
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          onBlur={props.onBlurM}
          value={props.mobile}
          name="mobile"
          placeholder="Enter E-mail ID / Mobile Number"
          
        />
      </div>

      <div className="form-group mt35 spinner-container">
        <button
          onClick={props.getOTP}
          className="btn btn-outline-info btn-lg btn-block user-form-btn"
        >
          GET OTP {props.showSpinner ? <Spinner /> : null}
        </button>
      </div>

      <div className="form-group text-center mt35">
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          name="otp"
          placeholder="Enter OTP"
          maxLength={4}
          value={props.otp}
        />
      </div>
      <div className="form-group text-center mt35 spinner-container">
        <button
          onClick={props.validateOTP}
          disabled={props.otpv}
          className="btn btn-outline-info btn-lg btn-block user-form-btn"
        >
          Verify {props.showSpinner1 ? <Spinner /> : null}
        </button>
      </div>
      </div>
    </React.Fragment>
  );
}

function Step2(props) {
  if (props.currentStep !== 2) {
    return null;
  }
  return (
    <React.Fragment>
      <div className="form-group text-center">
        <p className="messageContainer">{props.message}</p>
        <p> {props.renderHelpP}</p>
        <p> {props.renderHelpCp}</p>
      </div>
      <div className="card-inputs">
      <div className="form-group ">
        <input
          type="password"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          onBlur={props.onBlurP}
          value={props.password}
          name="password"
          placeholder="Enter new password"
        />
      </div>
      <div className="form-group ">
        <input
          type="password"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          onBlur={props.onBlurCp}
          value={props.cpassword}
          name="cpassword"
          placeholder="Confirm password"
        />
      </div>

      <div className="form-group mt35 spinner-container">
        <button
          onClick={props.handleUpdatePassword}
          className="btn btn-outline-info btn-lg btn-block user-form-btn"
        >
          Confirm & Sign In {props.showSpinner ? <Spinner /> :  null }
        </button>
      </div>
      </div>
    </React.Fragment>
  );
}
export default compose(
  graphql(generateOtp, { name: "otpgeneratemutate" }),
  graphql(verifyOtp, { name: "otpverifymutate" }),
  graphql(resetPassword, { name: "resetpasswordmutate" })
)(validation(strategy(options))(ForgotPassword));
