import React from "react";
import gql from "graphql-tag";
import { Query, graphql } from "react-apollo";
import { toast } from "react-toastify";
import { compose } from "react-apollo";
import { Spinner } from "../../Spinner";
import Countries from "./countries";
import Joi from "joi";
import strategy from "joi-validation-strategy";
import validation from "react-validation-mixin";

const generateOtp = gql`
  mutation GetOtp($mobile: String!, $country: String!) {
    generateOtp(mobile: $mobile, country: $country) {
      generateOtp {
        isSuccess
        message
      }
    }
  }
`;

const verifyOtp = gql`
  mutation VerifyOtp($mobile: String!, $otp: String!) {
    verifyOtp(mobile: $mobile, otp: $otp) {
      verifyOtp {
        isSuccess
        message
      }
    }
  }
`;

const registerUser = gql`
  mutation CreateUser(
    $email: String!
    $password: String!
    $firstname: String!
    $lastname: String!
    $mobilenumber: String!
    $rolename: String!
    $username: String!
    $location: String
    $countryCode: String!
  ) {
    createUser(
      email: $email
      password: $password
      firstname: $firstname
      lastname: $lastname
      mobilenumber: $mobilenumber
      rolename: $rolename
      username: $username
      location: $location
      countryCode: $countryCode
    ) {
      user {
        email
      }
    }
  }
`;

const options = {
  language: {
    any: {
      required: "{{key}} custom required message."
    }
  }
};

class Register extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentStep: 1,
      username: "",
      mobile: "",
      password: "",
      cpassword: "",
      otp: "",
      email: "",
      firstname: "",
      lastname: "",
      location: "",
      country: '+91',
      otpv: false,
      role: "Reporter",
      showSpinner: false,
      showSpinner1: false,
      message: ""
    };

    this.validatorTypes = {
      mobile: Joi.number()
        .required()
        .min(1000000000)
        .max(9999999999)
        .label("mobile")
        .error(errors => {
          return {
            message: "Please enter a valid mobile number"
          };
        }),



      password: Joi.string()
        .required()
        .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$^+=!*()@%&]).{8,}$/)
        .label("password")
        .error(errors => {
          return {
            message: "Try using  minimum of 8 characters and a combination of UPPERCASE, lowercase, digits(0-9) and special characters"
          };
        }),

      cpassword: Joi.string()
        .valid(Joi.ref("password"))
        .required()
        .label("cpassword")
        .error(errors => {
          return {
            message: "Confirm password doesn't match with password"
          };
        }),

      username: Joi.string()
        .required()
        .regex(/^[a-zA-Z0-9]+$/)
        .label("username")
        .error(errors => {
          return {
            message: "Please enter a valid username"
          };
        }),

      email: Joi.string()
        .email({ minDomainAtoms: 2 })
        .required()
        .label("email")
        .error(errors => {
          return {
            message: "Please enter a valid email address"
          };
        }),

      firstname: Joi.string()
        .required()
        .regex(/^[a-zA-Z\s]*$/)
        .label("firstname")
        .error(errors => {
          return {
            message: "Please enter a valid first name"
          };
        }),

      lastname: Joi.string()
        .required()
        .regex(/^[a-zA-Z\s]*$/)
        .label("lastname")
        .error(errors => {
          return {
            message: "Please enter a valid last name"
          };
        }),

      location: Joi.string()
        .required()
        .regex(/^[a-zA-Z\s]*$/)
        .label("location")
        .error(errors => {
          return {
            message: "Please enter a valid location"
          };
        }),

        otp: Joi.number()
        .min(1000)
        .max(9999)
        .label("otp")
        .error(errors => {
          return {
            message: "OTP should be of 4 digits"
          };
        }),
       

       
    };

    this.generateOTP = this.generateOTP.bind(this);
    this.validateOTP = this.validateOTP.bind(this);
    this.handleOtpChange = this.handleOtpChange.bind(this);
    this.onCountryChange = this.onCountryChange.bind(this);
  }

  handleChange = event => {

    const { name, value } = event.target;

    if(name === 'mobile' && isNaN(value)){

    return;

    }

    if(name === 'mobile'){

      this.setState({otpv: false});
    }

    
    this.setState({
      [name]: value
    });

  };



   onCountryChange(country) {
    
    this.setState({
      country: country
    });

  }

    handleOtpChange(otp, event: SyntheticKeyboardEvent<HTMLElement>){
    
      if(!isNaN(otp.target.value)){

        // if(this.state.otp.length < 4){

           this.setState({ 
      otp: otp.target.value
    });
     //   }


      

     }

    

  };


  _next = () => {
    let currentStep = this.state.currentStep;
    currentStep = currentStep >= 2 ? 3 : currentStep + 1;
    this.setState({
      currentStep: currentStep
    });
  };

  _prev = () => {
    let currentStep = this.state.currentStep;
    currentStep = currentStep <= 1 ? 1 : currentStep - 1;
    this.setState({
      currentStep: currentStep
    });
  };

  /*
   * the functions for our button
   */

  generateOTP = async () => {

 

    if (!this.props.isValid("mobile") || this.state.mobile === "") {
      this.setState({
        message: "Please enter a valid mobile number"
      });
      setTimeout(
        function() {
          this.setState({ message: "" });
        }.bind(this),
        5000
      );
      return;
    }
    this.setState({
      showSpinner: true
    });

    try {
      const response = await this.props.otpgeneratemutate({
        variables: { mobile: this.state.mobile, country: this.state.country }
      });
      console.log(response);
      if (response.data.generateOtp.generateOtp.isSuccess) {
        let tempMessage =
          "A One-Time Password has been sent to " + this.state.mobile;

        this.setState({ message: tempMessage });
        this.setState({
          showSpinner: false
        });
      }

      setTimeout(
        function() {
          this.setState({ message: "" });
        }.bind(this),
        8000
      );
     
    } catch (error) {
      this.setState({
        message: error.graphQLErrors[0].message
      });
      setTimeout(
        function() {
          this.setState({ message: "" });
        }.bind(this),
        5000
      );
      this.setState({
        showSpinner: false
      });
      // console.log(error);
    }
  };

  validateOTP = async () => {
    
    var mvalid = this.props.isValid("mobile");
    var psswd = this.props.isValid("password");
    var cpasswd = this.props.isValid("cpassword");

    if(!mvalid || !psswd || !cpasswd || !this.state.mobile || !this.state.password || !this.state.cpassword){

      let tempMessage = "Please fill the valid details and try again ";

          this.setState({ message: tempMessage });
          return;

    }

    else{

         this.setState({
            showSpinner1: true
          });
          

          try {
            const response = await this.props.otpverifymutate({
              variables: { mobile: this.state.mobile, otp: this.state.otp }
            });

            if (response.data.verifyOtp.verifyOtp.isSuccess) {
              let tempMessage = "OTP verified successfully";

              this.setState({ message: tempMessage });
              this.setState({
                showSpinner1: false
              });
               this.setState({
               otpv: true
              });

              this._next();
            }

            setTimeout(
              function() {
                this.setState({ message: "" });
              }.bind(this),
              5000
            );
      
          } catch (error) {
            this.setState({
              message: error.graphQLErrors[0].message
            });
            setTimeout(
              function() {
                this.setState({ message: "" });
              }.bind(this),
              5000
            );
            this.setState({
              showSpinner1: false
            });
           
          }
   
    }
  };

  handleRegistration = async () => {



    this.props.validate(
      async function(error) {
        if (error) {
          console.log(this.props.errors)
          
          let tempMessage = "Please fix the errors and try again ";

          this.setState({ message: tempMessage });
          return;
        } else {
       
           const { email, password, firstname, lastname} = this.state;
           const username = this.state.username; 
            const mobilenumber = this.state.mobile; 
            const location = this.state.location;
            const rolename = this.state.role;
            const countryCode = this.state.country;
          
               this.setState({
            showSpinner: true
          });
         

          try {
            const response = await this.props.createusermutate({
              variables: { email, password, firstname, lastname, mobilenumber, rolename,  username , location, countryCode},
            });
              console.log(response);
            if (response.data) {
              toast.success("Registration Successfull");
              this.setState({
                showSpinner: false
              });
               window.location.href = "/login";

              
            }

          } catch (error) {
            toast.error(error.graphQLErrors[0].message);
            this.setState({
              showSpinner: false
            });
            //this._next();
            // console.log(error);
          }
        }

        // this.onSubmit()
      }.bind(this)
    );
  };

   previousButton() {
    let currentStep = this.state.currentStep;
    // If the current step is not 1, then render the "previous" button
    if (currentStep !== 1) {
      return (
        <i className="fas fa-long-arrow-alt-left" onClick={this._prev}></i>
      );
    }
    // ...else return nothing
    return null;
  }

  nextButton() {
    let currentStep = this.state.currentStep;
    let otpv = this.state.otpv;
    // If the current step is not 3, then render the "next" button
    if (currentStep < 2 && otpv) {
      return (
        <i className="fas fa-long-arrow-alt-right" onClick={this._next}></i>
      );
    }
    // ...else render nothing
    return null;
  }

  getValidatorData() {
    return this.state;
  }

  renderHelpText = message => {
    
    return <span className="help-block">{message}</span>;
  };

  render() {

    return (
      <React.Fragment>
        <div className="login-bg">
          <div className="login-form">
            <div className="card">
            <div className="prev-next-form">
                <span className="back-arrow"> {this.previousButton()}</span>
                <span className="next-arrow" disabled={this.state.otpv}> {this.nextButton()}</span>
              </div>
              <div className="card-logo">
                <img
                  src="https://cdn.worldvectorlogo.com/logos/ikon-1.svg"
                  alt="bg"
                ></img>
              </div>
              <div className="card-form">
             
              
                <Step1
                  currentStep={this.state.currentStep}
                  handleChange={this.handleChange}
                  handle
                  onCountryChange={this.onCountryChange}
                  handleOtpChange={this.handleOtpChange}
                  mobile={this.state.mobile}
                  country={this.state.country}
                  otp={this.state.otp}
                  errorDiv={this.state.errorDiv}
                  password={this.state.password}
                  cpassword={this.state.cpassword}
                  generateOTP={this.generateOTP}
                  validateOTP={this.validateOTP}
                  showSpinner={this.state.showSpinner}
                  showSpinner1={this.state.showSpinner1}
                  message={this.state.message}
                  renderHelpM={this.renderHelpText(
                    this.props.getValidationMessages("mobile")
                  )}
                  renderHelpP={this.renderHelpText(
                    this.props.getValidationMessages("password")
                  )}
                  renderHelpCp={this.renderHelpText(
                    this.props.getValidationMessages("cpassword")
                  )}
                  onBlurM={this.props.handleValidation("mobile")}
                  onBlurP={this.props.handleValidation("password")}
                  onBlurCp={this.props.handleValidation("cpassword")}
                />
                <Step2
                  currentStep={this.state.currentStep}
                  handleChange={this.handleChange}
                  handleRegistration={this.handleRegistration}
                  email={this.state.email}
                  username={this.state.username}
                  firstname={this.state.firstname}
                  lastname={this.state.lastname}
                  location={this.state.location}
                  role={this.state.role}
                  showSpinner={this.state.showSpinner}
                  onBlurE={this.props.handleValidation("email")}
                  onBlurFn={this.props.handleValidation("firstname")}
                  onBlurLn={this.props.handleValidation("lastname")}
                  onBlurLo={this.props.handleValidation("location")}
                  onBlurU={this.props.handleValidation("username")}
                  renderHelpE={this.renderHelpText(
                    this.props.getValidationMessages("email")
                  )}
                  renderHelpFn={this.renderHelpText(
                    this.props.getValidationMessages("firstname")
                  )}
                  renderHelpLn={this.renderHelpText(
                    this.props.getValidationMessages("lastname")
                  )}
                  renderHelpLo={this.renderHelpText(
                    this.props.getValidationMessages("location")
                  )}
                  renderHelpU={this.renderHelpText(
                    this.props.getValidationMessages("username")
                  )}
                />

               
           
              </div>
               <div className="container reg-border">
                <div className="row">
                  <div className="col-sm-6">
                    <div className="text-left">
                      <span className="text-muted">
                        <a href="/login">Login</a>
                      </span>
                    </div>
                  </div>

                  <div className="col-sm-6">
                    <div className="text-right">
                      <span className="text-muted">
                        <a href="/reset-password">Forgot Password?</a>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

function Step1(props) {
  if (props.currentStep !== 1) {
    return null;
  }

  return (
    <React.Fragment>
      <div className="form-group error-container">
        <p className="messageContainer">{props.message}</p>
        <p> {props.renderHelpM}</p>
        <p> {props.renderHelpP}</p>
        <p> {props.renderHelpCp}</p>
      </div>
      <div className="card-inputs">
      <div className="form-group country-container">
      <span>
      <Countries
          type="text"
          className="form-control input-lg"
          onChange={props.onCountryChange}
          value={props.country}
          name="country"

        />
        </span>
        <span>
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          value={props.mobile}
          placeholder="Mobile Number"
          name="mobile"
          pattern="^\d{10}$"
          onBlur={props.onBlurM}
          maxLength={10}
        />
        </span>
        </div>
         
      <div className="form-group">
        <input
          type="password"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          placeholder="Password"
          name="password"
          onBlur={props.onBlurP}
        />
      </div>
      <div className="form-group">
        <input
          type="password"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          onBlur={props.onBlurCp}
          placeholder="Confirm Password"
          name="cpassword"
        />
      </div>
      <div className="form-group text-center mt35  spinner-container">
        <button
          className="btn btn-outline-info btn-lg btn-block user-form-btn"
          disabled={props.showSpinner}
          onClick={props.generateOTP}
        >
          Get OTP {props.showSpinner ? <Spinner /> : null}
        </button>
      </div>
      <div className="form-group mt35 ">
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleOtpChange}
          value={props.otp}
          placeholder="OTP"
          name="otp"
          maxLength={4}
        />
      </div>
      <div className="form-group text-center mt35 spinner-container">
        <button
          className="btn btn-outline-info btn-lg user-form-btn"
          disabled={props.showSpinner1}
          onClick={props.validateOTP}
        >
          Verify {props.showSpinner1 ? <Spinner /> : null}
        </button>
      </div>
      </div>
    </React.Fragment>
  );
}

function Step2(props) {
  if (props.currentStep !== 2) {
    return null;
  }
  return (
    <React.Fragment>
      <div className="form-group error-container">
        <p className="messageContainer">{props.message}</p>
        <p> {props.renderHelpU}</p>
        <p> {props.renderHelpE}</p>
        <p> {props.renderHelpFn}</p>
        <p> {props.renderHelpLn}</p>
        <p> {props.renderHelpLo}</p>
      </div>
      <div className="card-inputs">
      <div className="form-group ">
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          value={props.username}
          placeholder="Username"
          name="username"
          onBlur={props.onBlurU}
        />
      </div>
      <div className="form-group ">
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          value={props.email}
          placeholder="Email ID"
          name="email"
          pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
          onBlur={props.onBlurE}
        />
      </div>
      <div className="form-group ">
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          value={props.firstname}
          placeholder="First Name"
          pattern="[A-Za-z]$"
          name="firstname"
          onBlur={props.onBlurFn}
        />
      </div>
      <div className="form-group">
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          value={props.lastname}
          placeholder="Last Name"
           pattern="[A-Za-z]$"
          name="lastname"
          onBlur={props.onBlurLn}
        />
      </div>
      <div className="form-group ">
        <input
          type="text"
          className="form-control input-lg align-center"
          onChange={props.handleChange}
          value={props.location}
          placeholder="Location"
           pattern="[A-Za-z]$"
          name="location"
          onBlur={props.onBlurLo}
        />
      </div>
      <div className="form-group text-center mt35 spinner-container">
        <button
          className="btn btn-outline-info btn-lg user-form-btn"
          disabled={props.showSpinner}
          onClick={props.handleRegistration}
        >
          Submit {props.showSpinner ? <Spinner /> : null}
        </button>
      </div>
      </div>
    </React.Fragment>
  );
}

export default compose(
  graphql(generateOtp, { name: "otpgeneratemutate" }),
  graphql(verifyOtp, { name: "otpverifymutate" }),
  graphql(registerUser, { name: "createusermutate" })
)(validation(strategy(options))(Register));
