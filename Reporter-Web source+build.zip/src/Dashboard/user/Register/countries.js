import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
 
// import Select from 'react-select';
const GET_COUNTRY_CODES= gql`
query GetCountryCodes{
    getCountries{
   countryCode
   code
  }
  }
`;


class Countries extends React.Component{
    
constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.state = {selectedOption: null};
        
  }

  handleChange = (selectedOption) => {
    
     let val = selectedOption.target.value;
        this.setState({ selectedOption: val });
    this.props.onChange(val)
  
  }

  componentDidMount() {

      if(this.state.selectedOption == null){

    this.setState({ selectedOption: "+91" })
  }

  }



   render() {
    return(

 <Query query={GET_COUNTRY_CODES} >
    
      

     {({ loading, error, data }) => {
          if (loading) return <div></div>
          if (error) return <div>Error Loading Data</div>

          return (
              <div className="m-r-10">
              <select className="form-control" id="c-code" value={this.state.selectedOption} onChange={this.handleChange}>
            { data.getCountries.map((option, index) => <option key={index} value={option.code}>{option.code}</option>)}
          </select>
      
        </div>
          );
        }}
  </Query>
      );
   }
  
  
  

}

export default Countries;