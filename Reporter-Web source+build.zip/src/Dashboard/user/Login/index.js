import React , { Component } from "react";
import gql from "graphql-tag";
import { graphql } from "react-apollo";
import { toast } from "react-toastify";
import { compose } from "react-apollo";
import Joi from "joi";
import strategy from "joi-validation-strategy";
import validation from "react-validation-mixin";
import FacebookLogin from 'react-facebook-login/dist/facebook-login-render-props'
import { GoogleLogin } from 'react-google-login';


import { Spinner } from "../../Spinner";

const mutation = gql`
  mutation LoginUser($userName: String!, $password: String!) {
    login(userName: $userName, password: $password) {
      user{
      user{
        id
        email
        username
        isVerifiedByAdmin
        isActive
        groups{
          name
        }
      }
      token
    }
    }
  }
`;
const verifyMutation = gql`
  mutation LoginUser($token: String!) {
    verifyToken(token: $token) {
      payload
    }
  }
`;

const socialLogin = gql`

  mutation SocialLogin($accessToken: String!, $provider: String!) {
    socialAuth(accessToken:$accessToken,provider:$provider){
      
      social{
        extraData
        user{
          id
          email
          username
          groups{
            name
          }
          isVerifiedByAdmin
          isActive
        }
      }
      token
    }
  }
`;
const options = {
  language: {
    any: {
      required: "{{key}} custom required message."
    }
  }
};

class Login extends Component {
  constructor(props) {


    super(props);
    console.log(this.props)
    this.state = {
      userName: "",
      password: "",
      name: "",
      accessToken: "",
      provider: "",
      display: "none",
      showSpinner: false,
    };

    this.validatorTypes = {
      userName: Joi.string()
        .required()
        .label("userName")
        .error(errors => {
       
          return {
            message: "Please enter a valid email id / mobile number"
          };
        }),

      password: Joi.string()
        .required()
        .label("password")
        .error(errors => {
       
          return {
            message: "Password field should not be empty"
          };
        })
    };


this.onClickSubmit = this.onClickSubmit.bind(this);
this.onSubmit = this.onSubmit.bind(this);
this.onSocialLogin = this.onSocialLogin.bind(this);

    
  }

   _handleKeyDown = (e) => {
   
    if (e.key === 'Enter') {
     this.onClickSubmit();
    }
  }

  getValidatorData() {
    return this.state;
  }

onClickSubmit(event) {



  console.log(this.props.errors)
  this.props.validate(function(error) {
  if(error) {
    // form contains errors
    return;
  }

  this.onSubmit()
  
}.bind(this));



  }

 


  onSubmit = async () => {

     this.setState({
            showSpinner: true
          });

    //this.onClickSubmit();
    const { userName, password } = this.state;

    try {
      const response = await this.props.loginmutate({
        variables: { userName, password }
      });
     
      const token  = response.data.login.user.token;
      console.log(token);
    
      if (response.data.login.user.token) {
        localStorage.setItem("token", token);
        localStorage.setItem(
          "userGroup",
          response.data.login.user.user.groups[0].name
        );
        localStorage.setItem("userName", response.data.login.user.user.username);
        localStorage.setItem("userEmail", response.data.login.user.user.email);
        localStorage.setItem("userId", response.data.login.user.user.id);
        localStorage.setItem(
          "userVerified",
          response.data.login.user.user.isVerifiedByAdmin
        );

         this.setState({
            showSpinner: false
          });
        window.location.href = "/Dashboard";
      }
    } catch (error) {
       this.setState({
            showSpinner: false
          });
      // this.notify('error','Invalid credentials');
      localStorage.clear();
      toast.error("Invalid Credentails");
    }
  };


   onSocialLogin = async () => {

  

    //this.onClickSubmit();
    const { accessToken, provider } = this.state;

    try {
      const response = await this.props.socialauthmutate({
        variables: { accessToken, provider }
      });
     //console.log(response.data);
      const token  = response.data.socialAuth.token;
      console.log(token);
    
      if (response.data.socialAuth.token) {
        localStorage.setItem("token", token);
        localStorage.setItem(
          "userGroup",
          response.data.socialAuth.social.user.groups[0].name
        );
        localStorage.setItem("userName", response.data.socialAuth.social.user.username);
        localStorage.setItem("userEmail", response.data.login.user.user.email);
        localStorage.setItem("userId", response.data.login.user.user.id);
        localStorage.setItem(
          "userVerified",
          response.data.socialAuth.social.user.isVerifiedByAdmin
        );


        
        window.location.href = "/Dashboard";
      }
    } catch (error) {
       this.setState({
            display: "none"
          });
      localStorage.clear();
      toast.error("Invalid username / password");
    }
  };

  onChange = field => {
    return event => {
      let state = {};
      state[field] = event.target.value;
      this.setState(state);
    };
  };

  renderHelpText = message => {
    return <span className="help-block">{message}</span>;
  };

   facebookResponse = (response) => {

    console.log(response.accessToken);
    if(response.accessToken){

      this.setState({ accessToken: response.accessToken, provider: "facebook", display: "block" }, () => {

          this.onSocialLogin();
      });
    }
        
    };

    googleResponse = (response) => {

    console.log(response);
    if(response.accessToken){

      this.setState({ accessToken: response.accessToken, provider: "google-oauth2", display: "block" }, () => {

          this.onSocialLogin();
      });
    }
        
    };

  render() {
    //const {  } = this.state;
    // const { editorState } = this.state;

    return (
      <div className="login-bg">
        <div className="login-form" onKeyDown={this._handleKeyDown}>
        
          <div className="card">
          <div className={'card-overlay '+this.state.display} >
          <Spinner />
        </div>
            <div className="card-logo">
              <img
                src="https://cdn.worldvectorlogo.com/logos/ikon-1.svg"
                alt="bg"
              ></img>
            </div>
            <div className="card-form">
              <h4 className="card-sub-title">Connect With</h4>

              <div className="text-center card-social-btn">
               <FacebookLogin
                        appId="452037772288012"
                        autoLoad={false}
                        fields="name,email,picture"
                        callback={this.facebookResponse}
                        render={renderProps => (
                          <a href="#" className=" btn btn-fb" onClick={renderProps.onClick}>
                  <i className="fab fa-facebook-f"></i>
                </a>
      
  )} />
                <a href="#" className="btn  btn-tw">
                  <i className="fab fa-twitter"></i>
                </a>
                 <GoogleLogin
    clientId="99348832866-5afav565gpij62cfqt78s88a0kmos8mt.apps.googleusercontent.com"
    render={renderProps => (
      <a href="#" className=" btn btn-gplus" onClick={renderProps.onClick}>
                  <i className="fab fa-google"></i>
                </a>
    )}
    buttonText="Login"
    onSuccess={this.googleResponse}
    onFailure={this.googleResponse}
    cookiePolicy={'single_host_origin'}
  />
                
              </div>

              <div className="or-seperator">
                <b>or</b>
              </div>
              <p className="text-center">sign in</p>
              <div className="form-group text-center error-container">
                {this.renderHelpText(this.props.getValidationMessages("email"))}
              </div>
              <div className="form-group text-center">
                {this.renderHelpText(
                  this.props.getValidationMessages("password")
                )}
              </div>
              <div className="card-inputs">
              <div className="form-group ">
                <input
                  type="text"
                  className="form-control input-lg align-center"
                  onChange={this.onChange("userName")}
                  onBlur={this.props.handleValidation("userName")}
                  value={this.state.userName}
                  ref="userName"
                  placeholder="Email ID / Mobie Number"
                  
                />
              </div>

              <div className="form-group">
                <input
                  type="password"
                  className="form-control input-lg align-center"
                  onChange={this.onChange("password")}
                  onBlur={this.props.handleValidation("password")}
                 
                  ref="password"
                  placeholder="Password"
                  
                />
              </div>

              <div className="form-group text-center spinner-container">
                <button
                  onClick={this.onClickSubmit}
                  disabled={this.state.showSpinner}
                  className="btn btn-outline-info btn-lg btn-block user-form-btn"
                >
                  Sign in {this.state.showSpinner ? <Spinner /> : null}
                </button>
              </div>
              </div>

              <div className="container reg-border">
                <div className="row">
                  <div className="col-sm-6">
                    <div className="text-left">
                      <span className="text-muted">
                        <a href="/register">Register</a>
                      </span>
                    </div>
                  </div>

                  <div className="col-sm-6">
                    <div className="text-right">
                      <span className="text-muted">
                        <a href="/reset-password">Forgot Password?</a>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}



export default compose(
  graphql(mutation, { name: "loginmutate" }),
  graphql(socialLogin, { name: "socialauthmutate" }),
)(validation(strategy(options))(Login));
