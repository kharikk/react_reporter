import React, { Component } from "react";
import HeaderDashboard from "../../App/HeaderDashboard";
import { Query, graphql } from "react-apollo";
import gql from "graphql-tag";
import moment from "moment";
import Modal from "react-responsive-modal";
import StatusBar from "../../App/StatusBar";
import { UserInfo } from "../../App/UserInfo";
import { toast } from "react-toastify";
// import Footer from '../App/Footer';

const GET_USER_PROFILE = gql`
  query GetCurrentUserProfile($token: String!) {
    GetProfile(token: $token) {
      firstName
      lastName
      dateJoined
      location
      mobilenumber
      email
      profileSet {
        qualification
        address1
      }
    }
  }
`;

const changepassword = gql `

mutation ChangePassword($p: String!, $op: String!, $token:String!){
  
  changePassword(newpassword: $p, oldpassword:$op, token:$token){
    
    user{
      id
      slug
    }
  }
  
}

`;



export default class Profile extends Component {
  constructor() {
    super();
    this.state = {
      isOpen: false,
      password:"",
      cpassword:"",
      opassword:""
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  onOpenModal = () => {
    this.setState({ isOpen: true });
  };

  onCloseModal = () => {
    this.setState({ isOpen: false });
  };

  handleChange(e) {
    let field = e.target.name;
    this.setState({ [field]: e.target.value })
  }

  async handleSubmit() {

let o = this.state.opassword;
let p = this.state.password;
let c = this.state.cpassword;
      if(!o || !p || !c){

          toast.error("Please fill in valid details and try again!");
          return null;

      }

      else if(p !== c){

        toast.error("Confirm password doesn't match with password");
        return null;
      }


      else{

             try {
      const response = await this.props.mutate({
        variables: {
          p: this.state.password,
          token: window.localStorage.getItem("token"),
          op: this.state.opassword
        }
      });
      console.log(response);
      if (response.data) {
        toast.success("Password updated successfully. Please login again.");
        localStorage.clear();
         setTimeout(function() {
          
         window.location.href = "/logout";
        }, 3000);
        this.setState({ password:"",
                        opassword: "",
                        cpassword: "",
                        isOpen: false
                      })
      }
    } catch (error) {
      toast.error(error.graphQLErrors[0].message);
    }

      }

  }

  
  render() {
    return (
      <Query
        query={GET_USER_PROFILE}
        variables={{ token: window.localStorage.getItem("token") }}
      >
        {({ loading, error, data }) => {
          if (loading) return <div></div>;
          if (error) return <div></div>;

          return (
            <div className="container-fluid no-padding">
              <div className="row no-margin">
                <HeaderDashboard />

                <div className="main-content" id="tglmcdisplay">
                  <StatusBar />
                  <span className="page-header">
                    <span className="article-header">My Profile</span>
                  </span>

                  <div className="row no-margin" id="main">
                    <div className="col-sm-12 col-md-12 well" id="content">
                      <div className="container-fluid">
                        <div className="row">
                          <div className="col-md-12">
                            <div className="row profile-details">
                              <div className="col-md-5">
                                <div className="d-flex">
                                  <div className="col-md-3">
                                    <img
                                      src="http://lorempixel.com/output/people-q-g-64-64-1.jpg"
                                      className="profile-img-circle"
                                      alt="Cinque Terre"
                                    ></img>
                                  </div>
                                  <div className="col-md-9 d-flex">
                                    <div className="col">
                                      <span className="user-details">
                                        <strong>Name</strong>
                                      </span>
                                      <span className="user-details">
                                        <strong>Qualification</strong>
                                      </span>
                                    </div>
                                    <div className="col">
                                      <span className="user-details">
                                        :{" "}
                                        {data.GetProfile.firstName +
                                          " " +
                                          data.GetProfile.lastName}
                                      </span>

                                      <span className="user-details">
                                        :
                                        {
                                          data.GetProfile.profileSet
                                            .qualification
                                        }
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="col d-flex">
                                <div className="col">
                                  <span className="user-details">
                                    <strong>Join Date</strong>
                                  </span>
                                  <span className="user-details">
                                    <strong>Category</strong>
                                  </span>
                                  <span className="user-details">
                                    <strong>Work Location</strong>
                                  </span>
                                </div>
                                <div className="col">
                                  <span className="user-details">
                                    :{" "}
                                    {moment(data.GetProfile.dateJoined).format(
                                      "LL"
                                    )}
                                  </span>
                                  <span className="user-details">
                                    : Politics
                                  </span>
                                  <span className="user-details">
                                    : {data.GetProfile.location}{" "}
                                  </span>
                                </div>
                              </div>

                              <div className="col d-flex">
                                <div className="col">
                                  <span className="user-details">
                                    <strong>Mobile No</strong>
                                  </span>
                                  <span className="user-details">
                                    <strong>Email</strong>
                                  </span>
                                  <span className="user-details">
                                    <strong>Address</strong>
                                  </span>
                                </div>
                                <div className="col">
                                  <span className="user-details">
                                    :{data.GetProfile.mobilenumber}
                                  </span>

                                  <span className="user-details">
                                    :{data.GetProfile.email}
                                  </span>

                                  <span className="user-details">
                                    :{data.GetProfile.profileSet.address1}{" "}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-md-12 mt35">
                          <a href={"/profile/edit/" + UserInfo().id}>
                            <button
                              type="button"
                              className="btn btn-outline-info pull-right m-r-20"
                            >
                              Edit
                            </button>
                          </a>
                          <button
                            type="button"
                            className="btn btn-outline-info  m-r-20"
                            onClick={this.onOpenModal}
                            data-toggle="modal"
                            data-target="#loginModal"
                          >
                            Change Password
                          </button>
                          <Modal
                            open={this.state.isOpen}
                            onClose={this.onCloseModal}
                             classNames={{
          overlay: "cpOverlay",
          modal: "cpModal",
        }}
                          >
                            <div
                              className="modal1 password-modal"
                              id="loginModal"
                              tabindex="-1"
                            >
                              <div className="modal-dialog">
                                <div className="modal-content">
                                  <div className="modal-header">
                                    {/* <button className="close" data-dismiss="modal">&times;</button> */}
                                    <h4 className="modal-title">
                                      Change password
                                    </h4>
                                  </div>
                                  <div className="modal-body">
                                    <form>
                                      <div className="form-group">
                                        <label for="inputcurrentpassword">
                                          Current Password
                                        </label>
                                        <input
                                          className="form-control"
                                          placeholder="Change Password"
                                          type="password"
                                          id="inputcurrentpassword"
                                          name="opassword"
                                          value={this.state.opassword}
                                          onChange={this.handleChange}
                                        />
                                      </div>
                                      <div className="form-group">
                                        <label for="inputNewpassword">
                                          New Password
                                        </label>
                                        <input
                                          className="form-control"
                                          placeholder="New Password"
                                          type="password"
                                          id="inputNewpassword"
                                          name="password"
                                          value={this.state.password}
                                          onChange={this.handleChange}
                                        />
                                      </div>
                                      <div className="form-group">
                                        <label for="inputconfirmpassword">
                                          Confirm Password
                                        </label>
                                        <input
                                          className="form-control"
                                          placeholder="Confirm Password"
                                          type="password"
                                          id="inputconfirmpassword"
                                          name="cpassword"
                                          value={this.state.cpassword}
                                          onChange={this.handleChange}
                                        />
                                      </div>
                                    </form>
                                  </div>
                                  <div className="modal-footer text-center">
                                    <button className="btn btn-primary" onClick={this.handleSubmit}>
                                      Submit
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </Modal>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        }}
      </Query>
    );
  }
}

Profile = graphql(changepassword)(Profile);
