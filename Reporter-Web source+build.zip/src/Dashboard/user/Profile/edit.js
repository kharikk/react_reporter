import React, { Component } from 'react';
import { Query, graphql } from "react-apollo";
import HeaderDashboard from '../../App/HeaderDashboard';
import ReactDOM from 'react-dom';
import gql from "graphql-tag";
import Modal from 'react-responsive-modal';
import StatusBar from '../../App/StatusBar';
import { render } from "react-dom";
import { toast } from "react-toastify";
import axios from "axios";
import moment from "moment";
import DatePicker from "react-datepicker";
import "react-daterange-picker/dist/css/react-calendar.css";


const uploadQuery = "mutation{ uploadFiles(upload: Upload){ result message }}";

const GET_USER_PROFILE = gql`



query GetCurrentUserProfile($token: String!){  
  GetProfile(token: $token){
    
  firstName
    lastName
    dateJoined
    location
    mobilenumber
    email
    profilephoto
    profileSet{
      qualification
    }
    
  }
}
`;
const mutation = gql`
mutation UpdateProfile($token: String!, $profileData: ProfileInput!){
  
  updateProfile(token: $token, profileData: $profileData){
    
    profile{
    
      id
    }
    
  }
}
`;

var qualification;
class Profile extends Component {


  constructor(props) {

    super(props);
    console.log(props);
   
    const src =  "https://i.pravatar.cc/300";
    const userDetails = this.props.profileData;
    this.state = {
      avatar: userDetails.profilephoto,
      firstname: userDetails.firstName,
      lastname: userDetails.lastName,
      // joiningdate: new Date(),
      datejoined: userDetails.dateJoined,
      mobileno: userDetails.mobilenumber,
      qualification: null,
      worklocation: userDetails.location,
      email: userDetails.email,
      category: userDetails.firstName,
      address: userDetails.address,
      preview: src,
      loaded: 0,
      uploadFile: "",
      isOpen: false,
      

    };
    console.log(this.props)
    this.handleFirstNameChange = this.handleFirstNameChange.bind(this);
    this.handleLastNameChange = this.handleLastNameChange.bind(this);
    this.handleDateJoinedChange = this.handleDateJoinedChange.bind(this);
    this.handleMobileNoChange = this.handleMobileNoChange.bind(this);
    this.handleQualificationChange = this.handleQualificationChange.bind(this);
    this.handleWorkLocationChange = this.handleWorkLocationChange.bind(this);
    this.handleCategoryChange = this.handleCategoryChange.bind(this);
    this.handleAddressChange = this.handleAddressChange.bind(this);
    this.onAvatarUpload = this.onAvatarUpload.bind(this);
  }

  componentDidMount(){

    if(!this.state.avatar){

      this.setState({ avatar: "https://ui-avatars.com/api/?name="+this.state.firstName+this.state.lastName},() => {

     

      })
    }
  }
  onOpenModal = () => {
    this.setState({ isOpen: true });
  };

  onCloseModal = () => {
    this.setState({ isOpen: false });
  };

  handleFirstNameChange(data) {


    this.setState({ firstname: data.target.value });
  }
  handleLastNameChange(data) {

    this.setState({ lastname: data.target.value });
  }
  handleDateJoinedChange(date) {
    this.setState(
      {
        datejoined: date
      },
      () => {
        console.log(moment(this.state.datejoined).format("YYYY-MM-DD"));
      }
    );
  }
  // handleJoiningDateChange(data) {

  //   this.setState({ joiningdate: data.target.value });
  // }
  handleMobileNoChange(data) {

    this.setState({ mobileno: data.target.value });
  }
  handleQualificationChange(data) {

    this.setState({ qualification: data.target.value });
  }
  handleWorkLocationChange(data) {

    this.setState({ worklocation: data.target.value });
  }
  handleCategoryChange(data) {

    this.setState({ category: data.target.value });
  }
  handleAddressChange(data) {

    this.setState({ address: data.target.value });
  }
  
  // onBeforeFileLoad(elem) {
  //   if (elem.target.files[0].size > 71680) {
  //     alert("File is too big!");
  //     elem.target.value = "";
  //   };

  // }
  onAvatarUpload(event) {
    this.setState({
      avatar: event.target.files[0],
    },() => {

      const data = new FormData();
    data.append("upload", this.state.avatar);
    data.append("query", uploadQuery);
    axios
      .post(process.env.REACT_APP_GRAPHQL_URL, data, {
      })
      .then(res => {
        console.log(res.data.data.uploadFiles.result);

        this.setState(
          { avatar: res.data.data.uploadFiles.result },
          () => {
          }
        );
      })
      .catch(err => {
        toast.error("Upload failed");
        
      });
    });
  }

  handleSubmit = async () => {
    var userDetails = {};

    userDetails["avatar"] = "";

    userDetails["firstname"] = this.state.firstname;
    userDetails["lastname"] = this.state.lastname;
    
    userDetails["qualification"] = this.state.qualification;
    userDetails["location"] = this.state.worklocation;
    userDetails["address"] = this.state.address;
    userDetails["avatar"] = this.state.avatar;
    console.log(userDetails);

    try {

      const response = await this.props.mutate({
        variables: {
          token: window.localStorage.getItem("token"),
          profileData: userDetails
        }
      });
      if (response.data.updateProfile.profile.id) {
        toast.success("Profile updated successfully");

      }
    } catch (error) {
      console.log(error);
      toast.error(error.graphQLErrors[0].message);
    }
  };

  

  handleValidation = () => {
   if (!isNaN(this.state.firstname) || !isNaN(this.state.lastname)) {
    toast.error("First Name/Last name could not contain any digits/special characters");
   }
    else{

      this.handleSubmit();
    }
  }
     




  render() {

    return (
      <div className="container-fluid no-padding">
        <div className="row no-margin">
          <HeaderDashboard />

          <div className="main-content" id="tglmcdisplay">
            <StatusBar />
            <span className="page-header">
              <span className="article-header">My Profile</span>
              <button type="button" className="btn btn-outline-info pull-right m-r-20">Back</button>

            </span>

            <div className="row no-margin" id="main" >
              <div className="col-sm-12 col-md-12 well" id="content">
                <div className="container-fluid">
                  <div className="row profile-details">
                    <div className="col-md-4">
                      <div className="row">
                        <div className="col-md-3">
                        <div className="pro-img-input">
                          <label htmlFor="pro-file-input">
                           <img src={this.state.avatar} className="img-circle img-responsive fa fa-camera" /> 
                                                      <i class="fa fa-camera color-white profile-cam-icon" ></i>
                          </label>

                          <input id="pro-file-input" type="file" onChange={this.onAvatarUpload} />
                        </div>
                        </div>
                        <div className="col-md-9">
                          <span className="edit-profile">
                            First Name <input value={this.state.firstname} type="name" onChange={this.handleFirstNameChange} className="form-control" placeholder="FirstName" required />
                            Last Name <input value={this.state.lastname} type="name" onChange={this.handleLastNameChange} className="form-control" placeholder="LastName" required />
                          </span>
                          <span className="edit-profile">
                          <label>Joining Date</label>
                          
                             <input value={this.state.dateJoined} disabled className="form-control" placeholder="Join Date" required />
                          </span>

                          <span className="edit-profile">
                            Mobile No  <input disabled value={this.state.mobileno} type="Mobile Number" onChange={this.handleMobileNoChange} className="form-control" placeholder="Mobile number" required />
                          </span>
                        </div>
                      </div>



                    </div>
                    <div className="col-md-4">
                      <span className="edit-profile">

                        Qualification <input value={this.state.qualification} type="text" onChange={this.handleQualificationChange} className="form-control" placeholder="Qualification" required />
                      </span>

                      <span className="edit-profile">
                        Work Location  <input value={this.state.worklocation} type="WorkLocation" onChange={this.handleWorkLocationChange} className="form-control" placeholder="Work Location" required />
                      </span>

                      <span className="edit-profile">
                        Email <input value={this.state.email} type="Email" disabled className="form-control" placeholder="Email"  />
                      </span>



                    </div>
                    <div className="col-md-4">
                      <span className="edit-profile">

                        Category  <input value={this.state.category} type="Category" onChange={this.handleCategoryChange} className="form-control" placeholder="Category" required />
                      </span>

                      <span className="edit-profile">
                        Address <input value={this.state.address} type="Address" onChange={this.handleAddressChange} className="form-control" placeholder="Address" required />
                      </span>


                    </div>



                  </div>


                  <div className="row ">
                   
                    <div className="col-sm-12">
                      <button
                        type="button"
                        className="btn btn-outline-info m-t-25 pull-right"
                        id="buttons"
                        // onClick={this.handleSubmit}
                        onClick={this.handleValidation}
                      >
                        Submit
                            </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    )
  }
}

export default class EditProfile extends Component {


  render() {


    return (
      <Query
        query={GET_USER_PROFILE}
        variables={{
          token: window.localStorage.getItem("token"),
          userSlug: this.props.match.params.userSlug,

        }}
      >
        {({ loading, error, data }) => {
          if (loading) return <div></div>;
            console.log(data);
          if (error) { window.location.href = "/404" };

          return (
            <Profile profileData={data.GetProfile} />
          );
        }}
      </Query>
    );
  }
}

Profile = graphql(mutation)(Profile);
