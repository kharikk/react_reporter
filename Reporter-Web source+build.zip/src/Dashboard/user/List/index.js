import React, { Component } from "react";
import HeaderDashboard from "../../App/HeaderDashboard";
import ReactDOM, { render } from "react-dom";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import { PageLoader } from "../../../PageLoader";
import ReactTable from "react-table";
import "react-table/react-table.css";
import moment from "moment";
import StatusBar from "../../App/StatusBar";
import { slug } from "../../../Helpers"




export default class UserList extends Component {
  constructor() {
    super();
  }

  render() {
    const GET_USER_PROFILE = gql`
      query getListOfUserAndArticleCountList(
        $token: String!
        $userType: String!
      ) {
        getListOfUserAndArticleCount(token: $token, userType: $userType) {
          draft
          rework
          published
          rejected
          pending
          createPermission
          editPermission
          rejectPermission

          user {
            id
            email
            username
            slug
          }
        }
      }
    `;

    const columns = [
      {
        Header: "Name",
        accessor: "username"
      },
      {
        Header: "Draft",
        accessor: "draft"
      },
      {
        Header: "Rework",
        accessor: "rework"
      },
      {
        Header: "Pending",
        accessor: "pending"
      },
      {
        Header: "Rejected",
        accessor: "rejected"
      },
      {
        Header: "Published",
        accessor: "published"
      },
      {
        Header: "Status",
        accessor: "slug",
        Cell: props => (
          <a href={"profile/" + slug(this.props.list)+'/'+props.value} className="profile-edit">
            Edit
          </a>
        )
      }
    ];

    
    return (
      <Query
        query={GET_USER_PROFILE}
        variables={{
          token: window.localStorage.getItem("token"),
          userType: this.props.list
        }}
      >
        {({ loading, error, data }) => {
          if (loading) return <PageLoader />;
          if (error) return <div></div>;
          var dataArray = [];

          for (let i = 0; i < data.getListOfUserAndArticleCount.length; i++) {
            dataArray.push({
              username: data.getListOfUserAndArticleCount[i].user.username,
              slug: data.getListOfUserAndArticleCount[i].user.slug,
              draft: data.getListOfUserAndArticleCount[i].draft,
              rework: data.getListOfUserAndArticleCount[i].rework,
              pending: data.getListOfUserAndArticleCount[i].pending,
              rejected: data.getListOfUserAndArticleCount[i].rejected,
              published: data.getListOfUserAndArticleCount[i].published
            });
          }

          return (
            <div className="container-fluid no-padding">
              <div className="row no-margin">
                <HeaderDashboard />

                <div className="main-content" id="tglmcdisplay">
                  <StatusBar />
                  <span className="page-header">
                    <span className="article-header">List of {this.props.list}s</span>
                    <button
                      type="button"
                      className="btn btn-outline-info pull-right m-r-20"
                      
                    >
                      Back
                    </button>
                  </span>
                  <div className="container-fluid">
                    <div className="row no-margin" id="main">
                      <div className="col-md-12">
                        <div className="users-table-container">
                          <ReactTable data={dataArray} columns={columns} minRows = {0}/>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        }}
      </Query>
    );
  }
}
