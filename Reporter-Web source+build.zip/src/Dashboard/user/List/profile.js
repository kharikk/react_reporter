import React, { Component } from "react";
import { Query, graphql } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import PageLoader from "../../../PageLoader";
import moment from "moment";
import SweetAlert from "react-bootstrap-sweetalert";
import HeaderDashboard from "../../App/HeaderDashboard";
import StatusBar from "../../App/StatusBar";
import { toast } from "react-toastify";
// import { UserInfo } from './UserInfo';
// import '../../admin.css';


const mutation = gql`
mutation UpdateUserPermission($token: String!, $inputData: UpdatePermissionsInput!){
  
  updatePermission(token: $token, permissionData: $inputData){
    
    user{
      username
    }
  }
}
`;

const GET_USER_PROFILE = gql`
  query GetReporterProfile(
    $token: String!
    $userSlug: String!
    $userType: String
  ) {
    getListOfUserAndArticleCount(
      token: $token
      userSlug: $userSlug
      userType: $userType
    ) {
      user {
        id
        firstName
        username
        profilephoto
        lastName
        slug
        dateJoined
        mobilenumber
        location
        email
        profileSet {
          qualification
          address1
          reportingTo
        }
      }
      pending
      published
      draft
      rejected
      rework
      editPermission
      createPermission
      rejectPermission
    }
  }
`;


export default class UserProfile extends Component {
  render() {
    console.log(this.props);
    return (
      <Query
        query={GET_USER_PROFILE}
        variables={{
          token: window.localStorage.getItem("token"),
          userSlug: this.props.match.params.userSlug,
          userType: this.props.match.params.userType.replace("-"," ")
        }}
      >
        {({ loading, error, data }) => {
          if (loading) return <div></div>;
          if (error) {window.location.href="/404"};

          return (
                <RenderProfile data={data} />
          );
        }}
      </Query>
    );
  }
}


class RenderProfile extends Component {


    constructor(props) {

    super(props);
    this.state = {
      id: this.props.data.getListOfUserAndArticleCount[0].user.id,
      create: this.props.data.getListOfUserAndArticleCount[0].createPermission,
      edit: this.props.data.getListOfUserAndArticleCount[0].editPermission,
      reject: this.props.data.getListOfUserAndArticleCount[0].rejectPermission

    };
      console.log(this.props)
  }
  toggleChangeC = () => {
    this.setState({
      create: !this.state.create,
    });
  }

  toggleChangeE = () => {
    this.setState({
      edit: !this.state.edit,
    });
  }

  toggleChangeR = () => {
    this.setState({
      reject: !this.state.reject,
    });
  }

  handlePermissionUpdate = async () => {

        var inputData = {};
        inputData['isEdit'] = this.state.edit;
        inputData['isAdd'] = this.state.create;
        inputData['isReject'] = this.state.reject;
        inputData['user'] = this.state.id;

    try {
      const response = await this.props.mutate({
        variables: {
          token: window.localStorage.getItem("token"),
          inputData: inputData
        }
      });
      if (response.data.updatePermission.user.username) {
        toast.success("Permissions updated successfully");
        
      }
    } catch (error) {
        console.log(error);
      toast.error(error.graphQLErrors[0].message);
    }
  };

    render() {

        return(

                <div className="container-fluid no-padding">
              <div className="row no-margin">
                <HeaderDashboard />

                <div className="main-content" id="tglmcdisplay">
                  <StatusBar />
                  <span className="page-header">
                    <span className="article-header">{this.props.data.getListOfUserAndArticleCount[0].user.firstName +" " +this.props.data.getListOfUserAndArticleCount[0].user.lastName}
                    </span>
                    <button
                      type="button"
                      className="btn btn-outline-info pull-right m-r-20"
                    >
                      Back
                    </button>
                  </span>

                  <div className="row no-margin" id="main">
                    <div className="col-sm-12 col-md-12 well" id="content">
                      <div className="container-fluid">
                        <div className="row no-margin">
                          {/* <div className="table-bordered"> */}
                          <div className="col-md-12">
                            <div className="row profile-details">
                              <div className="col-md-5">
                                <div className="d-flex">
                                  <div className="col-md-3">
                                    <img
                                      src="http://lorempixel.com/output/people-q-g-64-64-1.jpg"
                                      className="profile-img-circle"
                                      alt="Cinque Terre"
                                    ></img>
                                  </div>
                                  <div className="col-md-9 d-flex">
                                    <div className="col">
                                      <span className="user-details">
                                        <strong>Name</strong>
                                      </span>
                                      <span className="user-details">
                                        <strong>Qualification</strong>
                                      </span>
                                    </div>
                                    <div className="col">
                                      <span className="user-details">
                                        :{" "}
                                        {this.props.data.getListOfUserAndArticleCount[0]
                                          .user.firstName +
                                          " " +
                                          this.props.data.getListOfUserAndArticleCount[0]
                                            .user.lastName}
                                      </span>

                                      <span className="user-details">
                                        :{"  M.sc."}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="col d-flex">
                                <div className="col">
                                  <span className="user-details">
                                    <strong>Join Date</strong>
                                  </span>
                                  <span className="user-details">
                                    <strong>Category</strong>
                                  </span>
                                  <span className="user-details">
                                    <strong>Work Location</strong>
                                  </span>
                                </div>
                                <div className="col">
                                  <span className="user-details">
                                    :{" "}
                                    {moment(
                                      this.props.data.getListOfUserAndArticleCount[0].user
                                        .dateJoined
                                    ).format("LL")}
                                  </span>
                                  <span className="user-details">
                                    : Politics
                                  </span>
                                  <span className="user-details">
                                    :{" "}
                                    {
                                      this.props.data.getListOfUserAndArticleCount[0].user
                                        .location
                                    }{" "}
                                  </span>
                                </div>
                              </div>

                              <div className="col d-flex">
                                <div className="col">
                                  <span className="user-details">
                                    <strong>Mobile No</strong>
                                  </span>
                                  <span className="user-details">
                                    <strong>Email</strong>
                                  </span>
                                  <span className="user-details">
                                    <strong>Address</strong>
                                  </span>
                                </div>
                                <div className="col">
                                  <span className="user-details">
                                    :
                                    {
                                      this.props.data.getListOfUserAndArticleCount[0].user
                                        .mobilenumber
                                    }
                                  </span>

                                  <span className="user-details">
                                    :
                                    {
                                      this.props.data.getListOfUserAndArticleCount[0].user
                                        .email
                                    }
                                  </span>

                                  <span className="user-details">
                                    :
                                    {
                                      this.props.data.getListOfUserAndArticleCount[0].user
                                        .location
                                    }{" "}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="col-md-12">
                            <div className="row">
                              <table className="table table-bordered table-profile">
                                <thead>
                                  <tr>
                                    <th>Drafts</th>
                                    <th>Rework</th>
                                    <th>Pending</th>
                                    <th>Rejected</th>
                                    <th>Published</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td>
                                      {
                                        this.props.data.getListOfUserAndArticleCount[0]
                                          .draft
                                      }
                                    </td>
                                    <td>
                                      {
                                        this.props.data.getListOfUserAndArticleCount[0]
                                          .rework
                                      }
                                    </td>
                                    <td>
                                      {
                                        this.props.data.getListOfUserAndArticleCount[0]
                                          .pending
                                      }
                                    </td>
                                    <td>
                                      {
                                        this.props.data.getListOfUserAndArticleCount[0]
                                          .rejected
                                      }
                                    </td>
                                    <td>
                                      {
                                        this.props.data.getListOfUserAndArticleCount[0]
                                          .published
                                      }
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                        <div className="row no-margin">
                          <div className="d-block">
                            <p className="block-text">Permissions</p>
                            <span className="permissions-block">
                              <span className="profile-checkbox">
                                <input type="checkbox" value="create"  checked={this.state.create} onChange={this.toggleChangeC}/>
                                Create Article
                              </span>

                              <span className="profile-checkbox">
                                <input type="checkbox" checked={this.state.edit} onChange={this.toggleChangeE} />
                                Edit Article
                              </span>
                              <span className="profile-checkbox">
                                <input type="checkbox" checked={this.state.reject} onChange={this.toggleChangeR} />
                                Reject Article
                              </span>
                            </span>
                          </div>
                        </div>
                        <div className="row ">
                          <div className="col-sm-6">
                            <button
                              type="button"
                              className="btn btn-outline-info m-t-25"
                              id="buttons"
                              onClick={this.handlePermissionUpdate}
                            >
                              Save
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            );
    }

}

RenderProfile = graphql(mutation)(RenderProfile);
