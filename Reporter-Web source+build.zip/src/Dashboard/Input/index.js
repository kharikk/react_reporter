import React from 'react';

import './style.css';

const Input = ({ children, color = 'white', ...props }) => (
  <input className={`form-control `} {...props}>
    {children}
  </input>
);

export default Input;
