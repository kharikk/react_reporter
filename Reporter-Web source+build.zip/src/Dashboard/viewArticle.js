import React, { Component } from "react";
import gql from "graphql-tag";
import { Query, graphql } from "react-apollo";


import { EditorState } from "draft-js";


import HeaderDashboard from "./App/HeaderDashboard";
import StatusBar from "./App/StatusBar";
import { UserInfo } from "./App/UserInfo";


import { toast } from "react-toastify";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";
import "filepond/dist/filepond.min.css";
import "./admin.css";
import moment from "moment";
var token1 = window.localStorage.getItem("token");

var fileSet = [];
var tmpFiles = [];
var commentsArr = [];

var userEmail = UserInfo().email;
var isReporter = true;
if (UserInfo().group != "Reporter") {
  isReporter = false;
}

const GET_ARTICLE = gql`
query GetArticle($articleid: ID!, $token1: String!) {
    getDashboardArticles(articleId: $articleid, token: $token1) {
      id
      
      articletitle
      articledescription
      article{
        slug
        id
      isLocked
      articleType
      user {
        username
        email
        groups{
          name
        }
      }
      articleeditedbySet{
        
        commentsSet{
          comment
          modifiedAt
          commentby{
            editor{
              username
              
            }
            role
          }
        }
      }
      articlestatusSet {
        statusname
        globalStatus
      }
      section{
        name
      }
      
    }
      language {
        languagename
      }
      
      location
      
      category {
        categoryname
      }
      subcategory {
        subcategoryname
      }
      articlekeywordsSet {
        keywords {
          keyword
        }
      }
      attachmentsSet {
        isFeaturedImage
        path
        filename
      }
      featuredImage
    }
  }
`;

const mutation = gql`
  mutation updateArticle(
    $articleSlug: String!
    $token: String!
    $updateStatus: String!,
  ) {
    updateArticleByStatus(
      articleSlug: $articleSlug
      token: $token
      updateStatus: $updateStatus,comment:"dfd"
    ) {
      article {
        slug
      }
    }
  }
`;

export default class ViewArticle extends Component {
  render() {
    let articleId = this.props.match.params.id;

    return (
      <Query
        query={GET_ARTICLE}
        variables={{ articleid: articleId, token1: token1 }}
      >
        {({ loading, error, data }) => {
          if (loading) return <div></div>;
          if (error) return <div>Error Loading Data</div>;

        
          return <ArticleContent content={data.getDashboardArticles[0]} />;
        }}
      </Query>
    );
  }
}

class ArticleContent extends Component {
  constructor(props) {
    super(props);
    var keywordslist = [];
    var fileSet = [];
    console.log(props);
    for (var j = 0; j < this.props.content.articlekeywordsSet.length; j++) {
      keywordslist.push({
        value: this.props.content.articlekeywordsSet[j].keywords.keyword,
        label: this.props.content.articlekeywordsSet[j].keywords.keyword
      });
    }
    // console.log(this.props);
    this.state = {
      articleId: this.props.content.article.id,
      slug: this.props.content.article.slug,
      title: this.props.content.articletitle,
      location: this.props.content.location,
      category: this.props.content.category.categoryname,
      subcategory: this.props.content.subcategory.subcategoryname,
      language: this.props.content.language.languagename,
      // inputValue: "",
      lockstatus: this.props.content.article.isLocked,
      articledescription: this.props.content.articledescription,
      //value: this.props.content.keywordslist,
      articlekeywordsSet: this.props.content.articlekeywordsSet,
      featuredImage: this.props.content.featuredImage,
      files: [],
      status: this.props.content.article.articlestatusSet[0].globalStatus,
      section: this.props.content.article.section.name,
      reject: this.props.content.reject,
      publish: this.props.content.publish,
      isPublisher: false,
      isEditor: false,
      notReporter: false,
      isVerified: false,
      uploadFile: "",
      email: this.props.content.article.user.email,
      comments: [],
      historyHeadline:"",
      comment: '',
      articleType: this.props.content.article.articleType,
      editorState: EditorState.createEmpty()
    };

    this.handleReject = this.handleReject.bind(this);
    this.handlePublish = this.handlePublish.bind(this);
  }
  
  componentDidMount() {

    for (let i = 0; i < this.props.content.attachmentsSet.length; i++) {
      if (
        !this.props.content.attachmentsSet[i].isFeaturedImage &&
        this.props.content.attachmentsSet[i].path !== ""
      ) {
        fileSet.push(this.props.content.attachmentsSet[i].filename);
      }
    }

    if(this.props.content.article.articleeditedbySet.length > 0 ){
     
      

      for (let i = 0; i < this.props.content.article.articleeditedbySet.length; i++) {



        if(this.props.content.article.articleeditedbySet[i].commentsSet.length > 0){
            commentsArr.push({
          comment: this.props.content.article.articleeditedbySet[i].commentsSet[0].comment,
          commentBy: this.props.content.article.articleeditedbySet[i].commentsSet[0].commentby.editor.username,
          date: this.props.content.article.articleeditedbySet[i].commentsSet[0].modifiedAt,
          role: this.props.content.article.articleeditedbySet[i].commentsSet[0].role
        });

        }
         
        
        this.setState({historyHeadline:"Comments History"})

        
      }

    }
    
    this.setState({ comments: commentsArr })

    this.setState({ files: fileSet })
  }

    handleComment(e) {

    this.setState({ comment: e.target.value });
  }

  handleReject = async () => {
    try {
      console.log(this.state.slug);
      const response = await this.props.mutate({
        variables: {
          updateStatus: "Rejected",
          token: window.localStorage.getItem("token"),
          articleSlug: this.state.slug,
          comment: this.state.comment
        }
      });
      console.log(response);
      if (response.data.updateArticleByStatus.article) {
        toast.success("Article updated successfully");
        this.setState({ status: "REJECTED" });
      }
    } catch (error) {
      toast.error(error.graphQLErrors[0].message);
    }
  };

  handlePublish = async () => {
    try {
      console.log(this.state.slug);
      const response = await this.props.mutate({
        variables: {
          updateStatus: "Published",
          token: window.localStorage.getItem("token"),
          articleSlug: this.state.slug
        }
      });

      if (response.data.updateArticleByStatus.article) {
        toast.success("Article updated successfully");
      }
    } catch (error) {
      toast.error(error.graphQLErrors[0].message);
    }
  };

  render() {
    console.log("comments");
    
    var isReporter = false;
    if(UserInfo().group === 'Reporter'){
      isReporter = true;

    }

    console.log(this.state.comments);
    return (
      <div className="row no-margin">
        <HeaderDashboard />

        <div className="main-content" id="tglmcdisplay">
          <StatusBar />

          <div className="row">
            <div className="page-header">
              <div className="row">
                <div className="col-md-6">
                  <span className="article__title">
                    <h3>
                      {" "}
                      <strong>{this.state.title}</strong>
                    </h3>
                  </span>
                </div>

                <div className="col-md-6 ">
                  <span className="pull-right">
                    <span className="wrapper-float">
                      <span className="article__status">
                        <b>Status:</b>
                        <span className={"m-l-4 status__color disp-unset "+this.state.status.toLowerCase()}>
                          {this.state.status}
                        </span>
                      </span>
                    </span>
                  </span>
                </div>
              </div>
            </div>
          </div>
          {/* <span className="page-header">
            <span className="article__title"><h3> <strong>{this.state.title}</strong></h3></span><span><span className="pull-right article__status"> <b>Status:</b><span className=" pull-right m-l-4 status__color">{this.state.status}</span></span><a className="btn btn-outline-info pull-right m-r-20" href="#">Back</a></span>
          </span> */}
          <div className="container-fluid">
            <div className="row">
              <div className="view-container" id="create-form">
                <div className="row">
                  <div className="col">
                    <p>
                      <strong>Language</strong>
                    </p>
                    <p className="capitalize">{this.state.language}</p>
                  </div>
                  <div className="col">
                    <p>
                      <strong>Category</strong>
                    </p>
                    <p className="capitalize">{this.state.category}</p>
                  </div>
                  <div className="col">
                    <p>
                      <strong>Sub Category</strong>
                    </p>
                    <p className="capitalize">{this.state.subcategory}</p>
                  </div>
                  <div className="col">
                    <p>
                      <strong>Location</strong>
                    </p>
                    <p className="capitalize">{this.state.location}</p>
                  </div>
                  <div className="col-12 b-word">
                    <p>
                      <strong>Article Title</strong>
                    </p>
                    <p className="capitalize">{this.state.title}</p>
                  </div>

                  <div className="col-12 b-word">
                    <p>
                      <strong>Article</strong>
                    </p>
                    <p
                      dangerouslySetInnerHTML={{
                        __html: this.state.articledescription
                      }}
                    />
                  </div>
                  <div className="col-12">
                    <p>
                      <strong>Keywords</strong>
                    </p>
                    <p>
                      {this.state.articlekeywordsSet.map((Tags, index) => (
                        <span
                          key={index}
                          className="badge badge-pill article-tags-files"
                        >
                          {Tags.keywords.keyword}
                        </span>
                      ))}
                    </p>
                  </div>
    <div className="col-12">
                    <p>
                      <strong>Attached Files</strong>
                    </p>
                    <p>
                      {this.state.files.map((files, index) => (
                        <span
                          key={index}
                          className="badge badge-pill article-tags-files"
                        >
                          {files}
                        </span>
                      ))}
                    </p>
                  </div>
                   {!isReporter && (

                              <div className="form-group col-md-12">
                         
                          <label htmlFor="article">Comments</label>

                          <textarea className="form-control" name="comment" value={this.state.comment} onChange={this.handleComment}></textarea>
                        </div>

                          )}
                  <div className="col-12">
                    
                  <p>
                  <strong>{this.state.historyHeadline}</strong>
                    </p>
                    <p>
                      {
                       // this.state.comments
                        
                        this.state.comments.map((comments, index) => (
                        <p
                          key={index}
                          className=""
                        >
                      
                          <span>Comment By - </span>  
                          <span>{
                            comments.commentBy
                            //console.log(comments.comment)
                           //comments.date
                           
                            } </span>
                            <span>Comment On </span>
                            <span>
                            
                              {moment( comments.date).format('LLLL')}
                             
                            </span>
                            <p>{comments.comment}</p>
                        </p>
                      ))}
                    </p>
                  </div>
                  <div className="col-12 m-b-20">
                  {(() => {
                               let status =
                                this.state.status;
                              let userRole = UserInfo().group;
                              let ownArticle = false;
                              if (userEmail === this.state.email) {
                                ownArticle = true;
                              }

                              if (
                                isReporter 
                              ) {
                                return null;
                              } else if (
                                userRole === "Content Editor" && (ownArticle || status === "PUBLISHED" )   
                              ) {
                                return null;
                              } else if (
                                userRole === "Publisher" && ownArticle   
                              ) {
                                return null;
                              } else {
                                return (

                                   <button
                      type="button"
                      className="btn btn-outline-info pull-left"
                      onClick={this.handleReject}
                    >
                      Reject
                    </button>
                                );
                              }
                            })()}
                   

                      {(() => {
                              let status =
                                this.state.status;
                              let userRole = UserInfo().group;
                              let ownArticle = false;
                              if (userEmail === this.state.email) {
                                ownArticle = true;
                              }

                              let lockStatus = this.state.lockstatus;

                              if (lockStatus) {
                                return null;
                              }

                              if (
                                isReporter &&
                                (status === "PENDING" ||
                                  status === "REJECTED" ||
                                  status === "PUBLISHED")
                              ) {
                                return null;
                              } else if (
                                userRole === "Content Editor" &&
                                ((ownArticle &&
                                  (status === "PENDING" ||
                                    status === "REJECTED" ||
                                    status === "PUBLISHED")) ||
                                  (!ownArticle &&
                                    (status === "REJECTED" ||
                                      status === "PUBLISHED" || 
                                      status === "REWORK")))
                              ) {
                                return null;
                              } else if (
                                userRole === "Publisher" &&
                                ((ownArticle &&
                                  (status === "PENDING" ||
                                    status === "REJECTED" ||
                                    status === "PUBLISHED")) ||
                                  (!ownArticle &&
                                    (status === "REWORK")))
                              ) {
                                return null;
                              } else {
                                return (

                                   <button
                      type="button"
                      className="btn btn-outline-info pull-right m-r-20"
                    >
                      <a
                                    href={`/edit/${this.state.articleType.toLowerCase()}/${
                                      this.state.articleId
                                    }`}
                                    className=""
                                  >
                                    Edit
                            
                                  </a>
                    </button>
                                );
                              }
                            })()}
                    {/* <button type="button" className=" publishbutton btn btn-outline-info pull-right m-r-20 " onClick={this.handlePublish}>Publish</button> */}
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* </div> */}
        </div>
      </div>
    );
  }
}

const AttachedFiles = files => {
  return (
    <div className="attachmentsContainer">
      {files.files.map((attachments, index) => (
        <span key={index} className="attachmentContent">
          <a href={attachments} download>
            {getFilename(attachments)}
          </a>
          <i className="fa fa-times-circle-o"></i>
        </span>
      ))}
    </div>
  );
};

function getFilename(url) {
  return url.substring(url.lastIndexOf("/") + 1);
}

ArticleContent = graphql(mutation)(ArticleContent);

// export default compose(
//   graphql(mutateupdateArticle, { name: "editarticlebystatusmutate" }),
// )(ViewArticle);
