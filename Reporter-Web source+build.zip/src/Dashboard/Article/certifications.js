import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import { UserInfo } from '../App/UserInfo';

import Select from 'react-select';




  var CertOptions = [
{value: "UA",label: "UA"},
{value: "U",label: "U"},
{value: "A",label: "A"},
];




class MovieCertifications extends React.Component{
    
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
         if(this.props.currentCertification){
             this.state = {selectedOption: this.props.currentCertification};
        }

        else {

            this.state = {selectedOption: null};
        }
      }
    
      handleChange = (selectedOption) => {
         let val = selectedOption.value;
        this.setState({ selectedOption: val });
        this.props.onCertificationChange(selectedOption.value)
      }

    
    
       render() {
        const { selectedOption } = this.state;
        var selectedValue;
          if(selectedOption != null){

            selectedValue = {value: selectedOption, label: selectedOption};
          }

          else {

            selectedValue = selectedOption;
          }

        return(
        
 <Select
            value={selectedValue}
            onChange={this.handleChange}
            options={CertOptions}
          />
         

           );
               
         
       }
        
    }

    export default MovieCertifications;