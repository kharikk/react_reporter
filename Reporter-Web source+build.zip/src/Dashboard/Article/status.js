import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import { UserInfo } from '../App/UserInfo';

import Select from 'react-select';


if(UserInfo().group === "Content Editor"){

  var StatusOptions = [
{value: "Pending",label: "Pending"},
{value: "Rework",label: "Rework"},
{value: "Rejected",label: "Reject"},
];

}

else {

    var StatusOptions = [
{value: "Pending",label: "Pending"},
{value: "Published",label: "Publish"},
{value: "Rework",label: "Rework"},
{value: "Rejected",label: "Reject"},
];

}








class ArticleStatus extends React.Component{
    
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
         if(this.props.currentArticleStatus){
             this.state = {selectedOption: this.props.currentArticleStatus};
        }

        else {

            this.state = {selectedOption: null};
        }
      }
    
      handleChange = (selectedOption) => {
         let val = selectedOption.value;
        this.setState({ selectedOption: val });
        this.props.onStatusChange(selectedOption.value)
      }

    
    
       render() {
        const { selectedOption } = this.state;
        var selectedValue;
          if(selectedOption != null){

            selectedValue = {value: selectedOption, label: selectedOption};
          }

          else {

            selectedValue = selectedOption;
          }

        return(
        
 <Select
            value={selectedValue}
            onChange={this.handleChange}
            options={StatusOptions}
          />
         

           );
               
         
       }
        
    }

    export default ArticleStatus;