import React, { Component } from "react";
import gql from "graphql-tag";
import { graphql, compose } from "react-apollo";
import CreatableSelect from "react-select";
import { EditorState } from "draft-js";
import Input from "../Input";
import SubCategoryByCategory from "./subcategory";
import Category from "./categories";
import Languages from "./languages";
import ClassicEditor from "ckeditor5-custom-doped";
import HeaderDashboard from "../App/HeaderDashboard";
import StatusBar from "../App/StatusBar";
import { toast } from "react-toastify";
import axios from "axios";
import { Spinner } from "../Spinner";
import { FilePond, registerPlugin } from "react-filepond";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";
import FilePondPluginMediaPreview from "filepond-plugin-media-preview";
import FilePondPluginImageOverlay from "filepond-plugin-image-overlay";
import FilePondPluginGetFile from "filepond-plugin-get-file";
import customUploadAdapter from "./uploadAdapter";
import AmazonS3URI from "amazon-s3-uri";
import Modal from "react-responsive-modal";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";
import "filepond-plugin-media-preview/dist/filepond-plugin-media-preview.css";
import "filepond-plugin-image-overlay/dist/filepond-plugin-image-overlay.css";
import "filepond-plugin-get-file/dist/filepond-plugin-get-file.css";
import "../admin.css";

var token = window.localStorage.getItem("token");
var fileSet = [];
registerPlugin(
  FilePondPluginImagePreview,
  FilePondPluginMediaPreview,
  FilePondPluginGetFile,
  FilePondPluginImageOverlay
);

const uploadQuery = "mutation{ uploadFiles(upload: Uplod){ result message }}";

const mutation = gql`
  mutation CreateNewArticle($data: ArticleInput!, $token: String!) {
    createArticle(articleData: $data, token: $token) {
      article {
        articletitle
      }
    }
  }
`;

const deleteMutation = gql`
  mutation deleteAttachment(
    $bucket: String!
    $filePath: String!
    $fullPath: String!
    $token: String!
  ) {
    deleteAttachment(
      bucket: $bucket
      filePath: $filePath
      fullPath: $fullPath
      token: $token
    ) {
      deleteAttachment {
        status
        message
      }
    }
  }
`;

const components = {
  DropdownIndicator: null
};

const createKeywordOption = (label: string) => ({
  label,
  value: label
});

class CKEditor extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  bindChangeEvent = (editor, document) => {
    document.on("change", () => {
      if (document.differ.getChanges().length > 0) {
        this.props.onChange(editor.getData());
      }
    });
  };

  componentDidMount() {
    ClassicEditor.create(document.querySelector("#editor"), {
      extraPlugins: [customUploadAdapter],
      image: {
        // You need to configure the image toolbar, too, so it uses the new style buttons.
        toolbar: [
          "imageTextAlternative",
          "|",
          "imageStyle:alignLeft",
          "imageStyle:full",
          "imageStyle:alignRight"
        ],

        styles: [
          // This option is equal to a situation where no style is applied.
          "full",

          // This represents an image aligned to the left.
          "alignLeft",

          // This represents an image aligned to the right.
          "alignRight"
        ]
      }
    })
      .then(editor => {
        editor.setData(this.props.data);
        this.bindChangeEvent(editor, editor.model.document);
      })
      .catch(error => {
        console.error(error);
      });
  }

  render() {
    return <div id={"editor"}></div>;
  }
}

export default class CreateArticle extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      title: "",
      location: "",
      category: "",
      subcategory: "",
      language: "",
      inputValue: "",
      editordata: "",
      featuredImage: "http://lorempixel.com/1920/1080/business/",
      uploadFile: "",
      loaded: 0,
      status: "Pending",
      value: [],
      Files: [],
      showSpinner: false,
      isOpen: false,
      editorState: EditorState.createEmpty()
    };

    this.handleCategoryChange = this.handleCategoryChange.bind(this);
    this.handleSubcategoriesChange = this.handleSubcategoriesChange.bind(this);
    this.handleLanguages = this.handleLanguages.bind(this);
    this.handleFilesChange = this.handleFilesChange.bind(this);
    this.handleEditorData = this.handleEditorData.bind(this);
    this.handleTitleChange = this.handleTitleChange.bind(this);
    this.handleLocation = this.handleLocation.bind(this);
    this.onFileUpload = this.onFileUpload.bind(this);
    this.handleValidation = this.handleValidation.bind(this);
  }

  handleEditorData(data) {
    this.setState({ editordata: data });
  }

  handleCategoryChange(category) {
    this.setState({ category: category });
  }
  handleSubcategoriesChange(subcategory) {
    this.setState({ subcategory: subcategory });
  }
  handleLanguages(language) {
    this.setState({ language: language });
  }

  handleLocation(e) {
    this.setState({ location: e.target.value });
    console.log(this.state.location);
  }

  handleTitleChange(e) {
    this.setState({ title: e.target.value });
  }

  handleFilesChange(Files) {
    this.setState({ Files });
  }

  onFileUpload(event) {
    this.setState({
      uploadFile: event.target.files[0],
      loaded: 0
    });
  }

  onOpenModal = () => {
    this.setState({ isOpen: true });
  };

  onCloseModal = () => {
    this.setState({ isOpen: false });
  };

  onClickHandler = () => {
    if (!this.state.uploadFile) {
      toast.error("Please select a file to upload");
      return false;
    }

    const data = new FormData();
    data.append("upload", this.state.uploadFile);
    data.append("query", uploadQuery);
    axios
      .post(process.env.REACT_APP_GRAPHQL_URL, data, {
        onUploadProgress: p => {
          this.setState({ showSpinner: true });
        }
      })
      .then(res => {
        console.log(res.data.data.uploadFiles.result);

        this.setState(
          { featuredImage: res.data.data.uploadFiles.result },
          () => {
            this.setState({ showSpinner: false });
          }
        );
      })
      .catch(err => {
        toast.error("Upload failed");
        this.setState({ showSpinner: false });
      });
  };

  handleChange = (value: any, actionMeta: any) => {
    this.setState({ value });
  };

  handleSave = () => {
    this.setState({ status: "Draft" }, () => {
      this.handleSubmit();
    });
  };

  handleInputChange = (newValue: String) => {
    const inputValue = newValue;

    this.setState({ inputValue });
  };

  handleKeyDown = (event: SyntheticKeyboardEvent<HTMLElement>) => {
    const { inputValue, value } = this.state;
    if (value && value.length >= 10) {
      return;
    } else {
      if (!inputValue) return;

      switch (event.key) {
        case "Enter":
        case "Tab":
          if (value != null) {
            if (!this.state.value.find(x => x.value === inputValue)) {
              this.setState({
                inputValue: "",
                value: [...value, createKeywordOption(inputValue)]
              });
            }
          } else {
            this.setState({
              inputValue: "",
              value: [createKeywordOption(inputValue)]
            });
          }
          event.preventDefault();
          break;
        default:
      }
    }
  };

  handleValidation = () => {

    if(!this.state.title || this.state.title.length < 10){
        toast.error("Article title should be of atleast 10 characters");
    }

    else  if(!this.state.featuredImage){
        toast.error("Please upload a featured image");
    }

    else if(!this.state.editordata){
        toast.error("Article description should not blank");
    }

    else  if(this.state.value < 1){
        toast.error("Please enter atleast one tag for the article");
    }

    else{

      this.handleSubmit();
    }
  }

  handleSubmit = async () => {
    var articleData = {};

    articleData["keywords"] = "";

    articleData["title"] = this.state.title;
    articleData["category"] = this.state.category;
    articleData["subcategory"] = this.state.subcategory;
    articleData["body"] = this.state.editordata;
    articleData["language"] = this.state.language;
    articleData["location"] = this.state.location;
    articleData["status"] = this.state.status;
    articleData["featuredimage"] = this.state.featuredImage;

    for (let i = 0; i < this.state.value.length; i++) {
      let c = ",";
      if (i === this.state.value.length - 1) {
        c = "";
      }

      articleData["keywords"] += this.state.value[i].label + c;
    }

    articleData["files"] = fileSet;

    console.log(articleData);

    try {
      const response = await this.props.createarticlemutation({
        variables: { data: articleData, token: token }
      });
      console.log(response);

      if (response.data) {
        toast.success("Article Created Successfully");
        setTimeout(function() {
          window.location.href = "/Dashboard";
        }, 3000);
      }
    } catch (error) {
      console.log(error);
      toast.error(error.graphQLErrors[0].message);
    }
  };

  render() {
    const category = this.state.category;
    const subcategory = this.state.subcategory;
    const language = this.state.language;

    //const {  } = this.state;
    // const { editorState } = this.state;
    const { inputValue, value } = this.state;

    return (
      <div className="container-fluid no-padding">
        <div className="row no-margin">
          <HeaderDashboard />

          <div className="main-content" id="tglmcdisplay">
            <StatusBar />
            <span className="page-header">
              <span className="article-header">Create Article</span>
            </span>
            <div className="row no-margin" id="main">
              <div className="col-sm-12 col-md-12 well" id="content">
                <div className="container-fluid">
                  <div className="row">
                    <form className="articleForm form-border" id="create-form">
                      <div className="form-row">
                        <div className="form-group col-md-3">
                          <label htmlFor="language">Language</label>
                          <Languages onLanguageChange={this.handleLanguages} />
                        </div>
                        <div className="form-group col-md-3">
                          <label htmlFor="category">Category</label>
                          <Category
                            onCategoryChange={this.handleCategoryChange}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label htmlFor="subcategory">Sub Category</label>
                          <SubCategoryByCategory
                            categoryname={category}
                            onSubCategoryChange={this.handleSubcategoriesChange}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label htmlFor="location">Location</label>
                          <Input
                            type="text"
                            onChange={this.handleLocation}
                            name="location"
                          />
                        </div>
                        <div className="form-group col-md-12">
                          <label htmlFor="title">Article Title</label>
                          <input
                            type="text"
                            className="form-control"
                            onChange={this.handleTitleChange}
                            value={this.title}
                            id="title"
                            maxLength={100}
                          />
                        </div>
                        <div className="form-group col-md-12">
                          <label htmlFor="title">Featured Image</label>
                          <div className="new-block spinner-container">
                            <input
                              type="file"
                              accept="image/*"
                              name="featuredimage"
                              className="file-form-control"
                              onChange={this.onFileUpload}
                            />
                            <button
                              type="button"
                              className="btn btn-outline-info"
                              onClick={this.onClickHandler}
                            >
                              Upload{" "}
                              {this.state.showSpinner ? <Spinner /> : null}
                            </button>
                          </div>
                          <div className="featured-image dash-image">
                            <img src={this.state.featuredImage} alt="" />
                          </div>
                        </div>

                        <div className="form-group col-md-12 article">
                          <label htmlFor="article">Article</label>
                          {/* <textarea rows="10" type="text" className="form-control" id="article" /> */}
                          <div>
                            <CKEditor
                              data=""
                              onChange={this.handleEditorData}
                            />
                          </div>
                        </div>
                        <div className="form-group col-md-12">
                          <label htmlFor="tags">
                            Tags{" "}
                            <span className="keywordSpan">(Upto 10 tags)</span>
                          </label>
                          <CreatableSelect
                            components={components}
                            inputValue={inputValue}
                            isClearable
                            isMulti
                            menuIsOpen={false}
                            onChange={this.handleChange}
                            onInputChange={this.handleInputChange}
                            onKeyDown={this.handleKeyDown}
                            placeholder="Enter tags and press enter..."
                            value={value}
                          />
                        </div>

                        <div className="form-group col-md-12">
                          <FilePond
                            allowMultiple={true}
                            server={{
                              load: (
                                source,
                                load,
                                error,
                                progress,
                                abort,
                                headers
                              ) => {
                                var myRequest = new Request(source);
                                fetch(myRequest).then(function(response) {
                                  response.blob().then(function(myBlob) {
                                    console.log(myBlob);
                                    load(myBlob);
                                  });
                                });
                              },
                              process: (
                                fieldName,
                                file,
                                metadata,
                                load,
                                error,
                                progress,
                                abort
                              ) => {
                                // fieldName is the name of the input field
                                // file is the actual file object to send

                                const formData = new FormData();
                                formData.append("upload", file);
                                formData.append("query", uploadQuery);

                                const request = new XMLHttpRequest();
                                request.open(
                                  "POST",
                                  process.env.REACT_APP_GRAPHQL_URL
                                );
                                request.responseType = "json";

                                // Should call the progress method to update the progress to 100% before calling load
                                // Setting computable to false switches the loading indicator to infinite mode
                                request.upload.onprogress = e => {
                                  progress(
                                    e.lengthComputable,
                                    e.loaded,
                                    e.total
                                  );
                                };

                                // Should call the load method when done and pass the returned server file id
                                // this server file id is then used later on when reverting or restoring a file
                                // so your server knows which file to return without exposing that info to the client
                                request.onload = function() {
                                  if (
                                    request.status >= 200 &&
                                    request.status < 300
                                  ) {
                                    // the load method accepts either a string (id) or an object
                                    load(
                                      request.response.data.uploadFiles.result
                                    );

                                    fileSet.push(
                                      request.response.data.uploadFiles.result
                                    );
                                  } else {
                                    // Can call the error method if something is wrong, should exit after
                                    error("oh no");
                                  }
                                };

                                request.send(formData);

                                // Should expose an abort method so the request can be cancelled
                                return {
                                  abort: () => {
                                    // This function is entered if the user has tapped the cancel button
                                    request.abort();

                                    // Let FilePond know the request has been cancelled
                                    abort();
                                  }
                                };
                              },

                              revert: async (source, load, error) => {
                                const { bucket, key } = AmazonS3URI(source);

                                try {
                                  const response = await this.props.deletemutation(
                                    {
                                      variables: {
                                        bucket: bucket,
                                        filePath: key,
                                        fullPath: source,
                                        token: token
                                      }
                                    }
                                  );

                                  if (response.data) {
                                    fileSet = fileSet.filter(function(
                                      value,
                                      index,
                                      arr
                                    ) {
                                      return value !== source;
                                    });

                                    this.setState({ Files: fileSet });
                                  }
                                } catch (e) {
                                  console.log(e);
                                }

                                error();

                                load();
                              },

                              remove: async (source, load, error) => {
                                const { bucket, key } = AmazonS3URI(source);

                                try {
                                  const response = await this.props.deletemutation(
                                    {
                                      variables: {
                                        bucket: bucket,
                                        filePath: key,
                                        fullPath: source,
                                        token: token,
                                        articleId: this.state.articleId
                                      }
                                    }
                                  );

                                  if (response.data) {
                                    fileSet = fileSet.filter(function(
                                      value,
                                      index,
                                      arr
                                    ) {
                                      return value !== source;
                                    });

                                    this.setState({ Files: fileSet });
                                  }
                                } catch (e) {
                                  console.log(e);
                                }

                                error();

                                load();
                              }
                            }}
                          />
                        </div>
                        <div className="form-group col-md-12 pull-right submit-controls">
                          <button
                            type="button"
                            id="submitClick"
                            className="btn btn-outline-info pull-right"
                            onClick={this.handleValidation}
                          >
                            Submit
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-info pull-right m-r-20"
                            onClick={this.handleSave}
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-info  m-r-20"
                            onClick={this.onOpenModal}
                            data-toggle="modal"
                            data-target="#loginModal"
                          >
                            Preview Article
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div className="row no-margin"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Modal open={this.state.isOpen} onClose={this.onCloseModal}>
          <div className="modal1" id="loginModal" tabindex="-1">
            <div className="modal-dialog">
              <div className="modal-content">
                <div className="modal-header">
                  <h4 className="modal-title">Preview Article</h4>
                </div>
                <div className="modal-body">
                 <p dangerouslySetInnerHTML={{ __html: this.state.editordata }} />

                </div>
                <div className="modal-foorter"></div>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    );
  }
}

CreateArticle = compose(
  graphql(mutation, { name: "createarticlemutation" }),
  graphql(deleteMutation, { name: "deletemutation" })
)(CreateArticle);
