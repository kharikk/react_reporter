import React, { Component } from "react";
import gql from "graphql-tag";
import { Query, graphql, Mutation } from "react-apollo";
import CreatableSelect from "react-select";
import { EditorState } from "draft-js";
import ArticleSection from "./sections";
import Input from "../Input";
import ClassicEditor from "ckeditor5-custom-doped";
import ArticleStatus from "./status";
import TimeField from "react-simple-timefield";
import MovieCertifications from "./certifications";
import HeaderDashboard from "../App/HeaderDashboard";
import StatusBar from "../App/StatusBar";
import { UserInfo } from "../App/UserInfo";
import axios from "axios";
import { Spinner } from "../Spinner";
import { toast } from "react-toastify";
import customUploadAdapter from "./uploadAdapter";
import moment from  'moment';
import DatePicker from "react-datepicker";
import "../admin.css";
var token1 = window.localStorage.getItem("token");

const uploadQuery = "mutation{ uploadFiles(upload: Uplod){ result message fileId }}";
var commentsArr = [];
const GET_ARTICLE = gql`
  query GetArticle($articleid: ID!, $token1: String!) {
    getDashboardArticles(articleId: $articleid, token: $token1) {
      id
      articletitle
      articledescription
      article{
        id
        slug
        articleeditedbySet{
        
          commentsSet{
            comment
            modifiedAt
            commentby{
              editor{
                username
                
              }
              role
            }
          }
        }
      user {
        username
      }
      articlestatusSet {
        statusname
      }
    }
      location
      movieSet {
        cast
        producer
        certification
        duration
        releasedate
        musicdirector
        director
        rating
        review
        language
      }
      articlekeywordsSet {
        keywords {
          keyword
        }
      }
      featuredImage
    }
  }
`;

const mutation = gql`
  mutation UpdateMovieReview($articleData: UpdateMovieInput!, $token1: String!) {
    updateMovie(articleData: $articleData, token: $token1) {
      article {
        articletitle
      }
    }
  }
`;

const components = {
  DropdownIndicator: null
};

const createKeywordOption = (label: string) => ({
  label,
  value: label
});

class StoryEditor extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  bindChangeEvent = (editor, document) => {
    document.on("change", () => {
      if (document.differ.getChanges().length > 0) {
        this.props.onChange(editor.getData());
      }
    });
  };

  componentDidMount() {
    ClassicEditor.create(document.querySelector("#story"), {
     extraPlugins: [customUploadAdapter],
       image: {
            // You need to configure the image toolbar, too, so it uses the new style buttons.
            toolbar: [ 'imageTextAlternative', '|', 'imageStyle:alignLeft', 'imageStyle:full', 'imageStyle:alignRight' ],

            styles: [
                // This option is equal to a situation where no style is applied.
                'full',

                // This represents an image aligned to the left.
                'alignLeft',

                // This represents an image aligned to the right.
                'alignRight'
            ]
        }
    })
      .then(editor => {
        editor.setData(this.props.data);
        this.bindChangeEvent(editor, editor.model.document);
      })
      .catch(error => {
        console.error(error);
      });
  }

  render() {
    return <div id={"story"}></div>;
  }
}

class ReviewEditor extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  bindChangeEvent = (editor, document) => {
    document.on("change", () => {
      if (document.differ.getChanges().length > 0) {
        this.props.onChange(editor.getData());
      }
    });
  };

  componentDidMount() {
    ClassicEditor.create(document.querySelector("#review"), {
      extraPlugins: [customUploadAdapter],
       image: {
            // You need to configure the image toolbar, too, so it uses the new style buttons.
            toolbar: [ 'imageTextAlternative', '|', 'imageStyle:alignLeft', 'imageStyle:full', 'imageStyle:alignRight' ],

            styles: [
                // This option is equal to a situation where no style is applied.
                'full',

                // This represents an image aligned to the left.
                'alignLeft',

                // This represents an image aligned to the right.
                'alignRight'
            ]
        }
    })
      .then(editor => {
        editor.setData(this.props.data);
        this.bindChangeEvent(editor, editor.model.document);
      })
      .catch(error => {
        console.error(error);
      });
  }

  render() {
    return <div id={"review"}></div>;
  }
}

class FormComponent extends Component {
  constructor(props) {
    super(props);

    var keywordslist = [];
    for (
      var j = 0;
      j < this.props.articleDetails.articlekeywordsSet.length;
      j++
    ) {
      keywordslist.push({
        value: this.props.articleDetails.articlekeywordsSet[j].keywords.keyword,
        label: this.props.articleDetails.articlekeywordsSet[j].keywords.keyword
      });
    }

    this.state = {
      movieId: this.props.articleDetails.article.id,
      title: this.props.articleDetails.articletitle,
      category: "Movie",
      subcategory: "Movie Reviews",
      rating: this.props.articleDetails.movieSet[0].rating,
      cast: this.props.articleDetails.movieSet[0].cast,
      releasedate: moment(this.props.articleDetails.movieSet[0].releasedate).toDate(),
      duration: this.props.articleDetails.movieSet[0].duration,
      mdirector: this.props.articleDetails.movieSet[0].musicdirector,
      producer: this.props.articleDetails.movieSet[0].producer,
      director: this.props.articleDetails.movieSet[0].director,
      story: this.props.articleDetails.articledescription,
      review: this.props.articleDetails.movieSet[0].review,
      certification: this.props.articleDetails.movieSet[0].certification,
      language: this.props.articleDetails.movieSet[0].language,
      inputValue: "",
      featuredImage: this.props.articleDetails.featuredImage,
      uploadFile: "",
      loaded: 0,
      status: this.props.articleDetails.article.articlestatusSet[0].statusname,
      value: keywordslist,
      Files: [],
      isPublisher: false,
      isEditor: false,
      notReporter: false,
      isVerified: false,
      uploadFile: "",
      time: "00:00",
      comments: [],
      historyHeadline:"",
      comment:'',
      editorState: EditorState.createEmpty()
    };
    this.handleCategoryChange = this.handleCategoryChange.bind(this);
    this.handleSubcategoriesChange = this.handleSubcategoriesChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleStatus = this.handleStatus.bind(this);

    this.handleFilesChange = this.handleFilesChange.bind(this);

    this.onFileUpload = this.onFileUpload.bind(this);
    this.handleStoryData = this.handleStoryData.bind(this);
    this.handleCertification = this.handleCertification.bind(this);
    this.handleReviewData = this.handleReviewData.bind(this);
    this.onDurationChange = this.onDurationChange.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
    this.handleComment = this.handleComment.bind(this);
  }

  componentDidMount() {
    var num = this.state.duration.match(/\d+/g);
      var time = num[0]+":"+num[1];

      this.setState({ time: time });

    var fileSet = [];
    if (UserInfo().group === "Content Editor") {
      this.setState({ isEditor: true });
      this.setState({ notReporter: true });
    }

    if (UserInfo().group === "Publisher") {
      this.setState({ isPublisher: true });
      this.setState({ notReporter: true });
    }

    if (UserInfo().verified === "true") {
      this.setState({ isVerified: true });
    }

    if(this.props.articleDetails.article.articleeditedbySet.length > 0 ){
  
      for (let i = 0; i < this.props.articleDetails.article.articleeditedbySet.length; i++) {



        if(this.props.articleDetails.article.articleeditedbySet[i].commentsSet.length > 0){
            commentsArr.push({
          comment: this.props.articleDetails.article.articleeditedbySet[i].commentsSet[0].comment,
          commentBy: this.props.articleDetails.article.articleeditedbySet[i].commentsSet[0].commentby.editor.username,
          date: this.props.articleDetails.article.articleeditedbySet[i].commentsSet[0].modifiedAt,
          role: this.props.articleDetails.article.articleeditedbySet[i].commentsSet[0].role
        });

        }
         
        
        this.setState({historyHeadline:"Comments History"})

        
      }

    }
    
    this.setState({ comments: commentsArr })

    this.setState({ Files: fileSet });

      if (
      UserInfo().group === "Reporter"
    ) {
      this.setState({ status: "Pending" });
    }

    // console.log(fileSet);
  }

  isOptionUnique(prop) {
    const { option, options, valueKey, labelKey } = prop;
    return !options.find(opt => option[valueKey] === opt[valueKey]);
  }

  handleCategoryChange(category) {
    this.setState({ category: category });
  }
  handleSubcategoriesChange(subcategory) {
    this.setState({ subcategory: subcategory });
  }

  handleStatus(status) {
    this.setState({ status: status });
  }

  handleStoryData(data) {
    this.setState({ story: data });
  }

  handleReviewData(data) {
    this.setState({ review: data });
  }

  handleCertification(certification) {
    this.setState({ certification: certification });
  }

  handleFilesChange(Files) {
    this.setState({ Files });
  }

  onFileUpload(event) {
    this.setState({
      uploadFile: event.target.files[0],
      loaded: 0
    });
  }

  handleDateChange(date) {
    this.setState(
      {
        releasedate: date
      },
      () => {
        
      }
    );
  }


  handleComment(e) {

    this.setState({ comment: e.target.value });
  }

 onDurationChange(time) {
    let splitTime = time.toString().split(":");
    let duration = splitTime[0] + " hr(s) " + splitTime[1] + " min(s)";

    this.setState({ duration }, () => {
    });
  }

  handleChange = (e) => {
    console.log(e);
    let field = e.target.name;
    this.setState({ [field]: e.target.value });
  };

  handleGenreChange = (value: any, actionMeta: any) => {
    this.setState({ value });
  };

   handleSave = () => {
    this.setState({ status: "Draft" }, () => {
      this.handleSubmit();
    });
  };

  onClickHandler = () => {

      if(!this.state.uploadFile){

      toast.error("Please select a file to upload");
      return false;
    }
     
                  
    const data = new FormData();
    data.append("upload", this.state.uploadFile);
    data.append("query", uploadQuery);
    axios
      .post(process.env.REACT_APP_GRAPHQL_URL, data,  {
        onUploadProgress: p => {
          this.setState({ showSpinner: true });
         
        }
      })
      .then(res => {
      
        console.log(res.data.data.uploadFiles.result);
       
        this.setState({ featuredImage: res.data.data.uploadFiles.result }, () => {
          this.setState({ showSpinner: false });
        
        });
      })
      .catch(err => {
        
        toast.error("Upload failed");
        this.setState({ showSpinner: false });
      });
  };

  handleInputChange = (newValue: String) => {
    const inputValue = newValue.replace(/\W/g, "");
    this.setState({ inputValue });
    return inputValue;
  };

  handleKeyDown = (event: SyntheticKeyboardEvent<HTMLElement>) => {
    const { inputValue, value } = this.state;
    if (value && value.length >= 10) {
      return;
    } else {
      if (!inputValue) return;

      switch (event.key) {
        case "Enter":
        case "Tab":
          if (value != null) {
            if (!this.state.value.find(x => x.value === inputValue)) {
              this.setState({
                inputValue: "",
                value: [...value, createKeywordOption(inputValue)]
              });
            }
          } else {
            this.setState({
              inputValue: "",
              value: [createKeywordOption(inputValue)]
            });
          }
          event.preventDefault();
          break;
        default:
      }
    }
  };

  handleInvalidSubmit = () => {
    toast.error(
      "Your account is not activated!. Please contact the site admin"
    );
  };

    handleValidation = () => {
    if (!this.state.title) {
      toast.error("Movie Title is required");
    } else if (!this.state.featuredImage) {
      toast.error("Please upload a featured image");
    } else if (!this.state.story) {
      toast.error("Story field is required");
    } else if (!this.state.review) {
      toast.error("Review field is required prov a review");
    } else if (!this.state.certification) {
      toast.error("Please select the certification");
    } else if(!parseFloat(this.state.rating)) {
      
      toast.error("Please enter a valid rating");
    } else if (!this.state.language) {
      toast.error("Please enter a Language");
    } else if (this.state.value < 1) {
      toast.error("Please enter atleast one genre");
    } else {
      this.handleSubmit();
    }
  };

  handleSubmit = async () => {
    var articleData = {};
    //articleData['keywords'] = this.state.value[0].label;

    articleData['keywords'] = "";

          articleData['movieId'] = this.state.movieId;
          articleData['title'] = this.state.title;
          articleData['category'] = "Movie";
          articleData['subcategory'] = "Movie Reviews";
          articleData['certification'] = this.state.certification;
          articleData['rating'] = this.state.rating;
          articleData['cast'] = this.state.cast;
          articleData['releasedate'] = moment(this.state.releasedate).format("YYYY-MM-DD");
          articleData['duration'] = this.state.duration;
          articleData['musicdirector'] = this.state.mdirector;
          articleData['producer'] = this.state.producer;
          articleData['review'] = this.state.review;
          articleData['director'] = this.state.director;
          articleData['story'] = this.state.story;
          articleData['language'] = this.state.language;
          articleData['status'] = this.state.status;
          articleData['featuredimage'] = this.state.featuredImage;
         // articleData["articleType"] = "review";
          // articleData['files'] =[""];
            for (let i = 0; i < this.state.value.length; i++) {
      let c = ",";
      if (i === this.state.value.length - 1) {
        c = "";
      }

      articleData["keywords"] += this.state.value[i].label + c;
    }

    if(this.state.comment.length > 0){

      articleData['comment'] = this.state.comment;
    }

    console.log(articleData);

    try {
      const response = await this.props.mutate({
        variables: { articleData: articleData, token1: token1 }
      });

      if (response.data) {
        toast.success("Success");
        setTimeout(function(){ window.location.href = "/Dashboard"; }, 3000);
        // this.notify('success','Article updated successfully');
      }
    } catch (error) {
      toast.error(error.graphQLErrors[0].message);
    }
  };

  render() {
    const { inputValue, value } = this.state;
    const isPublisher = this.state.isPublisher;
    const isEditor = this.state.isEditor;
    const notReporter = this.state.notReporter;
    const isVerified = this.state.isVerified;

    return (
      <div className="container-fluid no-padding">
        <div className="row no-margin">
          <HeaderDashboard />

          <div className="main-content" id="tglmcdisplay">
            <StatusBar />
            <span className="page-header">
              <span className="article-header">Edit Review</span>
            </span>
            <div className="row no-margin" id="main">
              <div className="col-sm-12 col-md-12 well" id="content">
                <div className="container-fluid">
                  <div className="row">
                    <form className="articleForm form-border" id="create-form">
                      <div className="form-row">
                        <div className="form-group col-md-12">
                          <label htmlFor="title">Movie Title</label>
                          <input
                            type="text"
                            className="form-control"
                            onChange={this.handleChange}
                            id="title"
                            name="title"
                            value={this.state.title}
                          />
                        </div>
                        <div className="form-group col-md-12 spinner-container">
                          <label htmlFor="title">Featured Image</label>
                          <div className="new-block">
                            <input
                              type="file"
                              accept="image/*"
                              name="featuredimage"
                              className="file-form-control"
                              onChange={this.onFileUpload}
                            />
                            <button
                              type="button"
                              className="btn btn-outline-info"
                              onClick={this.onClickHandler}
                            >
                              Upload {this.state.showSpinner ? <Spinner /> : null}
                            </button>
                          </div>
                          <div className="featured-image dash-image">
                            <img src={this.state.featuredImage} alt="" />
                          </div>
                        </div>
                        <div className="form-group col-md-12 story">
                          <label htmlFor="article">Story</label>

                          <div>
                            <StoryEditor
                              data={this.state.story}
                              onChange={this.handleStoryData}
                            />
                          </div>
                        </div>
                        <div className="form-group col-md-12 review">
                          <label htmlFor="article">Review</label>

                          <div>
                            <ReviewEditor
                              data={this.state.review}
                              onChange={this.handleReviewData}
                            />
                          </div>
                        </div>
                        <div className="form-group col-md-3">
                          <label>Certification</label>
                          <MovieCertifications
                            onCertificationChange={this.handleCertification}
                            currentCertification={this.state.certification}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Rating</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="rating"
                            value={this.state.rating}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Release Date(YYYY-MM-DD)</label>
                          <DatePicker
                            selected={this.state.releasedate}
                            onChange={this.handleDateChange}
                         
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Duration(hrs : mins)</label>
                          <TimeField
                            value={this.state.time}
                            onChange={this.onDurationChange}
                            style={{
                              display: "block",
                              width: "100%",
                              height: "calc(1.5em + 0.75rem + 2px)",
                              padding: "0.375rem 0.75rem",
                              fontSize: "1rem",
                              fontWeight: 400,
                              lineHeight: 1.5,
                              color: "#495057",
                              backgroundColor: "#fff",
                              backgroundClip: "padding-box",
                              border: "1px solid #ced4da",
                              borderRadius: "0.25rem",
                              transition:
                                "border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out"
                            }}
                          />
                        </div>

                        <div className="form-group col-md-3">
                          <label>Cast</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="cast"
                            value={this.state.cast}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Producer</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="producer"
                            value={this.state.producer}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Director</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="director"
                            value={this.state.director}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Music Director</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="mdirector"
                            value={this.state.mdirector}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Language</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="language"
                            value={this.state.language}
                          />
                        </div>
                        <div className="form-group col-md-9">
                          <label htmlFor="tags"> Genre</label>
                          <CreatableSelect
                            components={components}
                            inputValue={inputValue}
                            isClearable
                            isMulti
                            menuIsOpen={false}
                            onChange={this.handleGenreChange}
                            onInputChange={this.handleInputChange}
                            onKeyDown={this.handleKeyDown}
                            placeholder="Enter tags and press enter..."
                            value={value}
                          />
                        </div>
                         {notReporter && (
                          <div className="form-group col-md-4">
                            <label htmlFor="language">Status</label>
                            <ArticleStatus
                              onStatusChange={this.handleStatus}
                              currentArticleStatus={this.state.status}
                            />
                          </div>
                        )}

                          {notReporter && (

                              <div className="form-group col-md-12">
                         
                          <label htmlFor="article">Comments</label>

                          <textarea className="form-control" name="comment" value={this.state.comment} onChange={this.handleComment}></textarea>
                        </div>

                          )}
                         <div className="col-12">
                    
                    <p>
                        <strong>{this.state.historyHeadline}</strong>
                      </p>
                      <p>
                        {
                         // this.state.comments
                          
                          this.state.comments.map((comments, index) => (
                          <p
                            key={index}
                            className=""
                          >
                        
                            <span>Comment By - </span>  
                            <span>{
                              comments.commentBy
                              //console.log(comments.comment)
                             //comments.date
                             
                              } </span>
                              <span>Comment On </span>
                              <span>
                              
                                {moment( comments.date).format('LLLL')}
                               
                              </span>
                              <p>{comments.comment}</p>
                          </p>
                        ))}
                      </p>
                    </div>
                        <div className="form-group col-md-12 pull-right submit-controls">
                          <button
                            type="button"
                            id="submitClick"
                            className="btn btn-outline-info pull-right"
                            onClick={this.handleValidation}
                          >
                            Submit
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-info pull-right m-r-20"
                            onClick={this.handleSave}
                          >
                            Save
                          </button>
                       
                        </div>
                      </div>
                    </form>
                  </div>

                  <div className="row no-margin"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const AttachedFiles = files => {
  return (
    <div className="attachmentsContainer">
      {files.files.map((attachments, index) => (
        <span key={index} className="attachmentContent">
          <a href={attachments} download>
            {getFilename(attachments)}
          </a>
          <i className="fa fa-times-circle-o"></i>
        </span>
      ))}
    </div>
  );
};

function getFilename(url) {
  return url.substring(url.lastIndexOf("/") + 1);
}

class EditMovieReview extends Component {
  render() {
    let articleId = this.props.match.params.id;

    return (
      <Query
        query={GET_ARTICLE}
        variables={{ articleid: articleId, token1: token1 }}
      >
        {({ data, loading, error }) => {
          if (loading) return <div></div>;
          if (error) return <div></div>;
          if (data)
            console.log(data);
            return <FormComponent articleDetails={data.getDashboardArticles[0]} />;
        }}
      </Query>
    );
  }
}

export default EditMovieReview;

FormComponent = graphql(mutation)(FormComponent);
