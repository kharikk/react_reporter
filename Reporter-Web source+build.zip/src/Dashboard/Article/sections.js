import React, {Component} from 'react';
import Select from 'react-select';




    var SectionOptions = [
{value: "Top Stories",label: "Top Stories"},
{value: "In Focus",label: "In Focus"},
{value: "Photo Feature",label: "Photo Feature"},
{value: "Most Popular",label: "Most Popular"},
{value: "Tv & Movies",label: "Tv & Movies"},
{value: "Photos / Videos",label: "Photos / Videos"},
{value: "Business & Technology",label: "Business & Technology"},
{value: "Around the World",label: "Around the World"},
{value: "Astrology",label: "Astrology"},
{value: "Health & LifeStyle",label: "Health & LifeStyle"},
{value: "Travel & Religious",label: "Travel & Religious"},
{value: "General",label: "General"},


];










class ArticleSection extends Component{
    
    constructor(props) {
        super(props);
      
        this.handleChange = this.handleChange.bind(this);
         if(this.props.currentArticleSection){
             this.state = {selectedOption: this.props.currentArticleSection};
        }

        else {

            this.state = {selectedOption: null};
        }
      }
    
      handleChange = (selectedOption) => {
         let val = selectedOption.value;
        this.setState({ selectedOption: val });
        this.props.onSectionChange(selectedOption.value)
      }

    
    
       render() {
        const { selectedOption } = this.state;
        var selectedValue;
          if(selectedOption != null){

            selectedValue = {value: selectedOption, label: selectedOption};
          }

          else {

            selectedValue = selectedOption;
          }

         

        return(
        
 <Select
            value={selectedValue}
            onChange={this.handleChange}
            options={SectionOptions}
          />
         

           );
               
         
       }
        
    }

    export default ArticleSection;