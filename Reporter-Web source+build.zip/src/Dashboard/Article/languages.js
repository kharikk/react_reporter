import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';

import Select from 'react-select';

const LANGUAGES= gql`
query Languages{
    getLanguages{
      languagename
      id
    }
  }
`;




let LanguageOptions = [];





class Languages extends React.Component{
    
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);

        if(this.props.currentLanguage){
             this.state = {selectedOption: this.props.currentLanguage};
        }

        else {

            this.state = {selectedOption: null};
        }
       
      }
    
      handleChange = (selectedOption) => {
        let val = selectedOption.value;
        this.setState({ selectedOption: val });
        this.props.onLanguageChange(selectedOption.value)
      }
    
       render() {
        const { selectedOption } = this.state;
        return(
    
     <Query query={LANGUAGES}  >
        
          
    
         {({ loading, error, data }) => {
         
              if (loading) return  <Select
              value={selectedOption}
              onChange={this.handleChange}
              options={LanguageOptions}
            />
              if (error) return <div>Error Loading Data</div>
        
          
          LanguageOptions = [];


        
          if(data.getLanguages!=null){
          for(var i = 0; i< data.getLanguages.length; i++){
    
            LanguageOptions.push({
                value: data.getLanguages[i].languagename, 
                label:  data.getLanguages[i].languagename
            });
          }
       
          var selectedValue;
          if(selectedOption != null){

            selectedValue = {value: selectedOption, label: selectedOption};
          }

          else {

            selectedValue = selectedOption;
          }
        }
              return (
                 
               <Select
            value={selectedValue}
            onChange={this.handleChange}
            options={LanguageOptions}
          />
            
              );
            }}
      </Query>
          );
       }
        
    }

    export default Languages;