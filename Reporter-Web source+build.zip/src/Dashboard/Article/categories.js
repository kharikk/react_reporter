import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
 
import Select from 'react-select';
const GET_SUB_BY_CATEGORY= gql`
query Categories($isGallery: Boolean!){
    getCategories(isGallery: $isGallery){
    categoryname
    id
    isGallery
  }
  }
`;





let CategoryOptions = [];
var isGallery = false;

class Categories extends React.Component{
    
constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);

    if(this.props.currentCategory){
             this.state = {selectedOption: this.props.currentCategory};
        }

        else {

            this.state = {selectedOption: null};
        }

        if(this.props.type === "gallery"){

          isGallery = true;
        }
  }

  handleChange = (selectedOption) => {
    
     let val = selectedOption.value;
        this.setState({ selectedOption: val });
    this.props.onCategoryChange(selectedOption.value)
  
  }

   render() {
    const { selectedOption } = this.state;
    return(

 <Query query={GET_SUB_BY_CATEGORY} variables={{isGallery: isGallery}} >
    
      

     {({ loading, error, data }) => {
          if (loading) return <div></div>
          if (error) return <div>Error Loading Data</div>
    
      
      CategoryOptions = [];
      for(var i = 0; i< data.getCategories.length; i++){

        CategoryOptions.push({
            value: data.getCategories[i].categoryname, 
            label:  data.getCategories[i].categoryname
        });
      }

       var selectedValue;
          if(selectedOption != null){

            selectedValue = {value: selectedOption, label: selectedOption};
          }

          else {

            selectedValue = selectedOption;
          }

          return (
              <div>
           <Select
        value={selectedValue}
        onChange={this.handleChange}
        options={CategoryOptions}
      />
        </div>
          );
        }}
  </Query>
      );
   }
  
  
  

}

export default Categories;