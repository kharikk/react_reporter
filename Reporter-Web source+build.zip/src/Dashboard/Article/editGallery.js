import React, { Component } from "react";
import gql from "graphql-tag";
import { Query, graphql, Mutation, compose } from "react-apollo";
import CreatableSelect from "react-select";
import { EditorState } from "draft-js";
import ArticleSection from "./sections";
import Input from "../Input";
import SubCategoryByCategory from "./subcategory";
import Category from "./categories";
import Languages from "./languages";
import ClassicEditor from "ckeditor5-custom-doped";
import ArticleStatus from "./status";
import HeaderDashboard from "../App/HeaderDashboard";
import StatusBar from "../App/StatusBar";
import { UserInfo } from "../App/UserInfo";
import { PageLoader } from "../../PageLoader";
import axios from "axios";
import { Spinner } from "../Spinner";
import { FilePond, registerPlugin } from "react-filepond";
import FilePondPluginImagePreview from "filepond-plugin-image-preview";
import FilePondPluginMediaPreview from "filepond-plugin-media-preview";
import FilePondPluginImageOverlay from "filepond-plugin-image-overlay";
import FilePondPluginGetFile from "filepond-plugin-get-file";
import { toast } from "react-toastify";
import customUploadAdapter from "./uploadAdapter";
import AmazonS3URI from "amazon-s3-uri";
import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";
import "filepond-plugin-media-preview/dist/filepond-plugin-media-preview.css";
import "filepond-plugin-image-overlay/dist/filepond-plugin-image-overlay.css";
import "filepond-plugin-get-file/dist/filepond-plugin-get-file.css";
import "filepond/dist/filepond.min.css";
import "../admin.css";
import moment from "moment";
var token = window.localStorage.getItem("token");

var fileSet = [];
var tmpFiles = [];
var commentsArr = [];
registerPlugin(
  FilePondPluginImagePreview,
  FilePondPluginMediaPreview,
  FilePondPluginGetFile,
  FilePondPluginImageOverlay
);

const uploadQuery =
  "mutation{ uploadFiles(upload: Upload){ result message fileId }}";

const GET_ARTICLE = gql`
  query GetArticle($articleid: ID!, $token: String!) {
    getDashboardArticles(articleId: $articleid, token: $token) {
      id
      articletitle
      articledescription
      article{
        id
        slug
        isLocked
      articleeditedbySet{
        
        commentsSet{
          comment
          modifiedAt
          commentby{
            editor{
              username
              
            }
            role
          }
        }
      }
      user {
        username
      }
      articlestatusSet {
        statusname
        globalStatus
        editorstatus
      }
      section {
        name
      }
    }
      language {
        languagename
      }
      location
    
      category {
        categoryname
      }
      subcategory {
        subcategoryname
      }
      articlekeywordsSet {
        keywords {
          keyword
        }
      }
      attachmentsSet {
        isFeaturedImage
        path
      }
      featuredImage
    }
  }
`;

const mutation = gql`
  mutation UpdateArticle($articleData: UpdateArticleInput!, $token: String!) {
    updateArticleById(articleData: $articleData, token: $token) {
      article {
        articletitle
      }
    }
  }
`;

const deleteMutation = gql`
  mutation deleteAttachment(
    $bucket: String!
    $filePath: String!
    $fullPath: String!
    $token: String!
  ) {
    deleteAttachment(
      bucket: $bucket
      filePath: $filePath
      fullPath: $fullPath
      token: $token
    ) {
      deleteAttachment {
        status
        message
      }
    }
  }
`;

const components = {
  DropdownIndicator: null
};

const createKeywordOption = (label: string) => ({
  label,
  value: label
});

class CKEditor extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  bindChangeEvent = (editor, document) => {
    document.on("change", () => {
      if (document.differ.getChanges().length > 0) {
        this.props.onChange(editor.getData());
      }
    });
  };

  componentDidMount() {
    ClassicEditor.create(document.querySelector("#editor"), {
      extraPlugins: [customUploadAdapter]
    })
      .then(editor => {
        editor.setData(this.props.data);
        this.bindChangeEvent(editor, editor.model.document);
      })
      .catch(error => {
        console.error(error);
      });
  }

  render() {
    return <div id={"editor"}></div>;
  }
}

class FormComponent extends Component {
  constructor(props) {
    super(props);

    var keywordslist = [];
    for (
      var j = 0;
      j < this.props.articleDetails.articlekeywordsSet.length;
      j++
    ) {
      keywordslist.push({
        value: this.props.articleDetails.articlekeywordsSet[j].keywords.keyword,
        label: this.props.articleDetails.articlekeywordsSet[j].keywords.keyword
      });
    }
    console.log(keywordslist);

    this.state = {
      articleId: this.props.articleDetails.article.id,
      title: this.props.articleDetails.articletitle,
      location: this.props.articleDetails.location,
      category: this.props.articleDetails.category.categoryname,
      subcategory: this.props.articleDetails.subcategory.subcategoryname,
      language: this.props.articleDetails.language.languagename,
      inputValue: "",
      editordata: this.props.articleDetails.articledescription,
      value: keywordslist,
      featuredImage: this.props.articleDetails.featuredImage,
      Files: [],
      status: this.props.articleDetails.article.articlestatusSet[0].statusname,
      section: this.props.articleDetails.article.section.name,
      isPublisher: false,
      isEditor: false,
      notReporter: false,
      isVerified: false,
      uploadFile: "",
      showSpinner: false,
      comments: [],
      historyHeadline:"",
      comment: '',
      editorState: EditorState.createEmpty()
    };
    this.handleCategoryChange = this.handleCategoryChange.bind(this);
    this.handleSubcategoriesChange = this.handleSubcategoriesChange.bind(this);
    this.handleLanguages = this.handleLanguages.bind(this);
    this.handleStatus = this.handleStatus.bind(this);
    this.handleSection = this.handleSection.bind(this);
    this.handleFilesChange = this.handleFilesChange.bind(this);
    this.handleEditorData = this.handleEditorData.bind(this);
    this.handleTitleChange = this.handleTitleChange.bind(this);
    this.onLocationChange = this.onLocationChange.bind(this);
    this.onFileUpload = this.onFileUpload.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.handleComment = this.handleComment.bind(this);
  }

  componentDidMount() {
    console.log(this.state.featuredImage);

    if (UserInfo().group === "Content Editor") {
      this.setState({ isEditor: true });
      this.setState({ notReporter: true });
    }

    if (UserInfo().group === "Publisher") {
      this.setState({ isPublisher: true });
      this.setState({ notReporter: true });
    }

    if (UserInfo().verified === "true") {
      this.setState({ isVerified: true });
    }


    if(this.props.articleDetails.article.articleeditedbySet.length > 0 ){
    
        for (let i = 0; i < this.props.articleDetails.article.articleeditedbySet.length; i++) {



        if(this.props.articleDetails.article.articleeditedbySet[i].commentsSet.length > 0){
            commentsArr.push({
          comment: this.props.articleDetails.article.articleeditedbySet[i].commentsSet[0].comment,
          commentBy: this.props.articleDetails.article.articleeditedbySet[i].commentsSet[0].commentby.editor.username,
          date: this.props.articleDetails.article.articleeditedbySet[i].commentsSet[0].modifiedAt,
          role: this.props.articleDetails.article.articleeditedbySet[i].commentsSet[0].role
        });

        }
         
        
        this.setState({historyHeadline:"Comments History"})

        
      }

    }
    
    this.setState({ comments: commentsArr })

    for (let i = 0; i < this.props.articleDetails.attachmentsSet.length; i++) {
      if (
        this.props.articleDetails.attachmentsSet[i].isFeaturedImage &&
        this.props.articleDetails.attachmentsSet[i].path !== ""
      ) {
        this.setState({
          featuredImage: this.props.articleDetails.attachmentsSet[i].path
        });
      }
    }

    for (let i = 0; i < this.props.articleDetails.attachmentsSet.length; i++) {
      if (
        !this.props.articleDetails.attachmentsSet[i].isFeaturedImage &&
        this.props.articleDetails.attachmentsSet[i].path !== ""
      ) {
        fileSet.push(this.props.articleDetails.attachmentsSet[i].path);
      }
    }

    for (let i = 0; i < this.props.articleDetails.attachmentsSet.length; i++) {
      if (
        !this.props.articleDetails.attachmentsSet[i].isFeaturedImage &&
        this.props.articleDetails.attachmentsSet[i].path !== ""
      ) {
        tmpFiles.push({
          source: this.props.articleDetails.attachmentsSet[i].path,
          options: { type: "local" }
        });
      }
    }

    this.setState({ Files: fileSet });
    console.log(this.state.Files);
    if (
      UserInfo().group === "Reporter"
    ) {
      this.setState({ status: "Pending" });
    }
  }

  isOptionUnique(prop) {
    const { option, options, valueKey, labelKey } = prop;
    return !options.find(opt => option[valueKey] === opt[valueKey]);
  }

  handleEditorData(data) {
    this.setState({ editordata: data });
  }

  handleCategoryChange(category) {
    console.log(this.props);
    this.setState({ category: category });
  }
  handleSubcategoriesChange(subcategory) {
    this.setState({ subcategory: subcategory });
  }
  handleLanguages(language) {
    this.setState({ language: language });
  }

  handleStatus(status) {
    this.setState({ status: status });
  }

  handleSection(section) {
    this.setState({ section: section });
  }

  handleTitleChange(e) {
    this.setState({ title: e.target.value });
  }

  handleFilesChange() {
    this.setState({ Files: fileSet });
  }

  onLocationChange(e) {
    this.setState({ location: e.target.value });
  }

  onFileUpload(event) {
    this.setState({
      uploadFile: event.target.files[0],
      loaded: 0
    });
  }

  handleComment(e) {

    this.setState({ comment: e.target.value });
  }

  onClickHandler = () => {
    if (!this.state.uploadFile) {
      toast.error("Please select a file to upload");
      return false;
    }

    const data = new FormData();
    data.append("upload", this.state.uploadFile);
    data.append("query", uploadQuery);
    axios
      .post(process.env.REACT_APP_GRAPHQL_URL, data, {
        onUploadProgress: p => {
          this.setState({ showSpinner: true });
        }
      })
      .then(res => {
        console.log(res.data.data.uploadFiles.result);

        this.setState(
          { featuredImage: res.data.data.uploadFiles.result },
          () => {
            this.setState({ showSpinner: false });
          }
        );
      })
      .catch(err => {
        toast.error("Upload failed");
        this.setState({ showSpinner: false });
      });
  };

  handleChange = (value: any, actionMeta: any) => {
    this.setState({ value });
  };

  handleSave = () => {
    this.setState({ status: "Draft" }, () => {
      this.handleSubmit();
    });
  };

  handleInputChange = (newValue: String) => {
    const inputValue = newValue;
    this.setState({ inputValue });
    return inputValue;
  };

  handleKeyDown = (event: SyntheticKeyboardEvent<HTMLElement>) => {
    const { inputValue, value } = this.state;
    if (value && value.length >= 10) {
      return;
    } else {
      if (!inputValue) return;

      switch (event.key) {
        case "Enter":
        case "Tab":
          if (value != null) {
            if (!this.state.value.find(x => x.value === inputValue)) {
              this.setState({
                inputValue: "",
                value: [...value, createKeywordOption(inputValue)]
              });
            }
          } else {
            this.setState({
              inputValue: "",
              value: [createKeywordOption(inputValue)]
            });
          }
          event.preventDefault();
          break;
        default:
      }
    }
  };

  handleInvalidSubmit = () => {
    toast.error(
      "Your account is not activated!. Please contact the site admin"
    );
  };

   handleValidation = () => {


    if (!this.state.title) {
      toast.error("Gallery Title is required");
    } else if (!this.state.featuredImage) {
      toast.error("Please upload a featured image");
    } else if (!this.state.language) {
      toast.error("Please select a language");
    } else if (fileSet.length < 1) {
      toast.error("Please upload files");
    } else if (!this.state.category) {
      toast.error("Please select a category");
    } else if (!this.state.subcategory) {
      toast.error("Please select a subcategory");
    } else {

     
      this.handleSubmit();
    }
  };

  handleSubmit = async () => {
    var articleData = {};

    articleData["keywords"] = "";

    articleData["articleId"] = this.state.articleId;
    articleData["title"] = this.state.title;
    articleData["category"] = this.state.category;
    articleData["subcategory"] = this.state.subcategory;
    articleData["body"] = this.state.editordata;
    articleData["language"] = this.state.language;
    articleData["location"] = this.state.location;
    articleData["status"] = this.state.status;
    articleData["featuredimage"] = this.state.featuredImage;
    articleData["section"] = this.state.section;
    articleData["files"] = fileSet;
    articleData["articleType"] = "gallery";

    if (this.state.value) {
      for (let i = 0; i < this.state.value.length; i++) {
        let c = ",";
        if (i === this.state.value.length - 1) {
          c = "";
        }

        articleData["keywords"] += this.state.value[i].label + c;
      }
    }
     if(this.state.comment.length > 0){

      articleData['comment'] = this.state.comment;
    }

    console.log(articleData);

    try {
      const response = await this.props.updatearticlemutation({
        variables: { articleData: articleData, token: token },
        refetchQueries: () => [
          {
            query: GET_ARTICLE,
            variables: { articleid: this.state.articleId, token: token }
          }
        ]
      });

      if (response.data) {
        toast.success("Success");
        setTimeout(function(){ window.location.href = "/Dashboard"; }, 3000);
        
        // this.notify('success','Article updated successfully');
      }
    } catch (error) {
      toast.error(error.graphQLErrors[0].message);
    }
  };

  render() {
    const { inputValue, value } = this.state;
    const isPublisher = this.state.isPublisher;
    const isEditor = this.state.isEditor;
    const notReporter = this.state.notReporter;
    const isVerified = this.state.isVerified;

    return (
      <div className="container-fluid no-padding">
        <div className="row no-margin">
          <HeaderDashboard />

          <div className="main-content" id="tglmcdisplay">
            <StatusBar />
            <span className="page-header">
              <span className="article-header">Edit Article</span>
            </span>
            <div className="row no-margin" id="main">
              <div className="col-sm-12 col-md-12 well" id="content">
                <div className="container-fluid">
                  <div className="row">
                    <form className="articleForm form-border" id="create-form">
                      <div className="form-row">
                        <div className="form-group col-md-3">
                          <label htmlFor="language">Language</label>
                          <Languages
                            onLanguageChange={this.handleLanguages}
                            currentLanguage={this.state.language}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label htmlFor="category">Category</label>
                          <Category
                            onCategoryChange={this.handleCategoryChange}
                            currentCategory={this.state.category}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label htmlFor="subcategory">Sub Category</label>
                          <SubCategoryByCategory
                            categoryname={this.state.category}
                            onSubCategoryChange={this.handleSubcategoriesChange}
                            currentSubCategory={this.state.subcategory}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label htmlFor="location">Location</label>
                          <Input
                            type="text"
                            onChange={this.onLocationChange}
                            name="location"
                            value={this.state.location}
                          />
                        </div>
                        <div className="form-group col-md-12">
                          <label htmlFor="title">Article Title</label>
                          <input
                            type="text"
                            className="form-control"
                            value={this.state.title}
                            onChange={this.handleTitleChange}
                            id="title"
                          />
                        </div>

                        <div className="form-group col-md-12 spinner-container">
                          <label htmlFor="title">Featured Image</label>
                          <div className="new-block">
                            <input
                              type="file"
                              accept="image/*"
                              name="featuredimage"
                              className="file-form-control"
                              onChange={this.onFileUpload}
                            />
                            <button
                              type="button"
                              className="btn btn-outline-info"
                              onClick={this.onClickHandler}
                            >
                              Upload{" "}
                              {this.state.showSpinner ? <Spinner /> : null}
                            </button>
                          </div>
                          <div className="featured-image dash-image">
                            <img src={this.state.featuredImage} alt="" />
                          </div>
                        </div>
                        <div className="form-group col-md-12 gallery">
                          <label htmlFor="article">Gallery Tagline</label>

                          <div>
                            <CKEditor
                              data={this.state.editordata}
                              onChange={this.handleEditorData}
                            />
                          </div>
                        </div>
                        <div className="form-group col-md-12">
                          <label htmlFor="tags">
                            Tags{" "}
                            <span className="keywordSpan">(Upto 50 tags)</span>
                          </label>
                          <CreatableSelect
                            components={components}
                            isClearable
                            inputValue={inputValue}
                            isMulti
                            menuIsOpen={false}
                            onChange={this.handleChange}
                            onInputChange={this.handleInputChange}
                            onKeyDown={this.handleKeyDown}
                            placeholder="Enter tags and press enter..."
                            value={this.state.value}
                          />
                        </div>

                        {notReporter && (
                          <div className="form-group col-md-4">
                            <label htmlFor="language">Status</label>
                            <ArticleStatus
                              onStatusChange={this.handleStatus}
                              currentArticleStatus={this.state.status}
                            />
                          </div>
                        )}

                        {isPublisher && (
                          <div className="form-group col-md-4">
                            <label>Section</label>
                            <ArticleSection
                              onSectionChange={this.handleSection}
                              currentArticleSection={this.state.section}
                            />
                          </div>
                        )}

                         {notReporter && (

                              <div className="form-group col-md-12">
                         
                          <label htmlFor="article">Comments</label>

                          <textarea className="form-control" name="comment" value={this.state.comment} onChange={this.handleComment}></textarea>
                        </div>

                          )}

                        <div className="form-group col-md-12">
                          <FilePond
                            allowMultiple={true}
                            files={tmpFiles}
                            server={{
                              fetch: null,
                              load: (
                                source,
                                load,
                                error,
                                progress,
                                abort,
                                headers
                              ) => {
                                console.log(source);
                                var myRequest = new Request(source);
                                fetch(myRequest).then(function(response) {
                                  response.blob().then(function(myBlob) {
                                    console.log(myBlob);
                                    load(myBlob);
                                  });
                                });
                              },
                              process: (
                                fieldName,
                                file,
                                metadata,
                                load,
                                error,
                                progress,
                                abort
                              ) => {
                                // fieldName is the name of the input field
                                // file is the actual file object to send

                                const formData = new FormData();
                                formData.append("upload", file);
                                formData.append("query", uploadQuery);

                                const request = new XMLHttpRequest();
                                request.open(
                                  "POST",
                                  process.env.REACT_APP_GRAPHQL_URL
                                );
                                request.responseType = "json";

                                // Should call the progress method to update the progress to 100% before calling load
                                // Setting computable to false switches the loading indicator to infinite mode
                                request.upload.onprogress = e => {
                                  progress(
                                    e.lengthComputable,
                                    e.loaded,
                                    e.total
                                  );
                                };

                                // Should call the load method when done and pass the returned server file id
                                // this server file id is then used later on when reverting or restoring a file
                                // so your server knows which file to return without exposing that info to the client
                                request.onload = function() {
                                  if (
                                    request.status >= 200 &&
                                    request.status < 300
                                  ) {
                                    // the load method accepts either a string (id) or an object
                                    load(
                                      request.response.data.uploadFiles.result
                                    );

                                    fileSet.push(
                                      request.response.data.uploadFiles.result
                                    );

                                    tmpFiles.push({
                                      source:
                                        request.response.data.uploadFiles
                                          .result,
                                      options: { type: "local" }
                                    });

                                    //load();
                                  } else {
                                    // Can call the error method if something is wrong, should exit after
                                    error("oh no");
                                  }
                                };

                                request.send(formData);

                                // Should expose an abort method so the request can be cancelled
                                return {
                                  abort: () => {
                                    // This function is entered if the user has tapped the cancel button
                                    request.abort();

                                    // Let FilePond know the request has been cancelled
                                    abort();
                                  }
                                };
                              },

                              revert: async (source, load, error) => {
                                

                                try {
                                  const { bucket, key } = AmazonS3URI(source);
                                  const response = await this.props.deletemutation(
                                    {
                                      variables: {
                                        bucket: bucket,
                                        filePath: key,
                                        fullPath: source,
                                        token: token,
                                        articleId: this.state.articleId
                                      }
                                    }
                                  );

                                  if (response.data) {
                                    fileSet = fileSet.filter(function(
                                      value,
                                      index,
                                      arr
                                    ) {
                                      return value !== source;
                                    });

                                    tmpFiles = tmpFiles.filter(function(
                                      value,
                                      index,
                                      arr
                                    ) {
                                      return value.source !== source;
                                    });

                                    this.setState({ Files: fileSet });
                                  }
                                } catch (e) {
                                  console.log(e);
                                }

                                error();

                                load();
                              },

                              remove: async (source, load, error) => {
                                

                                try {
                                  const { bucket, key } = AmazonS3URI(source);
                                  const response = await this.props.deletemutation(
                                    {
                                      variables: {
                                        bucket: bucket,
                                        filePath: key,
                                        fullPath: source,
                                        token: token,
                                        articleId: this.state.articleId
                                      }
                                    }
                                  );

                                  if (response.data) {
                                    fileSet = fileSet.filter(function(
                                      value,
                                      index,
                                      arr
                                    ) {
                                      return value !== source;
                                    });

                                    tmpFiles = tmpFiles.filter(function(
                                      value,
                                      index,
                                      arr
                                    ) {
                                      return value.source !== source;
                                    });

                                    this.setState({ Files: fileSet });
                                  }
                                } catch (e) {
                                  error('Could not remove');
                                }

                                error();

                                load();
                              }
                            }}
                          />
                        </div>
                        <div className="col-12">
                    
                    <p>
                        <strong>{this.state.historyHeadline}</strong>
                      </p>
                      <p>
                        {
                         // this.state.comments
                          
                          this.state.comments.map((comments, index) => (
                          <p
                            key={index}
                            className=""
                          >
                        
                            <span>Comment By - </span>  
                            <span>{
                              comments.commentBy
                              //console.log(comments.comment)
                             //comments.date
                             
                              } </span>
                              <span>Comment On </span>
                              <span>
                              
                                {moment( comments.date).format('LLLL')}
                               
                              </span>
                              <p>{comments.comment}</p>
                          </p>
                        ))}
                      </p>
                    </div>
                        {/*  <div className="form-group col-md-12">
                          <label htmlFor="article">Comments</label>

                          <div>
                            <textarea>Enter comments</textarea>
                          </div>
                        </div> */}
                        <div className="form-group col-md-12 pull-right submit-controls">
                          <button
                            type="button"
                            className="btn btn-outline-info pull-right"
                            onClick={this.handleValidation}
                          >
                            Submit
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-info pull-right m-r-20"
                            onClick={this.handleSave}
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>

                  <div className="row no-margin"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

class EditGallery extends Component {
  render() {
    let articleId = this.props.match.params.id;

    return (
      <Query
        query={GET_ARTICLE}
        variables={{ articleid: articleId, token: token }}
      >
        {({ data, loading, error }) => {
          if (loading) return <PageLoader />;
          if (error) return <div></div>;
          if (data)
            return <FormComponent articleDetails={data.getDashboardArticles[0]} />;
        }}
      </Query>
    );
  }
}

export default EditGallery;

FormComponent = compose(
  graphql(mutation, { name: "updatearticlemutation" }),
  graphql(deleteMutation, { name: "deletemutation" })
)(FormComponent);
