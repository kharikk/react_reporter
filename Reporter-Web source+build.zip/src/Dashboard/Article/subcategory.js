import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import Select from 'react-select';

const GET_SUB_BY_CATEGORY= gql`
query SubCategories($categoryname:String,$isGallery: Boolean!){
    getSubcategories(categoryName:$categoryname,isGallery: $isGallery){
      subcategoryname
    }
  }
`;




let SubcategoryOptions = [];
var isGallery = false;


class SubCategoryByCategory extends React.Component{
    
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
           if(this.props.currentSubCategory){
             this.state = {selectedOption: this.props.currentSubCategory};
        }

        else {

            this.state = {selectedOption: null};
        }

        if(this.props.type === "gallery"){

          isGallery = true;
        }
      }
    
      handleChange = (selectedOption) => {
        let val = selectedOption.value;
        this.setState({ selectedOption: val });
        this.props.onSubCategoryChange(selectedOption.value)
        
      }
    
       render() {
        const { selectedOption } = this.state;
     
        return(
    
     <Query query={GET_SUB_BY_CATEGORY}  variables={{categoryname: this.props.categoryname, isGallery: isGallery}} >
        
          
    
         {({ loading, error, data }) => {
              if (loading) return  <Select
              value={selectedOption}
              onChange={this.handleChange}
              options={SubcategoryOptions}
            />
              if (error) return <div>Error Loading Data</div>
        
         
          SubcategoryOptions = [];

         
          if(data.getSubcategories!=null){
          for(var i = 0; i < data.getSubcategories.length; i++){
    
            SubcategoryOptions.push({
                value: data.getSubcategories[i].subcategoryname, 
                label: data.getSubcategories[i].subcategoryname
            });
          }
            var selectedValue;
          if(selectedOption != null){

            selectedValue = {value: selectedOption, label: selectedOption};
          }

          else {

            selectedValue = selectedOption;
          }

        }
              return (
                
               <Select
            value={selectedValue}
            defaultValue ={selectedValue}
            onChange={this.handleChange}
            options={SubcategoryOptions}
          />
            
              );
            }}
      </Query>
          );
       }
      
      
      
    
    }
    
export default SubCategoryByCategory;