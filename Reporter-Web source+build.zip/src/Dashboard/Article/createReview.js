import React, { Component } from "react";
import gql from "graphql-tag";
import { Query, graphql } from "react-apollo";
import CreatableSelect from "react-select";
import { EditorState } from "draft-js";
import Input from "../Input";
import MovieCertifications from "./certifications";
import moment from "moment";
import ClassicEditor from "ckeditor5-custom-doped";
import HeaderDashboard from "../App/HeaderDashboard";
import StatusBar from "../App/StatusBar";
import { toast } from "react-toastify";
import axios from "axios";
import TimeField from "react-simple-timefield";
import { Spinner } from "../Spinner";
import customUploadAdapter from "./uploadAdapter";
import "../admin.css";
import DatePicker from "react-datepicker";
import "react-daterange-picker/dist/css/react-calendar.css";

var token1 = window.localStorage.getItem("token");

const uploadQuery =
  "mutation{ uploadFiles(upload: Uplod){ result message fileId }}";

const mutation = gql`
  mutation createMovieReview($data: MovieInput!, $token1: String!) {
    createMovie(articleData: $data, token: $token1) {
      article {
        articletitle
      }
    }
  }
`;

const components = {
  DropdownIndicator: null
};

const createKeywordOption = (label: string) => ({
  label,
  value: label
});

class StoryEditor extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  bindChangeEvent = (editor, document) => {
    document.on("change", () => {
      if (document.differ.getChanges().length > 0) {
        this.props.onChange(editor.getData());
      }
    });
  };

  componentDidMount() {
    ClassicEditor.create(document.querySelector("#story"), {
      extraPlugins: [customUploadAdapter],
      image: {
        // You need to configure the image toolbar, too, so it uses the new style buttons.
        toolbar: [
          "imageTextAlternative",
          "|",
          "imageStyle:alignLeft",
          "imageStyle:full",
          "imageStyle:alignRight"
        ],

        styles: [
          // This option is equal to a situation where no style is applied.
          "full",

          // This represents an image aligned to the left.
          "alignLeft",

          // This represents an image aligned to the right.
          "alignRight"
        ]
      }
    })
      .then(editor => {
        editor.setData(this.props.data);
        this.bindChangeEvent(editor, editor.model.document);
      })
      .catch(error => {
        console.error(error);
      });
  }

  render() {
    return <div id={"story"}></div>;
  }
}

class ReviewEditor extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  bindChangeEvent = (editor, document) => {
    document.on("change", () => {
      if (document.differ.getChanges().length > 0) {
        this.props.onChange(editor.getData());
      }
    });
  };

  componentDidMount() {
    ClassicEditor.create(document.querySelector("#review"), {
      extraPlugins: [customUploadAdapter],
      image: {
        // You need to configure the image toolbar, too, so it uses the new style buttons.
        toolbar: [
          "imageTextAlternative",
          "|",
          "imageStyle:alignLeft",
          "imageStyle:full",
          "imageStyle:alignRight"
        ],

        styles: [
          // This option is equal to a situation where no style is applied.
          "full",

          // This represents an image aligned to the left.
          "alignLeft",

          // This represents an image aligned to the right.
          "alignRight"
        ]
      }
    })
      .then(editor => {
        editor.setData(this.props.data);
        this.bindChangeEvent(editor, editor.model.document);
      })
      .catch(error => {
        console.error(error);
      });
  }

  render() {
    return <div id={"review"}></div>;
  }
}

export default class CreateMoviewReview extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      title: "",
      rating: "",
      cast: "",
      releasedate: new Date(),
      duration: "",
      mdirector: "",
      producer: "",
      director: "",
      story: "",
      review: "",
      certification: "",
      category: "",
      subcategory: "",
      language: "",
      inputValue: "",
      editordata: "",
      featuredImage: "http://lorempixel.com/1920/1080/business/",
      uploadFile: "",
      loaded: 0,
      status: "Pending",
      value: [],
      Files: [],
      time: "00:04",
      showSpinner: false,
      editorState: EditorState.createEmpty()
    };
    this.handleCategoryChange = this.handleCategoryChange.bind(this);
    this.handleSubcategoriesChange = this.handleSubcategoriesChange.bind(this);
    this.handleFilesChange = this.handleFilesChange.bind(this);
    this.handleStoryData = this.handleStoryData.bind(this);
    this.handleCertification = this.handleCertification.bind(this);
    this.handleReviewData = this.handleReviewData.bind(this);
    this.onFileUpload = this.onFileUpload.bind(this);
    this.onDurationChange = this.onDurationChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
    // this.handlestartDateChange = this.handlestartDateChange.bind(this);
  }

  handleStoryData(data) {
    this.setState({ story: data });
  }

  handleReviewData(data) {
    this.setState({ review: data });
  }

  handleCategoryChange(category) {
    this.setState({ category: category });
  }
  handleSubcategoriesChange(subcategory) {
    this.setState({ subcategory: subcategory });
  }

  handleCertification(certification) {
    this.setState({ certification: certification });
  }
  handleDateChange(date) {
    this.setState(
      {
        releasedate: date
      },
      () => {
        console.log(moment(this.state.releasedate).format("YYYY-MM-DD"));
      }
    );
  }
  // handleSelect(startDate) {
  //   this.setState({
  //     startDate:  startDate
  //   });
  // }

  handleFilesChange(Files) {
    this.setState({ Files });
  }

  onDurationChange(time) {
    let splitTime = time.toString().split(":");
    let duration = splitTime[0] + " hr(s) " + splitTime[1] + " min(s)";

    this.setState({ duration }, () => {
      console.log(this.state.duration);
    });
  }

  onFileUpload(event) {
    this.setState({
      uploadFile: event.target.files[0],
      loaded: 0
    });
  }

  onClickHandler = () => {
    if (!this.state.uploadFile) {
      toast.error("Please select a file to upload");
      return false;
    }

    const data = new FormData();
    data.append("upload", this.state.uploadFile);
    data.append("query", uploadQuery);
    axios
      .post(process.env.REACT_APP_GRAPHQL_URL, data, {
        onUploadProgress: p => {
          this.setState({ showSpinner: true });
        }
      })
      .then(res => {
        console.log(res.data.data.uploadFiles.result);

        this.setState(
          { featuredImage: res.data.data.uploadFiles.result },
          () => {
            this.setState({ showSpinner: false });
          }
        );
      })
      .catch(err => {
        toast.error("Upload failed");
        this.setState({ showSpinner: false });
      });
  };

  handleSave = () => {
    this.setState({ status: "Draft" }, () => {
      this.handleSubmit();
    });
  };

  handleChange = e => {
    let field = e.target.name;
    this.setState({ [field]: e.target.value });
  };

  handleGenreChange = (value: any, actionMeta: any) => {
    this.setState({ value });
  };

  handleInputChange = (newValue: String) => {
    const inputValue = newValue;
    this.setState({ inputValue });
    return inputValue;
  };

  handleKeyDown = (event: SyntheticKeyboardEvent<HTMLElement>) => {
    const { inputValue, value } = this.state;
    if (value && value.length >= 10) {
      return;
    } else {
      if (!inputValue) return;

      switch (event.key) {
        case "Enter":
        case "Tab":
          if (value != null) {
            if (!this.state.value.find(x => x.value === inputValue)) {
              this.setState({
                inputValue: "",
                value: [...value, createKeywordOption(inputValue)]
              });
            }
          } else {
            this.setState({
              inputValue: "",
              value: [createKeywordOption(inputValue)]
            });
          }
          event.preventDefault();
          break;
        default:
      }
    }
  };

  handleValidation = () => {
    if (!this.state.title) {
      toast.error("Movie Title is required");
    } else if (!this.state.featuredImage) {
      toast.error("Please upload a featured image");
    } else if (!this.state.story) {
      toast.error("Story field is required");
    } else if (!this.state.review) {
      toast.error("Review field is required prov a review");
    } else if (!this.state.certification) {
      toast.error("Please select the certification");
    } else if (!this.state.rating || !isNaN(this.state.rating)) {
      toast.error("Please enter a valid rating");
    } else if (!this.state.language) {
      toast.error("Please enter a Language");
    } else if (this.state.value < 1) {
      toast.error("Please enter atleast one genre");
    } else {
      this.handleSubmit();
    }
  };

  handleSubmit = async () => {
    var articleData = {};

    //             //console.log(this.state);
    articleData["keywords"] = "";

    articleData["title"] = this.state.title;
    articleData["category"] = "Movie";
    articleData["subcategory"] = "Movie Reviews";
    articleData["certification"] = this.state.certification;
    articleData["rating"] = Number(this.state.rating);
    articleData["cast"] = this.state.cast;
    articleData["releasedate"] = moment(
      this.state.releasedate,
      "DD-MM-YYYY"
    ).format("YYYY-MM-DD");
    articleData["duration"] = this.state.duration;
    articleData["musicdirector"] = this.state.mdirector;
    articleData["producer"] = this.state.producer;
    articleData["review"] = this.state.review;
    articleData["director"] = this.state.director;
    articleData["story"] = this.state.story;
    articleData["language"] = this.state.language;
    articleData["status"] = this.state.status;
    articleData["featuredimage"] = this.state.featuredImage;
    articleData["articleType"] = "review";
    // articleData['files'] =[""];
    for (let i = 0; i < this.state.value.length; i++) {
      let c = ",";
      if (i === this.state.value.length - 1) {
        c = "";
      }

      articleData["keywords"] += this.state.value[i].label + c;
    }

    console.log(articleData["releasedate"]);

    console.log(this.state);

    try {
      const response = await this.props.mutate({
        variables: { data: articleData, token1: token1 }
      });
      console.log(response);

      if (response.data) {
        toast.success("Review Created Successfully");
        setTimeout(function() {
          window.location.href = "/Dashboard";
        }, 3000);
      }
    } catch (error) {
      toast.error(error.graphQLErrors[0].message);
    }
  };

  render() {
    const { inputValue, value } = this.state;
    return (
      <div className="container-fluid no-padding">
        <div className="row no-margin">
          <HeaderDashboard />

          <div className="main-content" id="tglmcdisplay">
            <StatusBar />
            <span className="page-header">
              <span className="article-header">Create Review</span>
            </span>

            <div className="row no-margin" id="main">
              <div className="col-sm-12 col-md-12 well" id="content">
                <div className="container-fluid">
                  <div className="row">
                    <form className="articleForm form-border" id="create-form">
                      <div className="form-row">
                        <div className="form-group col-md-12">
                          <label htmlFor="title">Movie Title</label>
                          <input
                            type="text"
                            className="form-control"
                            onChange={this.handleChange}
                            id="title"
                            name="title"
                          />
                        </div>
                        <div className="form-group col-md-12">
                          <label htmlFor="title">Featured Image</label>
                          <div className="new-block spinner-container">
                            <input
                              type="file"
                              accept="image/*"
                              name="featuredimage"
                              className="file-form-control"
                              onChange={this.onFileUpload}
                            />
                            <button
                              type="button"
                              className="btn btn-outline-info"
                              onClick={this.onClickHandler}
                            >
                              Upload{" "}
                              {this.state.showSpinner ? <Spinner /> : null}
                            </button>
                          </div>
                          <div className="featured-image dash-image">
                            <img src={this.state.featuredImage} alt="" />
                          </div>
                        </div>
                        <div className="form-group col-md-12 story">
                          <label htmlFor="article">Story</label>

                          <div>
                            <StoryEditor
                              data=""
                              onChange={this.handleStoryData}
                            />
                          </div>
                        </div>
                        <div className="form-group col-md-12 review">
                          <label htmlFor="article">Review</label>

                          <div>
                            <ReviewEditor
                              data=""
                              onChange={this.handleReviewData}
                            />
                          </div>
                        </div>
                        <div className="form-group col-md-3">
                          <label>Certification</label>
                          <MovieCertifications
                            onCertificationChange={this.handleCertification}
                            currentCertification={this.state.certification}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Rating</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="rating"
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Release Date(DD-MM-YYYY)</label>
                          <DatePicker
                            selected={this.state.releasedate}
                            onChange={this.handleDateChange}
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Duration(hrs : mins)</label>
                          <TimeField
                            value={this.state.time}
                            onChange={this.onDurationChange}
                            style={{
                              display: "block",
                              width: "100%",
                              height: "calc(1.5em + 0.75rem + 2px)",
                              padding: "0.375rem 0.75rem",
                              fontSize: "1rem",
                              fontWeight: 400,
                              lineHeight: 1.5,
                              color: "#495057",
                              backgroundColor: "#fff",
                              backgroundClip: "padding-box",
                              border: "1px solid #ced4da",
                              borderRadius: "0.25rem",
                              transition:
                                "border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out"
                            }}
                          />
                        </div>

                        <div className="form-group col-md-3">
                          <label>Cast</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="cast"
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Producer</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="producer"
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Director</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="director"
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Music Director</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="mdirector"
                          />
                        </div>
                        <div className="form-group col-md-3">
                          <label>Language</label>
                          <Input
                            type="text"
                            onChange={this.handleChange}
                            name="language"
                          />
                        </div>
                        <div className="form-group col-md-9">
                          <label htmlFor="tags"> Genre</label>
                          <CreatableSelect
                            components={components}
                            inputValue={inputValue}
                            isClearable
                            isMulti
                            menuIsOpen={false}
                            onChange={this.handleGenreChange}
                            onInputChange={this.handleInputChange}
                            onKeyDown={this.handleKeyDown}
                            placeholder="Enter tags and press enter..."
                            value={value}
                          />
                        </div>

                        <div className="form-group col-md-12 pull-right submit-controls">
                          <button
                            type="button"
                            id="submitClick"
                            className="btn btn-outline-info pull-right"
                            onClick={this.handleValidation}
                          >
                            Submit
                          </button>
                          <button
                            type="button"
                            className="btn btn-outline-info pull-right m-r-20"
                            onClick={this.handleSave}
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div className="row no-margin"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

CreateMoviewReview = graphql(mutation)(CreateMoviewReview);
