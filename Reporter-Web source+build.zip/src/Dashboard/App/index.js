import React, { Component } from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
// import decode from 'jwt-decode'
import Navigation from './Navigation';
import Footer from './Footer';
//import Profile from '../Profile';
 import Organization from '../Organization';

import * as routes from '../constants/routes';
import Create from '../Article';
import EditorConvertToHTML from '../Article/editor';
import Dashbaord from '../dashboard/dashboard';
import ViewArticle from '../dashboard/viewArticle';
import Register from '../user/register/index';
import Login from '../user/login/index';
import { Redirect } from 'react-router-dom';



const checkAuth = () => {
  const token = localStorage.getItem('token');
  const refreshToken =  localStorage.getItem('token')   //localStorage.getItem('refreshToken');
  console.log("token "+token);
  if (!token || !refreshToken) {
    console.log("token "+token);
    return false;
  }

  try {
    // { exp: 12903819203 }
    // const { exp } = decode(refreshToken);

    // if (exp < new Date().getTime() / 1000) {
    //   return false;
    // }

  } catch (e) {
    return false;
  }

  return true;
}

const AuthRoute = ({ component: Component, ...rest }) => (
  <Route {...rest} render={props => (
    checkAuth() ? (
      <Component {...props} />
    ) : (
        <Redirect to={{ pathname: '/login' }} />
      )
  )} />
)

const LoginAuth = ({component:component,...rest})=>(
  <Route {...rest} render={props=>(
    checkAuth()?(<Redirect to={{ pathname:'/dashboard'}}/>
    ):(
      <Component {...props} />
    )
  )}/>
)



class App extends Component {
  state = {
    organizationName: 'TotalTelugu.com',
  };

  onOrganizationSearch = value => {
    this.setState({ organizationName: value });
  };

  render() {
    const { organizationName } = this.state;

    return (
      <Router>
        <div className="App">
          <Navigation
            organizationName={organizationName}
            onOrganizationSearch={this.onOrganizationSearch}
          />

          <div className="App-main">
            <Route
              exact
              path={routes.ORGANIZATION}
              component={() => (
                <div className="App-content_large-header">
                  <Organization organizationName={organizationName} />
                </div>
              )}
            />
            <Route
              exact
              path={routes.PROFILE}
              component={() => (
                <div className="App-content_small-header">
                  <Examples/>
                </div>
              )}
            />
             <Route
              exact
              path={routes.CREATEARTICLE}
              component={() => (
                <div className="App-content_small-header">
                  <Create />
                </div>
              )}
            />
             <AuthRoute
              exact
              path={routes.DASHBOARD}
              component={() => (
                <div className="App-content_small-header">
                  <Dashbaord />
                </div>
              )}
            />
             <Route
              exact
              path={routes.VIEW_ARTICLE}
              component={() => (
                <div className="App-content_small-header">
                  <ViewArticle />
                </div>
              )}
            />
             <Route
              exact
              path={routes.REGISTER}
              component={() => (
                <div className="App-content_small-header">
                  <Register />
                </div>
              )}
            />
             <Route
              exact
              path={routes.LOGIN}
              component={() => (
                <div className="App-content_small-header">
                  <Login />
                </div>
              )}
            />
          </div>

          <Footer />
        </div>
      </Router>
    );
  }
}

export default App;
