import React, { Component } from "react";
import { Link } from "react-router-dom";
import { UserInfo } from "../UserInfo";

import { DashLogo } from "../../../Logo";
import CustomScroll from 'react-custom-scroll';
import 'react-custom-scroll/dist/customScroll.css';

import "../../App/App.css";

var userName = localStorage.getItem("userName");

const MenuLinks = () => {
    if (UserInfo().group === "Content Editor") {
        return (
            <ul className="list">
                <a href="/dashboard">
                    <li>
                        <span className="menu-icon">
                            <i className="fas fa-tachometer-alt"></i>
                        </span>
                        <span className="menu-text">Dashboard</span>
                    </li>
                </a>
                <a href="/dashboard/search">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-search" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Search Articles</span>
                    </li>
                </a>
                <a href="/add/article" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-plus" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Create Article</span>
                    </li>
                </a>
                <a href="/add/review" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fas fa-film"></i>
                        </span>
                        <span className="menu-text">Create Movie Review</span>
                    </li>
                </a>
                <a href="/add/gallery" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-picture-o" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Create Gallery</span>
                    </li>
                </a>
                <a href="/reporters" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-users" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Reporters</span>
                    </li>
                </a>
               
            </ul>
        );
    } else if (UserInfo().group === "Publisher") {
        return (
            <ul className="list">
                <a href="/dashboard">
                    <li>
                        <span className="menu-icon">
                            <i className="fas fa-tachometer-alt"></i>
                        </span>
                        <span className="menu-text">Dashboard</span>
                    </li>
                </a>
                <a href="/dashboard/search">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-search" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Search Articles</span>
                    </li>
                </a>
                <a href="/add/article" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-plus" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Create Article</span>
                    </li>
                </a>
                <a href="/add/review" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fas fa-film"></i>
                        </span>
                        <span className="menu-text">Create Movie Review</span>
                    </li>
                </a>
                 <a href="/add/gallery" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-picture-o" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Create Gallery</span>
                    </li>
                </a>
                <a href="/reporters" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-users" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Reporters</span>
                    </li>
                </a>
                <a href="/editors" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-users" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Editors</span>
                    </li>
                </a>
               
            </ul>
        );
    } else {
        return (
            <ul className="list">
                <a href="/dashboard">
                    <li>
                        <span className="menu-icon">
                            <i className="fas fa-tachometer-alt"></i>
                        </span>
                        <span className="menu-text">Dashboard</span>
                    </li>
                </a>
                <a href="/dashboard/search">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-search" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Search Articles</span>
                    </li>
                </a>
                <a href="/add/article" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-plus" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Create Article</span>
                    </li>
                </a>
                <a href="/add/review" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fas fa-film"></i>
                        </span>
                        <span className="menu-text">Create Movie Review</span>
                    </li>
                </a>
                 <a href="/add/gallery" className="">
                    <li>
                        <span className="menu-icon">
                            <i className="fa fa-picture-o" aria-hidden="true"></i>
                        </span>
                        <span className="menu-text">Create Gallery</span>
                    </li>
                </a>
               
            </ul>
        );
    }
};

class HeaderDashboard extends Component {
    render() {
        return (
            <CustomScroll>
            <div className="sidebar1" id="tgldisplay">
                <div className="dash-logo">
                    <DashLogo />
                </div>
                <a href="/profile" className="user-profile-link"><div className="user-avatar">
                    <img
                        src="http://lorempixel.com/output/people-q-g-64-64-1.jpg"
                        className="img-responsive center-block"
                        alt="User"
                    />
                    <p>{userName}</p>
                    <p>{UserInfo().group}</p>
                </div>
                </a>
                <br />
                <div className="left-navigation">
                    <MenuLinks />
                </div>
            </div>
            </CustomScroll>
        );
    }
}

export default HeaderDashboard;
