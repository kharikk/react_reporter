import React, { Component } from 'react';


var userInfo = [];

userInfo['id'] = localStorage.getItem('userId');
userInfo['email'] = localStorage.getItem('userEmail');
userInfo['group'] = localStorage.getItem('userGroup');
userInfo['username'] = localStorage.getItem('userName');
userInfo['verified'] = localStorage.getItem('userVerified');



export const UserInfo = () => {

	return(

		userInfo

		);
}