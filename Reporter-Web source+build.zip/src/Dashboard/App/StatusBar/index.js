import React, { Component } from 'react';
import { Query } from 'react-apollo';
import gql from 'graphql-tag';




const GET_STATUS_COUNT_USER = gql`
query GetStatusCountUser($token: String!){

   getArticleCount(token:$token){

    pending
    draft
    rejected
    published
    rework

  }


}
`;




class StatusBar extends Component {

	toggleSidebar() {
        var sb = document.getElementById("tgldisplay");
              sb.classList.toggle("tglshrink");
        var mc = document.getElementById("tglmcdisplay");
        	  mc.classList.toggle("tglmcexpand");
    }


	render() {

    
		return(
 

 <Query query={GET_STATUS_COUNT_USER} variables={{token:window.localStorage.getItem('token')}}>
    
      

     {({ loading, error, data }) => {
          if (loading) return <div></div>
          if (error) return <div></div>
    
        
          return (
           <div className="row dash-status">

<div className="col-md-1">
<div className="toogle-menu">
<a href="#" onClick={this.toggleSidebar} ><i className="fa fa-bars" aria-hidden="true"></i></a>
</div>
</div>

<div className="col-md-10">
<div className="row no-margin">
<a href="/dashboard/Draft" className="status-link">
<span className="status-span btn status-draft">
<span className="status-icon"><i className="fas fa-sticky-note"></i></span>
<span className="status-text">Draft</span>
 <span className="badge badge-light">{data.getArticleCount.draft}</span>
</span>
</a>
<a href="/dashboard/rework" className="status-link">
<span className="status-span btn status-rework">
<span className="status-icon"><i className="fas fa-file-signature"></i></span>
<span className="status-text">Re-Work</span>
   <span className="badge badge-light">{data.getArticleCount.rework}</span>
</span>
</a>
<a href="/dashboard/pending" className="status-link">
<span className="status-span btn status-pending">
<span className="status-icon"><i className="fas fa-clock"></i></span>
<span className="status-text">Pending</span>
   <span className="badge badge-light">{data.getArticleCount.pending}</span>
</span>
</a>
<a href="/dashboard/rejected" className="status-link">
<span className="status-span btn status-rejected">
<span className="status-icon"><i className="fas fa-times-circle"></i></span>
<span className="status-text">Rejected</span>
   <span className="badge badge-light">{data.getArticleCount.rejected}</span>
</span>
</a>
<a href="/dashboard/published" className="status-link">
<span  className="status-span btn status-published">
<span className="status-icon"><i className="fas fa-clipboard-check"></i></span>
<span className="status-text">Published</span>
   <span className="badge badge-light">{data.getArticleCount.published}</span>
</span>
</a>
</div>



 </div>

 <div className="col-md-1">
 <a href="/logout">
 <div className="logout-container">

 <span className="logout">

 <i className="fas fa-power-off" title="Logout"></i>
 </span>

 </div>
 </a>

</div>
</div>
          );
        }}
  </Query>

			);
	}
}

export default StatusBar; 


