import React from "react";
import DateRangePicker from "react-daterange-picker";
import "react-daterange-picker/dist/css/react-calendar.css";
import originalMoment from "moment";
import { extendMoment } from "moment-range";
const moment = extendMoment(originalMoment);

class ByDateRange extends React.Component {
  constructor(props, context) {
    super(props, context);

    const today = moment();

    this.state = {
      isOpen: false,
      value: moment.range(today.clone().subtract(7, "days"), today.clone())
    };
  }

  onSelect = (value, states) => {
    this.setState({ value, states });
  };

  onToggle = () => {
    this.setState({ isOpen: !this.state.isOpen });
  };

  renderSelectionValue = () => {
    return (
       
      <div>
          <h6><strong>By DateRange</strong></h6>
          <span className="pull-right"><button type="reset" className="clear-btn-boarder"> clear <i className="fas fa-chevron-up"></i></button></span>
        {this.state.value.start.format("DD/MM/YYYY")}
        {" - "}
        {this.state.value.end.format("DD/MM/YYYY")}
      </div>
    );
  };

  render() {
    return (
        <div className="col-md-12">
        <div className="date-range-border">{this.renderSelectionValue()}

        
          <input
            type="button"
            value="Between Dates"
            onClick={this.onToggle}
          />
        </div>

        {this.state.isOpen && (
          <DateRangePicker
            value={this.state.value}
            onSelect={this.onSelect}
            singleDateRange={true}
          />
        )}
      </div>
    );
  }
}

export default ByDateRange;
