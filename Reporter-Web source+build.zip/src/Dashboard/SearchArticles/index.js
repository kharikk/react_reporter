import React, { Component } from "react";
import gql from "graphql-tag";
import { Query, graphql, Mutation, compose } from "react-apollo";
import { Loader } from "../../Loader";
import Category from "./Category";
import Action from "./ByAction";
import HeaderDashboard from "../App/HeaderDashboard";
import Select from "react-select";
import StatusBar from "../App/StatusBar";

import "filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css";
import "filepond/dist/filepond.min.css";
import "react-datepicker/dist/react-datepicker.min.css";
import { PageLoader } from "../../PageLoader";
import ReactTable from "react-table";
import SubCategory from "./SubCategory";
import Status from "./ByStatus";
import ByDateRange from "./ByDateRange";
import moment from "moment";

// import DateRangePicker from 'react-bootstrap-daterangepicker';
// import "./admin.css";

var categoryArr = [];
var subcategoryArr = [];
var statusArr = [];
var actionArr = [];

export default class SearchArticlesDashboard extends Component {
  constructor() {
    super();
    this.state = {
      category: [],
      date: new Date()
    };

    this.onCategoryChange = this.onCategoryChange.bind(this);
  }

  onChange = date => this.setState({ date });
  rt = () => {
    alert();
  };

  onCategoryChange(category) {
    categoryArr = [];
    if (category) {
      for (let i = 0; i < category.length; i++) {
        let value = category[i].value;

        categoryArr.push(value);
      }
    }
  }

  onSubCategoryChange(subcategory) {
    subcategoryArr = [];

    if (subcategory) {
      for (let i = 0; i < subcategory.length; i++) {
        let value = subcategory[i].value;

        subcategoryArr.push(value);
      }
    }
  }

  onStatusChange(status) {
    statusArr = [];

    if (status) {
      for (let i = 0; i < status.length; i++) {
        let value = status[i].value;

        statusArr.push(value);
      }
    }
  }

  onActionChange(action) {
    actionArr = [];

    if (action) {
      for (let i = 0; i < action.length; i++) {
        let value = action[i].value;

        actionArr.push(value);
      }
    }
  }

  render() {
    const GET_ARTICLE_DASHBOARD = gql`
      query getsearcharticles(
        $token: String!
        $byCategory: [String]
        $bySubCategory: [String]
        $byStatus: [String]
        $byAction: [String]
      ) {
        searchArticle(
          token: $token
          byCategory: $byCategory
          bySubCategory: $bySubCategory
          byStatus: $byStatus
          byAction: $byAction
        ) {
          articletitle
          modifiedAt
          article {
            user {
              role {
                role
              }
              username
            }
          }
        }
      }
    `;

    const columns = [
      {
        Header: "Date",
        accessor: "date"
      },
      {
        Header: "ArticleTitle",
        accessor: "articletitle",
        Cell: props => <p className="pull-left">{props.value}</p>
      },
      {
        Header: "Action By",
        accessor: "user"
      },
      {
        Header: "Status",
        accessor: "user"
      }
    ];

    return (
      <Query
        query={GET_ARTICLE_DASHBOARD}
        variables={{
          token: window.localStorage.getItem("token")
        }}
      >
        {({ loading, error, data, refetch }) => {
          if (loading) return <PageLoader />;
          if (error) return <div></div>;
          var dataArray = [];
          console.log(data);
          for (let i = 0; i < data.searchArticle.length; i++) {
            dataArray.push({
              date: moment(data.searchArticle[i].modifiedAt).format(
                "DD/MM/YYYY"
              ),
              articletitle: data.searchArticle[i].articletitle,
              role: data.searchArticle[i].article.user.role.role,
              user: data.searchArticle[i].article.user.username
            });
          }

          return (
            <div className="container-fluid no-padding">
              <div className="row no-margin">
                <HeaderDashboard />

                <div className="main-content" id="tglmcdisplay">
                  <StatusBar />

                  <div className="container-fluid">
                    <div className="page-header">
                      <div className="row">
                        <div className="col-md-12">
                          <span>
                            <h3>
                              {" "}
                              <strong>Search Articles</strong>
                            </h3>
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-sm-2">
                        <div className="search-form">
                          <div className="row">
                            <div className="col-md-12">
                              <div className="borderline2">
                                <h6>
                                  <span>
                                    <strong>Refine List by:</strong>
                                  </span>
                                </h6>
                              </div>
                            </div>

                            <div className="form-group col-md-12 p10-20">
                            <p className="filter-text">By Category</p>
                              <Category
                                onCategoryChange={this.onCategoryChange}
                                currentCategory={categoryArr}
                              />
                              
                            </div>

                            <div className="form-group col-md-12 p10-20">
                            <p className="filter-text">By Sub Category</p>
                              <SubCategory
                                onSubCategoryChange={this.onSubCategoryChange}
                                currentSubCategory={subcategoryArr}
                              />
                            </div>

                            <div className="form-group col-md-12 p10-20">
                            <p className="filter-text">By Status</p>
                              <Status
                                onStatusChange={this.onStatusChange}
                                currentStatus={statusArr}
                              />
                            </div>

                             <div className="form-group col-md-12 p10-20">
                             <p className="filter-text">By Action</p>
                              <Action
                                onActionChange={this.onActionChange}
                                currentAction={actionArr}
                              />
                            </div>

                            <div className="form-group col-md-12 p10-20">
                             <button
                             className="filter-btn"
                                onClick={event =>
                                  refetch({
                                    byCategory: categoryArr,
                                    bySubCategory: subcategoryArr,
                                    byStatus: statusArr,
                                    byAction: actionArr
                                  })
                                }
                              >
                                Filter{" "}
                              </button>
                            </div>

                            

                            <ByDateRange />
                          </div>
                        </div>
                      </div>

                      <div className="col-sm-10">
                        <div className="col-md-12">
                          <div className="users-table-container">
                            <ReactTable data={dataArray} columns={columns} minRows = {0}/>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        }}
      </Query>
    );
  }
}
