import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import Select from 'react-select';

const GET_SUB_BY_CATEGORY= gql`
query SubCategories($categoryname:String,$isGallery: Boolean!){
    getSubcategories(categoryName:$categoryname,isGallery: $isGallery){
      subcategoryname
    }
  }
`;




let SubcategoryOptions = [];
var isGallery = false;
var setSubCategories = [];


class SubCategory extends React.Component{
    
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
         if(this.props.currentSubCategory && this.props.currentSubCategory.length > 0){
             console.log(this.props.currentSubCategory);
             setSubCategories=[];
             for(let i=0; i<this.props.currentSubCategory.length; i++){
                setSubCategories.push({ value: this.props.currentSubCategory[i], label: this.props.currentSubCategory[i]})

             }

          
             console.log(setSubCategories);
        }

        

        if(this.props.type === "gallery"){

          isGallery = true;
        }
      }
    
      handleChange = (selectedOption) => {
       
        this.props.onSubCategoryChange(selectedOption)
        
      }
    
       render() {
        
     
        return(
    
     <Query query={GET_SUB_BY_CATEGORY}  variables={{isGallery: isGallery}} >
        
          
    
         {({ loading, error, data }) => {
              if (loading) return  <div>Error Loading Data</div>
              if (error) return <div>Error Loading Data</div>
        
         
          SubcategoryOptions = [];

         
          if(data.getSubcategories!=null){
          for(var i = 0; i < data.getSubcategories.length; i++){
    
            SubcategoryOptions.push({
                value: data.getSubcategories[i].subcategoryname, 
                label: data.getSubcategories[i].subcategoryname
            });
          }
         

        }
              return (
                
               <Select
               isMulti
           
            defaultValue={setSubCategories}
            onChange={this.handleChange}
            options={SubcategoryOptions}
          />
            
              );
            }}
      </Query>
          );
       }
      
      
      
    
    }
    
export default SubCategory;