import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
 
import Select from 'react-select';
const GET_SUB_BY_CATEGORY= gql`
query Categories($isGallery: Boolean!){
    getCategories(isGallery: $isGallery){
    categoryname
    id
    isGallery
  }
  }
`;





 var StatusOptions = [
{value: "Pending",label: "Pending"},
{value: "Published",label: "Publish"},
{value: "Rework",label: "Rework"},
{value: "Rejected",label: "Reject"},
];

var setStatus = [];

class Status extends React.Component{
    
constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);

    if(this.props.currentStatus && this.props.currentStatus.length > 0){
             console.log(this.props.currentStatus);
             setStatus=[];
             for(let i=0; i<this.props.currentStatus.length; i++){
                setStatus.push({ value: this.props.currentStatus[i], label: this.props.currentStatus[i]})

             }

             
        }

       

        
  }

  handleChange = (selectedOption) => {

    this.props.onStatusChange(selectedOption)
  
  }

   render() {
  
    

 
    
      

  

     

          return (
              <div>
           <Select
        isMulti
        defaultValue={setStatus}
        onChange={this.handleChange}
        options={StatusOptions}
      />
        </div>
      

      );
   }
  
  
  

}

export default Status;