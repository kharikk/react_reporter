import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
 
import Select from 'react-select';
const GET_SUB_BY_CATEGORY= gql`
query Categories($isGallery: Boolean!){
    getCategories(isGallery: $isGallery){
    categoryname
    id
    isGallery
  }
  }
`;





 var actionOptions = [
{value: "Reporter",label: "Reporter"},
{value: "Content Editor",label: "Content Editor"},
{value: "Publisher",label: "Publisher"}
];

var setAction = [];

class Action extends React.Component{
    
constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);

    if(this.props.currentAction && this.props.currentAction.length > 0){
             console.log(this.props.currentAction);
             setAction=[];
             for(let i=0; i<this.props.currentAction.length; i++){
                setAction.push({ value: this.props.currentAction[i], label: this.props.currentAction[i]})

             }

             
        }

       

        
  }

  handleChange = (selectedOption) => {

    this.props.onActionChange(selectedOption)
  
  }

   render() {
  
    

 
    
      

  

     

          return (
              <div>
           <Select
        isMulti
        defaultValue={setAction}
        onChange={this.handleChange}
        options={actionOptions}
      />
        </div>
      

      );
   }
  
  
  

}

export default Action;