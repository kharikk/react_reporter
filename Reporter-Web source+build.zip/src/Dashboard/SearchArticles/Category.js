import React, {Component} from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
 
import Select from 'react-select';
const GET_SUB_BY_CATEGORY= gql`
query Categories($isGallery: Boolean!){
    getCategories(isGallery: $isGallery){
    categoryname
    id
    isGallery
  }
  }
`;





let CategoryOptions = [];
var isGallery = false;
var setCategories = [];

class Categories extends React.Component{
    
constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);

    if(this.props.currentCategory && this.props.currentCategory.length > 0){
             console.log(this.props.currentCategory);
             setCategories=[];
             for(let i=0; i<this.props.currentCategory.length; i++){
                setCategories.push({ value: this.props.currentCategory[i], label: this.props.currentCategory[i]})

             }

            
             console.log(setCategories);
        }

       

        if(this.props.type === "gallery"){

          isGallery = true;
        }
  }

  handleChange = (selectedOption) => {

    
    this.props.onCategoryChange(selectedOption)
  
  }

   render() {
    
    return(

 <Query query={GET_SUB_BY_CATEGORY} variables={{isGallery: isGallery}} >
    
      

     {({ loading, error, data }) => {
          if (loading) return <div></div>
          if (error) return <div>Error Loading Data</div>
    
      
      CategoryOptions = [];
      for(var i = 0; i< data.getCategories.length; i++){

        CategoryOptions.push({
            value: data.getCategories[i].categoryname, 
            label:  data.getCategories[i].categoryname
        });
      }

     

          return (
              <div>
           <Select
        isMulti
        defaultValue={setCategories}
        
        onChange={this.handleChange}
        options={CategoryOptions}
      />
        </div>
          );
        }}
  </Query>
      );
   }
  
  
  

}

export default Categories;