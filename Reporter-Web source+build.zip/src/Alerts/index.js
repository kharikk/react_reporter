import React, { Component } from "react";
import { MDBContainer, MDBAlert } from 'mdbreact';


class Alerts extends Component{

render() {


let alertType = this.props.alertType;
let message = this.props.message;

	return (

			 <MDBContainer>
      <MDBAlert color={alertType} dismiss>
        {message}
      </MDBAlert>
    </MDBContainer>


		);
}
	
}


export default Alerts;