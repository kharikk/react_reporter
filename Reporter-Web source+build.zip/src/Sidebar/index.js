import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import { Loader } from '../Loader';
import AdBanner from '../Home/AdBanners'
import strings from '../Locale';
import Cookies from 'js-cookie';



 var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }

const GET_RELATED_NEWS = gql`
  query GetNewsbycategory($categorySlug: String){
  getArticles(language:"${lang}", categorySlug: $categorySlug, limit:5){
  
    articletitle
    article{
    id
    slug
    }
    
   
  }
}
`;


const names = [
  'panel-header blue',
  'panel-header pink',
  'panel-header green',
  'panel-header info',
  'panel-header cyan',
  'panel-header red',
];

class Sidebar extends Component {
  constructor() {
    super();
    this.state = {};
    this.getRandomName = this.getRandomName.bind(this);
  }
  getRandomName() {
    return names[Math.floor(Math.random() * names.length)];
  }


  render() {

    return (

      <div className="col-md-4">

        <div className="ad-holder">

          <img
            className="img-fluid w-100" 
src="https://via.placeholder.com/400x330"
            alt="Ad banner"
          />
        </div>


        <Query asyncMode query={GET_RELATED_NEWS} variables={{ categorySlug: 'sports' }}>



          {({ loading, error, data }) => {
            if (loading) return <div><br /></div>
            if (error) return <div>Error Loading Data</div>
         
            return (

              <div className="panel panel-default mt20">
                <div className="panel-header pink">
                  {strings.relatedarticles}
          <i className="fa fa-ellipsis-v" aria-hidden="true"></i>
                </div>
                <div className="panel-body">
                  <ul>
                    {data.getArticles.map((article, index) =>


                      <li key={index}>
                        <Link to={`/article/${article.slug}`} className="">
                          {article.articletitle}
                        </Link>
                      </li>



                    )}
                  </ul>
                </div>

              </div>

            );
          }}
        </Query>

        <Query asyncMode query={GET_RELATED_NEWS}>



          {({ loading, error, data }) => {
            if (loading) return <div><br /></div>
            if (error) return <div>Error Loading Data</div>
            console.log(data);
            return (

              <div className="panel panel-default mt20">
                <div className="panel-header blue">
                  {strings.recommendedforyou}
          <i className="fa fa-ellipsis-v" aria-hidden="true"></i>
                </div>
                <div className="panel-body">
                  <ul>
                    {data.getArticles.map((article, index) =>


                      <li key={index}>
                        <Link to={`/article/${article.article.slug}`} className="">
                          {article.articletitle}
                        </Link>
                      </li>



                    )}
                  </ul>
                </div>
              </div>


            );
          }}
        </Query>

      </div>

    );


  }


}

export default Sidebar;