import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import ArticleList from '../ArticleList';
import  { Loader } from '../../Loader';
import Sidebar from '../../Sidebar';
import Header from '../../App/Header';
import Footer from '../../App/Footer';





class MiscPage extends Component {
  constructor() {
    super();

  }
 


  render() {

   console.log(this.props.match.params);

    return(
    
         <div className="the-body">
          <Header />
    <div className="row no-margin">
      <div className="col-md-8">
         
        
         <h4>Miscellaneous Content</h4>


      </div> 
      <div className="col-md-4">
         <Sidebar />

      </div> 
    
    </div>  
    <Footer />
     </div>

      );


  }
    
  
}

export default MiscPage;