import React from 'react';


export const Header_1 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/1920x200" alt="TotalTelugu Logo"/>
 
)

export const Header_2 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Header_3 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Header_4 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Home_1 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x330" alt="TotalTelugu Logo"/>
 
)

export const Article_1 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/500x550" alt="TotalTelugu Logo"/>
 
)

export const Politics_1 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/500x550" alt="TotalTelugu Logo"/>
 
)

export const Politics_2 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Politics_3 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x250" alt="TotalTelugu Logo"/>
 
)

export const Gallery_1 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Gallery_2 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Gallery_3 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Gallery_4 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Gallery_5 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Review_1 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x330" alt="TotalTelugu Logo"/>
 
)


export const Review_2 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Review_Detail_1 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x330" alt="TotalTelugu Logo"/>
 
)

export const Review_Detail_2 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="TotalTelugu Logo"/>
 
)

export const Review_Detail_3 = () => (

    <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x330" alt="TotalTelugu Logo"/>
 
)





