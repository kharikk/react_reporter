import React, { Component } from 'react';
import { TwitterTimelineEmbed } from 'react-twitter-embed';


class TwitterWidget extends Component {

render() {

	return (

			 <TwitterTimelineEmbed
  sourceType="profile"
  screenName="greatandhranews"
  options={{height: 400}}
/>

		);
}
}

export default TwitterWidget;