import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import Sidebar from '../../Sidebar';
import Header from '../../App/Header';
import Footer from '../../App/Footer';


const GET_CATEGORIES = gql`
{
  getCategories {
    
    categoryname
    id
  }
}
`;




class MovieNews extends Component {
  constructor() {
    super();
    this.state = {};
   
  }
  


  render() {

   

    return(
    
         <div className="the-body">
          <Header />
    <div className="row no-margin">
      <div className="col-md-8">
         
          <p className="mb20">Movie News landing Page</p>
          <p className="mt7">In Progress</p>
      </div> 
      <div className="col-md-4">
         <Sidebar />

      </div> 
    
    </div>  
    <Footer />
     </div>

      );


  }
    
  
}

export default MovieNews;