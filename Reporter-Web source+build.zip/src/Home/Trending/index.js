import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import Image from "react-graceful-image";
import  { Loader } from '../../Loader';
import { slug } from '../../Helpers';
import Cookies from 'js-cookie';



class Trending extends Component {

    render() {

      var GET_ARTICLES = '';
      var exclude = 0;
      var section="";
      if(this.props.section){

        section = slug(this.props.section);
      }

      if(this.props.exclude){

        exclude=this.props.exclude;
      }

       var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }


      

      if(this.props.subcategory){
           GET_ARTICLES = gql `
{
  
  getArticles(language:"${lang}", subcategoryname:"${this.props.subcategory}", orderby:"createdDate", sortby:"dsc",limit:${this.props.limit}, excludeArticleId: ${exclude}){
    
    articletitle
    article{
    slug
    id
    }
    featuredImage
  }

}
`;

      }

      else if(this.props.category){
           GET_ARTICLES = gql `
{
  
  getArticles(language:"${lang}", categorySlug:"${this.props.category}", orderby:"createdDate", sortby:"dsc",limit:${this.props.limit},excludeArticleId: ${exclude}){
    
    articletitle
    article{
    slug
    id
    }
    featuredImage
  }

}
`;

      }

  else if(this.props.keywords){


   
           GET_ARTICLES = gql `
{
  
  getArticles(language:"${lang}", keyword:[${'"' + this.props.keywords.join('","') + '"'}], orderby:"createdDate", sortby:"dsc", limit:${this.props.limit},excludeArticleId: ${exclude}){
    
    articletitle
    article{
    slug
    id
    }
    featuredImage
  }

}
`;



      }

      else {

       GET_ARTICLES = gql `
{
  
  getArticles(language:"${lang}", section:"${section}", orderby:"createdDate", sortby:"dsc", limit:${this.props.limit}){
    
    articletitle
    article{
    slug
    id
    }
    featuredImage
  }

}
`;
      }




      return(

          <Query query={GET_ARTICLES}>
    
      

     {({ loading, error, data }) => {
          if (loading) return <Loader />
          if (error) return <div>Error Loading Data</div>
    
        if(data.getArticles.length === 0){

          return <div className="no-data">No data to render in {this.props.section} section</div>
        }
      
          return (

             <div className="panel panel-default">
                  <div className={'panel-header '+ this.props.color}>
                    {this.props.title}
                    <a href={'section/'+section}><i className="fas fa-ellipsis-v"></i></a>
                  </div>
                  <div className="panel-body">
                    <TrendingNewsItem mplists={data.getArticles} />
                    
                  </div>
                </div>


            
          );
        }}
  </Query>


        );
    }



}

    


const TrendingNewsItem = ({ mplists }) => (
    <div className="thumb-item-row">
    {mplists.slice(0,6).map((article, index) => 
      <Link to={`/article/${article.slug}`} key={index} className="">
      <div className="mp-item-container d-flex" >
      <div className="col-md-12">
      {article.articletitle}
      </div>
     
      </div>
       </Link>
      

      )}
  </div>
);

export default Trending;