import React, { Component } from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import Sidebar from "../../Sidebar";
import Header from "../../App/Header";
import Footer from "../../App/Footer";
import GalleryHighlight from "./GalleryComponents";
import { GallerySubOne } from "./GalleryComponents";
import Modal from "react-awesome-modal";
import GalleryPost from "./single";
import GalleryCategoryRender from "./GalleryCategoryRender";
import Cookies from 'js-cookie';

  var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }

const GET_GALLERY = gql`
  {
    getArticles( language:"${lang}", sortby: "dsc", orderby: "modifiedAt", articleType: "gallery") {
      articletitle
      article {
        id
        slug
      }
      articledescription
      movieSet {
        releasedate
        rating
      }
      featuredImage
    }
  }
`;

class Gallery extends Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      article: ""
    };

    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }

  componentDidMount() {}

  openModal(slug) {
    this.setState({
      visible: true,
      article: slug
    });
  }

  closeModal() {
    this.setState({
      visible: false
    });
  }

  render() {
    return (
      <Query query={GET_GALLERY}>
        {({ loading, error, data }) => {
          if (loading) return <div></div>;
          if (error) return <div>Error Loading Data</div>;
          if (data.getArticles.length === 0) {
            return (
              <div className="no-data">No data to render in this section</div>
            );
          }

          return (
            <div className="the-body frontend review">
              <Header />
              <div className="row review-section-2 mt7">
                <div className="col-md-8">
                  <div className="gallery-highlight-row d-flex">
                    {data.getArticles.slice(0, 1).map((article, index) => (
                      <div
                        className="col-md-12 no-padding"
                        key={article.articletitle}
                        onClick={() => this.openModal(article.article.slug)}
                      >
                        <GalleryHighlight
                          title={article.articletitle}
                          featuredImage={article.featuredImage}
                          id={article.article.id}
                        />
                      </div>
                    ))}
                  </div>
                  
                </div>
                <div className="col-md-4 no-padding">

                  {data.getArticles.slice(1, 2).map((article, index) => (
                    <div
                      className="col-md-12 p5 no-padding"
                      key={article.articletitle}
                      onClick={() => this.openModal(article.article.slug)}
                    >
                      <GallerySubOne
                        title={article.articletitle}
                        featuredImage={article.featuredImage}
                        id={article.article.id}
                      />
                    </div>
                  ))}
                </div>
                <div className="col-md-12">
                <div className="ad-banner-row-1 d-flex">
                    <div className="col-md-12 no-padding">
                      <div className="ad-banner-holder-1">
                        <img
                          className="img-fluid w-100"
                          src="https://via.placeholder.com/1920x300"
                          alt="ad1"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="gallery-cat-display d-flex">
                    <GalleryCategoryRender />
                  </div>
                </div>
              </div>

              <Footer />
              <Modal
                visible={this.state.visible}
                width="80%"
                effect="fadeInUp"
                onClickAway={() => this.closeModal()}
              >
                <GalleryPost slug={this.state.article} />
              </Modal>
            </div>
          );
        }}
      </Query>
    );
  }
}
export default Gallery;
