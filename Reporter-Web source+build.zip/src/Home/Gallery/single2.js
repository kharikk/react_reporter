import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import gql from 'graphql-tag';
import moment from 'moment';
import { Loader } from '../../Loader';
import Header from '../../App/Header';
import Footer from '../../App/Footer';
// import  { Loader } from '../../Loader';
import ThumbnailNews from '../../Home/ThumbnailNews';
import ImageGallery from 'react-image-gallery';
import "react-image-gallery/styles/css/image-gallery.css";


const GET_ARTICLE = gql`
query GetArticle($slug: String){
  
    getArticles(slug: $slug){
    id
    article{

      id
      slug
    }
    articletitle
    articledescription
    featuredImage
    
    category {
      id
    }

      articlekeywordsSet {
      keywords {
        keyword
      }
    }
  }
}
`;

class GalleryPost extends Component {
  render() {

    let articleId = this.props.match.params.id;

    return (
      <Query query={GET_ARTICLE} variables={{ articleid: articleId }} >



        {({ loading, error, data }) => {
          if (loading) return <div></div>
          if (error) return <div>Error Loading Data</div>


        
          return (
            <GalleryContent content={data.getArticles[0]} />
          );
        }}
      </Query>

    );

  }
}

export const GalleryContent = (data) => {
  
  var keywordsArr =[];
  for (let i = 0; i < data.content.articlekeywordsSet.length; i++) {

      keywordsArr.push(data.content.articlekeywordsSet[i].keywords.keyword);
    }
 

  const images = [
      {
        original: 'http://lorempixel.com/1000/600/nature/1/',
        thumbnail: 'http://lorempixel.com/250/150/nature/1/',
      },
      {
        original: 'http://lorempixel.com/1000/600/nature/2/',
        thumbnail: 'http://lorempixel.com/250/150/nature/2/'
      },
      {
        original: 'http://lorempixel.com/1000/600/nature/3/',
        thumbnail: 'http://lorempixel.com/250/150/nature/3/'
      }
    ]



  return (
    <div className="the-body frontend">
      <Header />
      <div className="row">
        <div className="col-md-8">
         <ImageGallery items={images} />

        </div>
        <div className="col-md-4">
        
            <div className="ad-holder">
              <img className="img-fluid w-100" 
src="https://via.placeholder.com/500x550" alt="asd" />
            </div>

            
              <div className="d-flex mt14">

                <ThumbnailNews title="Related Articles" keywords={keywordsArr} exclude={data.content.article.id} limit={4} color="pink" />


              </div>

           
           
              <div className="d-flex mt14">

                <ThumbnailNews title="Recommended for you" category={data.content.category.id}  exclude={data.content.article.id} limit={4} color="blue" />


              </div>


          

      
        </div>

      </div>
      <Footer />
    </div>

  );
}




export default GalleryPost;


