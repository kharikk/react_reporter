import React, { Component } from 'react';
import { Query } from 'react-apollo';
import gql from 'graphql-tag';
import { GallerySubOne } from './GalleryComponents';
import Modal from 'react-awesome-modal';
import GalleryPost from './single';
import Cookies from 'js-cookie';




const GET_GALLERY_CATEGORIES = gql`
query Categories($isGallery: Boolean!){
    getCategories(isGallery: $isGallery){
    categoryname
    id
    slug
    isGallery
  }
  }
`;



class GalleryCategoryRender extends Component {

  render() {



    return(

        <Query asyncMode  query={GET_GALLERY_CATEGORIES} variables={{ isGallery: true }}>
    
      

     {({ loading, error, data }) => {
          if (loading) return <div><br/></div>
          if (error) return <div>Error Loading Data</div>
      
          return (
            
            <div className="highlight-row d-flex m-7">
            {data.getCategories.map((category, index) =>




                 <div className="col-md-12 no-padding" key={index}>

             <a  href={'/category/'+category.slug}><span className="gallery-category-header">{category.categoryname}</span></a>

            <GalleryComponentsCategoryList key={index} data={category} />

            </div>


              
          
        
           

            )}



               </div>
                
  
          );
        }}
  </Query>

      );


  }
    
  
}


class GalleryComponentsCategoryList extends Component {

  constructor(props) {
        super(props);
        this.state = {
            visible : false,
            article: ""
        }

        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

  openModal(slug) {
     
        this.setState({
            visible : true,
            article: slug
            
        });


    }
 
    closeModal() {
        this.setState({
            visible : false
        });
    }


  render() {

     var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }

   

  

  var GET_GALLERY_CATEGORY_ITEMS = gql`
{
  
  getArticles( language:"${lang}", categoryname:"${this.props.data.categoryname}", orderby:"createdDate", sortby:"dsc",limit:3,articleType: "gallery"){
    
    articletitle
    article{
    id
    slug
    }
    featuredImage
  }

}
`;

  
  return(

     <Query asyncMode  query={GET_GALLERY_CATEGORY_ITEMS}>
    
      

     {({ loading, error, data }) => {
          if (loading) return <div><br/></div>
          if (error) return <div>Error Loading Data</div>
    
          return (
            
            <div className="d-flex">
           
            {data.getArticles.map((article, index) => (

                <div className="col-md-4" key={article.articletitle} onClick={() => this.openModal(article.article.slug)}>
                   <GallerySubOne
                          title={article.articletitle}
                          featuredImage={article.featuredImage}
                          id={article.article.id}

                        />

                    </div>
                    ))}

             <Modal visible={this.state.visible} width="80%"  effect="fadeInUp" onClickAway={() => this.closeModal()}>
                 <GalleryPost slug={this.state.article} />
                </Modal>
            
           
</div>
         
  
          );
        }}
  </Query>

    );

      }

    }



export default GalleryCategoryRender;