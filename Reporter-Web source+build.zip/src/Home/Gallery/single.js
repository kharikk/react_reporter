import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import gql from 'graphql-tag';
import moment from 'moment';
import { Loader } from '../../Loader';
import Header from '../../App/Header';
import Footer from '../../App/Footer';
// import  { Loader } from '../../Loader';
import ThumbnailNews from '../../Home/ThumbnailNews';
import ImageGallery from 'react-image-gallery';
import "react-image-gallery/styles/css/image-gallery.css";



const GET_GALLERY = gql`
query GetArticle($slug: String!){
  
    getArticles(slug: $slug){
    id,
    articletitle
    attachmentsSet{
      path
    }
  }
}
`;

class GalleryPost extends Component {


  render() {
    var images = []

    return (

      <Query query={GET_GALLERY} variables={{ slug: this.props.slug }}>
        {({ loading, error, data }) => {
          if (loading) return <div></div>;
          if (error) return <div>Error Loading Data</div>;
          if (data.getArticles.length === 0) {
            return (
              <div className="no-data">No data to render in this section</div>
            );
          }

          for (let i = 0; i < data.getArticles[0].attachmentsSet.length; i++) {
      if (
        !data.getArticles[0].attachmentsSet[i].isFeaturedImage &&
        data.getArticles[0].attachmentsSet[i].path !== ""
      ) {
        images.push({
          original: data.getArticles[0].attachmentsSet[i].path,
          thumbnail: data.getArticles[0].attachmentsSet[i].path
        });
      }
    }

  

          return (
             <ImageGallery items={images} />
          );
        }}
      </Query>


     
    );
  }
}




export default GalleryPost;


