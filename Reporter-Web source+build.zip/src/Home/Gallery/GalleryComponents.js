import React, { Component } from "react";

export default class GalleryHighlight extends Component {
	
	render() {
		return (
			<div className="gallery-highlight">
				
					<div className="gallery-poster">
						<img
							src={this.props.featuredImage}
							alt={this.props.title}
						/>

					</div>
					<span className="gallery-title">{this.props.title}</span>
				
			</div>
		);
	}
}


export class GallerySubOne extends Component {
	

	render() {
		return (
			<div className="top-highlight">
				
					<div className="review-movie-poster">
						<img
							src={this.props.featuredImage}
							alt={this.props.title}
						/>
					</div>
					<div className="review-movie-info">

						<p className="review-movie-title">
							<h4>{this.props.title}</h4>
						</p>
					</div>
				
			</div>
		);
	}
}
