import React, { Component } from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import Sidebar from "../../Sidebar";
import Header from "../../App/Header";
import Footer from "../../App/Footer";
import MovieReviewComponentHighlight from "./movieReviewComponents";
import { MovieReviewComponentSub } from "./movieReviewComponents";
import { MovieReviewComponentThumb } from "./movieReviewComponents";
import Cookies from 'js-cookie';


 var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }


const GET_MOVIE_REVIEWS = gql`
  {
    getArticles(language:"${lang}", sortby: "desc", orderby: "modifiedAt", articleType: "review") {
      articletitle
      article{
      id
      slug
      }
      articledescription
      movieSet {
        releasedate
        rating
      }
      featuredImage
    }
  }
`;

class MovieNewsLanding extends Component {
  render() {
    return (
      <Query query={GET_MOVIE_REVIEWS}>
        {({ loading, error, data }) => {
          console.log(data);
          if (loading) return <></>;
          if (error) return <div>Error Loading Data</div>;
          if (data.getArticles.length === 0) {
            return (
              <div className="the-body frontend review">
              <Header />
              <div className="row review-section-1">
                <div className="col-md-12 no-padding">
                  <div className="highlight-row d-flex">
                  No data to render in this section
                  </div>
                  </div>
                  </div>
                  </div>
            );
          }

          return (
            <div className="the-body frontend review">
              <Header />
              <div className="row review-section-1">
                <div className="col-md-12 no-padding">
                  <div className="highlight-row d-flex">
                    <div className="col-md-7">
                      {data.getArticles.slice(0, 1).map((article, index) => (
                        <MovieReviewComponentHighlight
                          key={article.articletitle}
                          title={article.articletitle}
                          releaseDate={article.movieSet[0].releasedate}
                          rating={article.movieSet[0].rating}
                          excerpt={article.articledescription.replace(
                            /(.{200})..+/,
                            "$1…"
                          )}
                          featuredImage={article.featuredImage}
                          slug={article.article.slug}
                        />
                      ))}
                    </div>
                    <div className="col-md-5">
                      {data.getArticles.slice(1, 3).map((article, index) => (
                        <MovieReviewComponentSub
                          key={article.articletitle}
                          title={article.articletitle}
                          releaseDate={article.movieSet[0].releasedate}
                          rating={article.movieSet[0].rating}
                          excerpt={article.articledescription.replace(
                            /(.{150})..+/,
                            "$1…"
                          )}
                          featuredImage={article.featuredImage}
                          slug={article.article.slug}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <div className="row review-section-2 mt7">
                <div className="col-md-8 no-padding">
                  <div className="highlight-row d-flex">
                    {data.getArticles.slice(3, 7).map((article, index) => (
                      <div className="col-md-6" key={article.articletitle}>
                        <MovieReviewComponentHighlight
                          title={article.articletitle}
                          releaseDate={article.movieSet[0].releasedate}
                          rating={article.movieSet[0].rating}
                          excerpt={article.articledescription.replace(
                            /(.{100})..+/,
                            "$1…"
                          )}
                          featuredImage={article.featuredImage}
                          slug={article.article.slug}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="ad-banner-row-1 d-flex">
                    <div className="col-md-6">
                      <div className="ad-banner-holder-1">
                        <img
                          className="img-fluid w-100" 
src="https://via.placeholder.com/400x100"
                          alt="ad1"
                        />
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="ad-banner-holder-1">
                        <img
                          className="img-fluid w-100" 
src="https://via.placeholder.com/400x100"
                          alt="ad1"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="highlight-row d-flex">
                    {data.getArticles.slice(3, 7).map((article, index) => (
                      <div className="col-md-3" key={article.articletitle}>
                        <MovieReviewComponentThumb
                          title={article.articletitle}
                          releaseDate={article.movieSet[0].releasedate}
                          rating={article.movieSet[0].rating}
                          excerpt={article.articledescription.replace(
                            /(.{100})..+/,
                            "$1…"
                          )}
                          featuredImage={article.featuredImage}
                          slug={article.article.slug}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="highlight-row d-flex">
                  <div className="col-md-12 text-center">
                    <button className="fetch-more btn">Fetch More</button>
                  </div>
                  </div>
                </div>
                <div className="col-md-4 no-padding"></div>
              </div>

              <Footer />
            </div>
          );
        }}
      </Query>
    );
  }
}
export default MovieNewsLanding;
