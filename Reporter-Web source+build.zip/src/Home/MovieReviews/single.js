import React, { Component } from 'react';
import { Query } from 'react-apollo';
import gql from 'graphql-tag';
import moment from 'moment';
import Sidebar from '../../Sidebar';
import Header from '../../App/Header';
import Footer from '../../App/Footer';
import Rating from 'react-rating-doped';




const GET_REVIEW = gql`
query GetArticle($slug: String){
  
    getArticles(slug: $slug){
      article{
        id
        slug
      }
    articletitle
    featuredImage
    articledescription
    movieSet{
      cast
      producer
      certification
      duration
      releasedate
      musicdirector
      rating
      review
      language
      
    }
  
      articlekeywordsSet {
      keywords {
        keyword
      }
    }
  }
}
`;

class SingleMovieReview extends Component{
 render(){
 
 
       
  let slug = this.props.match.params.slug;
  
   return (
   <Query query={GET_REVIEW} variables={{slug: slug}} >
    
      

     {({ loading, error, data }) => {
          if (loading) return <div></div>
          if (error) return <div>Error Loading Data</div>
        
        console.log(data);
        console.log(data.getArticles[0]);
          return (
          <MovieContent content={data.getArticles[0]} />
          );
        }}
  </Query>

  );
 
 
 }
}

export const MovieContent = (data) => {

	return(
    <div className="the-body frontend">
          <Header />
    <div className="row">
      <div className="col-md-8">
          <span className="article-title"><h1>{data.content.articletitle}</h1></span>
         
          <div className="row no-margin movie-box">
          <div className="col-md-8 featured-movie-image">
            <img src={data.content.featuredImage} alt="movie-name" />

          </div>
          <div className="col-md-4 movie-info">

            <p><span className="mi-label">Rating: </span>
            <span className="mi-rating">
            <Rating rating={data.content.movieSet[0].rating} displayOnly={true} />
            </span>
            <span className="mi-rating-text"> {data.content.movieSet[0].rating}/5 </span></p>
            <p><span className="mi-certification">{data.content.movieSet[0].certification}</span>
            <span className="mi-language">{data.content.movieSet[0].language}</span>
            </p>
            <p> 
            <span className="mi-genre">
            <span className="genre-container">
                  <ul className="genre-list">
                    {data.content.articlekeywordsSet.map((Tags, index) => <li key={index}>{Tags.keywords.keyword}</li>)}
                  </ul>
            </span>

          </span></p>
          <p><span className="mi-release-date">{moment().format('LL')} </span> | <span className="mi-runtime"> 2hrs 10mins</span></p>
          <p><span className="mi-cast">Cast: {data.content.movieSet[0].cast}</span></p>
          <p><span className="mi-director">Director: {data.content.movieSet[0].director}</span></p>
          <p><span className="mi-producer">Producer: {data.content.movieSet[0].producer}</span></p>
          <p><span className="mi-music">Music Director: {data.content.movieSet[0].musicdirector}</span></p>
          </div>
         
          <div className="col-md-12 movie-content">
          <p className="movie-story"><span className="label">Story: </span>
          <span dangerouslySetInnerHTML={{__html: data.content.articledescription}} />
          </p>
          <p className="movie-review-content"><span className="label">Review: </span>
            <p dangerouslySetInnerHTML={{__html: data.content.movieSet[0].review}} />
            </p>
          </div>
             </div>
        
          
      </div>  
     <Sidebar />
    </div>	
    <Footer />
     </div>

		);
}




export default SingleMovieReview;


