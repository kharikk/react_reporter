import React, { Component } from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import {
  MDBCarousel,
  MDBCarouselCaption,
  MDBCarouselInner,
  MDBCarouselItem,
  MDBView,
  MDBContainer
} from "mdbreact";
import MovieReviewComponentHighlight from './movieReviewComponents';
import { MovieReviewComponentSub } from './movieReviewComponents';

import { Loader } from "../../Loader";
var limit = 9;

const GET_MOVIE_REVIEWS = gql`
  {
    getArticles {
      articletitle
      article{
      id
      slug
      }
      featuredImage
    }
  }
`;

class MovieReviewWide extends Component {
  render() {
    return (
      <Query query={GET_MOVIE_REVIEWS}>
        {({ loading, error, data }) => {
          if (loading) return <Loader />;
          if (error) return <div>Error Loading Data</div>;
          if (data.getArticles.length === 0) {
            return (
              <div className="no-data">No data to render in this section</div>
            );
          }

          return (
             <div className="highlight-row d-flex">
              <div className="col-md-6">
              <MovieReviewComponentHighlight title="Movie Title" releaseDate="12 Nov 2019" rating=" 2.5/5" excerpt="" featuredImage="https://in.bmscdn.com/showcaseimage/eventimage/bharat-04-06-2019-01-10-56-808.jpg"
                    />
              </div>
              <div className="col-md-6">
               <MovieReviewComponentHighlight title="Movie Title" releaseDate="12 Jov 2019" rating=" 4.5/5" excerpt="" featuredImage="https://in.bmscdn.com/showcaseimage/eventimage/bharat-04-06-2019-01-10-56-808.jpg"
                    />
              </div>
            </div>
          );
        }}
      </Query>
    );
  }
}

class MovieReviewWideList extends React.Component {
  render() {
    return (
      <div className="pol-slider-hl">
        <MDBCarousel
          activeItem={1}
          length={2}
          showControls={true}
          showIndicators={false}
          className="z-depth-1"
        >
          <MDBCarouselInner>
            {this.props.sldierlists.slice(0, 3).map((article, index) => (
              <MDBCarouselItem key={index} itemId={index + 1}>
                <Link to={`/article/${article.id}`}>
                  <MDBView>
                    <img
                      className="d-block w-100"
                      src={article.featuredImage}
                      alt={index}
                    />
                  </MDBView>
                  <MDBCarouselCaption>
                    <p>{article.articletitle}</p>
                  </MDBCarouselCaption>
                </Link>
              </MDBCarouselItem>
            ))}
          </MDBCarouselInner>
        </MDBCarousel>
      </div>
    );
  }
}

export default MovieReviewWide;
