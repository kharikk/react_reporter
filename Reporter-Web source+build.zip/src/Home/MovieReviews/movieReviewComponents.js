import React, { Component } from "react";

export default class MovieReviewComponentHighlight extends Component {


	render() {
		return (
			<div className="top-highlight">
				<a href={"review/" + this.props.slug} className="review">
					<div className="review-movie-poster">
						<img
							src={this.props.featuredImage}
							alt={this.props.title}
						/>
					</div>
					<div className="review-movie-info">
						<p className="review-movie-detail-1">
							<span className="review-release-date">
								{this.props.releaseDate}
							</span>
							<span className="review-rating">
								{this.props.rating}
							</span>
						</p>

						<p className="review-movie-title">
							<h4>{this.props.title}</h4>
						</p>

						<p
							className="review-excerpt"
							dangerouslySetInnerHTML={{
								__html: this.props.excerpt
							}}
						/>
					</div>
				</a>
			</div>
		);
	}
}

export class MovieReviewComponentSub extends Component {


	render() {
		return (
			
				<a href={"review/" + this.props.id} className="review">
				<div className="sub-highlight d-flex">
					<div className="col-md-4 no-padding review-movie-poster">
						<img
							src={this.props.featuredImage}
							alt={this.props.title}
						/>
					</div>
					<div className="col-md-8 no-padding">
						<div className="review-movie-info">
							<p className="review-movie-detail-1">
								<span className="review-release-date">
									{this.props.releaseDate}
								</span>
								<span className="review-rating">
									{this.props.rating}
								</span>
							</p>

							<p className="review-movie-title">
								<h4>{this.props.title}</h4>
							</p>
							<p
								className="review-excerpt"
								dangerouslySetInnerHTML={{
									__html: this.props.excerpt
								}}
							/>
						</div>
					</div>
				
			</div>
			</a>
		);
	}
}

export class MovieReviewComponentThumb extends Component {
	
	render() {
		return (
			<div className="top-highlight">
				<a href={"review/" + this.props.slug} className="review">
					<div className="review-movie-poster">
						<img
							src={this.props.featuredImage}
							alt={this.props.title}
						/>
					</div>
					<div className="review-movie-info">
						<p className="review-movie-detail-1">
							<span className="review-release-date">
								{this.props.releaseDate}
							</span>
						</p>

						<p className="review-movie-title">
							<h4>{this.props.title}</h4>
						</p>
					</div>
				</a>
			</div>
		);
	}
}
