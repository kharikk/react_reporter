import React, { Component } from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import {
  MDBCarousel,
  MDBCarouselCaption,
  MDBCarouselInner,
  MDBCarouselItem,
  MDBView,
  MDBContainer
} from "mdbreact";
import { Loader } from "../../Loader";
import MovieReviewComponentHighlight from './movieReviewComponents';
import { MovieReviewComponentSub } from './movieReviewComponents';


var limit = 9;

const GET_MOVIE_REVIEWS = gql`
  {
    getArticles {
      articletitle
      article{
      id
      slug
      }
      featuredImage
    }
  }
`;

class MovieReviewHighlight extends Component {
  render() {
    return (
      <Query query={GET_MOVIE_REVIEWS}>
        {({ loading, error, data }) => {
          if (loading) return <Loader />;
          if (error) return <div>Error Loading Data</div>;
          if (data.getArticles.length === 0) {
            return (
              <div className="no-data">No data to render in this section</div>
            );
          }

          return (
            <div className="highlight-row d-flex">
              <div className="col-md-7">
              <MovieReviewComponentHighlight title="Movie Title" releaseDate="12 Nov 2019" rating=" 2.5/5" excerpt="Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard du..." featuredImage="https://in.bmscdn.com/showcaseimage/eventimage/bharat-04-06-2019-01-10-56-808.jpg"
                    />
              </div>
              <div className="col-md-5">
               <MovieReviewComponentSub title="Movie Title" releaseDate="12 Jov 2019" rating=" 4.5/5" excerpt="Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard du..." featuredImage="https://starsunfolded.com/wp-content/uploads/2017/07/Girish-Karnad.jpg"
                    />

               <MovieReviewComponentSub title="Movie Title" releaseDate="12 Dov 2019" rating=" 3.5/5" excerpt="Lorem Ipsum is simply dummy text of the printing and
                    typesetting industry. Lorem Ipsum has been the industry's
                    standard du..." featuredImage="https://in.bmscdn.com/showcaseimage/eventimage/bharat-04-06-2019-01-10-56-808.jpg"
                    />
              </div>
            </div>
          );
        }}
      </Query>
    );
  }
}

class MovieReviewHighlightList extends React.Component {
  render() {
    return (
      <div className="pol-slider-hl">
        <MDBCarousel
          activeItem={1}
          length={2}
          showControls={true}
          showIndicators={false}
          className="z-depth-1"
        >
          <MDBCarouselInner>
            {this.props.sldierlists.slice(0, 3).map((article, index) => (
              <MDBCarouselItem key={index} itemId={index + 1}>
                <Link to={`/article/${article.id}`}>
                  <MDBView>
                    <img
                      className="d-block w-100"
                      src={article.featuredImage}
                      alt={index}
                    />
                  </MDBView>
                  <MDBCarouselCaption>
                    <p>{article.articletitle}</p>
                  </MDBCarouselCaption>
                </Link>
              </MDBCarouselItem>
            ))}
          </MDBCarouselInner>
        </MDBCarousel>
      </div>
    );
  }
}

export default MovieReviewHighlight;
