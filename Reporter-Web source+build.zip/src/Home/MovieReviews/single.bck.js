import React, { Component } from 'react';
import { Query } from 'react-apollo';
import gql from 'graphql-tag';
import moment from 'moment';
import Sidebar from '../Sidebar';
import Header from '../App/Header';
import Footer from '../App/Footer';




const GET_ARTICLE = gql`
query GetArticle($articleid: ID){
  
    ArticlesById(articleId: $articleid){
      article{
slug
        id}

    articletitle
    articledescription
    createdby
    category {
      id
    }

      articlekeywordsSet {
      KeyWords {
        KeyWordsName
      }
    }
  }
}
`;

class SingleMovieReview extends Component{
 render(){
 
  let articleId = this.props.match.params.id;
  
   return (
   <Query query={GET_ARTICLE} variables={{articleid: articleId}} >
    
      

     {({ loading, error, data }) => {
          if (loading) return <div></div>
          if (error) return <div>Error Loading Data</div>
    		
        console.log(data);
          return (
          <MovieContent content={data.ArticlesById[0]} />
          );
        }}
  </Query>

  );
 
 }
}

export const MovieContent = (data) => {

  console.log(data);
	return(
    <div className="the-body">
          <Header />
    <div className="row no-margin">
      <div className="col-md-8">
          <span className="article-title"><h1>{data.content.articletitle}</h1></span>
          <span className="article-info">By {data.content.createdby} | Published on {moment(data.content.categorycreateddate).format('dddd, LL')}</span>
          <div className="col-md-12 featured-image">
            <img src="https://mdbootstrap.com/img/Photos/Slides/img%20(1).jpg" alt={data.content.articletitle} />

          </div>
          <div className="article-content">

            <p dangerouslySetInnerHTML={{__html: data.content.articledescription}} />

          </div>

          <div className="article-tags">

            <span>Tags : </span>
            <span className="tags-container">
                  <ul className="tags-list">

    {data.content.articlekeywordsSet.map((Tags, index) => <li key={index}>{Tags.KeyWords.KeyWordsName}</li>)}
 


                  </ul>
            </span>

          </div>
          
      </div>  
     <Sidebar />
    </div>	
    <Footer />
     </div>

		);
}




export default SingleMovieReview;


