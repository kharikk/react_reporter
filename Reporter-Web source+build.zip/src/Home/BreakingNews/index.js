import React, { Component } from "react";
import ReactDOM from "react-dom";
import { Link } from "react-router-dom";
import { Query } from "react-apollo";
import gql from "graphql-tag";
import Slider from "react-slick";
import Cookies from 'js-cookie';


class BreakingNews extends Component {
  render() {

     var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }

    const GET_ARTICLES = gql`
  {
    getArticles(
      orderby: "createdDate"
      sortby: "dsc"
      limit: 6
      section:"top-stories"
      language:"${lang}"
    ) {
      articletitle
      article{
      id
      slug
      }
      featuredImage
      articledescription
    }
  }
`;


    var settings = {
      dots: false,
      infinite: true,
      slidesToShow:3,
      slidesToScroll: 1,
      autoplay: true,
      speed: 300,
      autoplaySpeed: 4000,
      cssEase: "linear",
      arrows: true
    };
    return (
      <Query query={GET_ARTICLES}>
        {({ loading, error, data }) => {
          if (loading) return <div></div>;
          if (error) return <div>Error Loading Data</div>;
          console.log(data);
          return (
            <div className="slider-container">
              <Slider {...settings}>
                {data.getArticles.map((article, index) => (
                  <div key={index}>
                    <Link to={`/article/${article.article.slug}`} className="bn-links" title={article.articletitle}>
                      {article.articletitle.replace(/(.{30})..+/, "$1…")}
                    </Link>
                  </div>
                ))}
              </Slider>
            </div>
          );
        }}
      </Query>
    );
  }
}

export default BreakingNews;
