import React, { Component } from "react";
import TopStories from "./TopStories";
import InFocus from "./InFocus";
import TwitterWidget from "./TwitterWidget";
import PhotoFeature from "./PhotoFeature";
import HighlightNews from "./HighlightNews";
import ThumbnailNews from "./ThumbnailNews";
import { Loader } from "../Loader";
import Header from "../App/Header";
import Footer from "../App/Footer";
import LandingPage from "../App/landingPage";
import strings from '../Locale';
import LocalizedStrings from 'react-localization';

class Home extends Component {

  constructor(){

    super();
    this.state = {
  splash: true
};

this.handleClick = this.handleClick.bind(this);

  }

  componentDidMount() {
  setTimeout(() => {
    this.setState({splash: false});
  }, 11000); 

  // 1000ms = 1 second
}

handleClick(e) {

  this.setState({splash: e})

  // 1000ms = 1 second


}


  render() {

     if (this.state.splash) {
    return  <div className="the-body frontend"><LandingPage onChange={this.handleClick} /></div>
  }
    return (
      <div className="the-body frontend">
        <Header />
        <div className="root-sub-container">
          <section className="sub-container section1">
            <div className="row row-eq">
              <div className="col-md-6 col-lg-4">
                <div className="panel panel-default">
                  <div className="panel-header cyan">
                    {strings.topstories}
                    <a href="/section/top-stories" className="to-links"><i className="fas fa-ellipsis-v"></i></a>
                  </div>
                  <div className="panel-body">
                    
                    <TopStories /> 
                  </div>
                </div>
              </div>
              <div className="col-md-6 col-lg-4 in-focus">
                <div className="panel panel-default">
                  <div className="panel-header green">
                    {strings.infocus}
                    <i className="fas fa-ellipsis-v"></i>
                  </div>
                  <div className="panel-body">
                   
                     <InFocus /> 
                  </div>
                </div>
              </div>
               <div className="col-md-6 col-lg-4">
                 
              
                
                  <HighlightNews
                  section="Photo Feature"
                  limit={6}
                  color="red"
                  title={strings.photofeature}

                />
              
              </div>
            </div>
          </section>
          <section className="sub-container section2">
            <div className="row row-eq">
              <div className="col-md-6 col-lg-4">
              
                
                  <HighlightNews
                  section="Photo Feature"
                  limit={6}
                  color="red"
                  title={strings.photofeature}

                />
              
              </div>
              <div className="col-md-6 col-lg-4 panel-block nest-blocks">
               
       
                   <ThumbnailNews title={strings.mostPopular} section="Most Popular" color="blue" limit={2} />
                   <ThumbnailNews title={strings.TvMovies} section="Tv & Movies" color="info" limit={2} />
                
                </div>
              
               <div className="col-md-6 col-lg-4">
              
                
                  <HighlightNews
                  section="Photos / Videos"
                  limit={6}
                  color="red"
                  title={strings.photosvideos}

                />
              
              </div>
            </div>
          </section>
          <section className="sub-container section3">
            <div className="row row-eq">
              <div className="col-md-6 col-lg-4 mt7">
                <HighlightNews
                  section="Business & Technology"
                  limit={6}
                  color="mpurple"
                  title={strings.businesstechnology}
                />
              </div>

              <div className="col-md-6 col-lg-4 mt7">
                <HighlightNews
                  section="Around the World"
                  limit={6}
                  color="sushi"
                  title={strings.aroundtheworld}
                />
              </div>
              <div className="col-md-6 col-lg-4 mt7">
                <HighlightNews
                  section="Astrology"
                  limit={6}
                  color="gold-drop"
                  title={strings.astrology}
                />
              </div>
            </div>
          </section>
          <section className="sub-container section4">
            <div className="row">
              <div className="col-md-6 col-lg-4 mt7">
                <HighlightNews
                  section="Health & Lifestyle"
                  limit={6}
                  color="pclay"
                  title={strings.healthlifestyle}
                />
              </div>

              <div className="col-md-6 col-lg-4 mt7">
                <HighlightNews
                  section="Travel & Religious"
                  limit={6}
                  color="matrix"
                  title={strings.travelreligious}
                />
              </div>

              <div className="col-md-12 col-lg-4 mt7">
                <div className="ad-container ad-home">
                  <img
                    className="img-fluid w-100" 
src="https://via.placeholder.com/400x330"
                    alt="Ad banner"
                  />
                </div>
              </div>
            </div>
          </section>
        </div>
        <Footer />
      </div>
    );
  }
}
export default Home;
