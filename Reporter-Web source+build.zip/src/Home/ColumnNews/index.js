import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import  { Loader } from '../../Loader';
import Image from "react-graceful-image";
import Cookies from 'js-cookie';







class ColumnNews extends Component {





    render() {

  var subcatagory = this.props.title;

   var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }

//   const GET_MOST_POPULAR = gql `
// {
  
//   GetArticlesBySections(orderby:"createdDate", sortby:"dsc",limit:13,section:"Top Stories")
//   {
//     articletitle
//     id
//   }

// }
// `;

const GET_MOST_POPULAR = gql`
 {
  
 
  
  getArticles(language:"${lang}"){
    
    articletitle
    article{
    id
    slug
    }
    featuredImage
  }


}
`;

      return(

          <Query query={GET_MOST_POPULAR}>
    
      

     {({ loading, error, data }) => {
          if (loading) return <Loader />
          if (error) return <div>Error Loading Data</div>
    
        if(data.getArticles.length === 0){

          return <div className="no-data">No data to render in this section</div>
        }
      
          return (

             <div className="panel panel-default">
                  <div className={'panel-header '+ this.props.color}>
                    {this.props.title}
                    <i className="fas fa-ellipsis-v"></i>
                  </div>
                  <div className="panel-body">
                    <div className="row row-eq no-margin">
                  <div className="col-md-6 no-padding">
                     <ColumnNewsItem mplists={data.getArticles} />

                  </div>
                   <div className="col-md-6 no-padding bl">
                    <ColumnNewsList mplists={data.getArticles} />

                  </div>
                   </div>
                  </div>
                </div>


            
          );
        }}
  </Query>


        );
    }



}

    


const ColumnNewsItem = ({ mplists }) => (
    <div className="mp-item-row">
    {mplists.slice(0, 5).map((article, index) => 
      <Link to={`/article/${article.article.id}`} key={index} className="">
      <div className="mp-item-container row-eq" >
      <div className="col-md-4">
       <Image
        src={article.featuredImage}
        className="content-image-placeholder"
        alt={article.articletitle}
        retry={{ count: -1 }}
      />
      </div>
      <div className="col-md-8">
      {article.articletitle}
      </div>
      </div>
      </Link>
      

      )}
  </div>
);


const ColumnNewsList = ({ mplists }) => (
  <ul>
    {mplists.slice(5, 13).map(article => <Link to={`/article/${article.article.id}`} key={article.articletitle}><li>{article.articletitle}</li></Link>)}
  </ul>
);

export default ColumnNews;