import React, { Component } from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import { Loader } from "../../Loader";
import Header from "../../App/Header";
import Footer from "../../App/Footer";
import ThumbnailNews from "../ThumbnailNews";
import HighlightNews from "../HighlightNews";
import Modal from "react-awesome-modal";
import Image from "react-graceful-image";
import GalleryPost from "../Gallery/single";
import Pagination from "../../Helpers/pagination";
import Cookies from 'js-cookie';

var limit = 99999999;


var articleList = [];
var totalRecords;
var isGallery = false;

class ArticleList extends Component {
  render() {

    var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }
    var GET_ARTICLES = "";
    var exclude = 0;



    if(this.props.gallery){

      isGallery = true;
    }

    if (this.props.exclude) {
      exclude = this.props.exclude;
    }

    if (this.props.limit) {
      limit = this.props.limit;
    }

    if (this.props.subcategory) {
      GET_ARTICLES = gql`
{
  
  getArticles(language:"${lang}", subcategoryname:"${this.props.subcategory}", orderby:"createdDate", sortby:"dsc",limit:${this.props.limit}, excludeArticleId: ${exclude}){
    
    articletitle
    article{
    id
    slug
    articleType
    }
    featuredImage
    articledescription
  }

}
`;
    } else if (this.props.category) {
      GET_ARTICLES = gql`
{
  
  getArticles(language:"${lang}", categorySlug:"${this.props.category}", orderby:"createdDate", sortby:"dsc",limit:${this.props.limit},excludeArticleId: ${exclude}){
    
    articletitle
    article{
    id
    slug
    articleType
    }
    featuredImage
    articledescription
  }

}
`;
    } else if (this.props.keywords) {
      GET_ARTICLES = gql`
{
  
  getArticles(language:"${lang}", keyword:[${'"' +
    this.props.keywords.join('","') +
    '"'}], orderby:"createdDate", sortby:"dsc", limit:${
        this.props.limit
      },excludeArticleId: ${exclude}){
    
    articletitle
    article{
    id
    slug
    articleType
    }
    featuredImage
    articledescription
  }

}
`;
    } else if (this.props.tag) {
      GET_ARTICLES = gql`
{
  
  getArticles(language:"${lang}", keyword:"${this.props.tag}", orderby:"createdDate", sortby:"dsc", limit:${this.props.limit}){
    
    articletitle
    article{
    id
    slug
    articleType
    }
    featuredImage
    articledescription
  }

}
`;
    } else if (this.props.search) {
      GET_ARTICLES = gql`
{
  
  getArticles(language:"${lang}", searchKeyword:"${this.props.search}", orderby:"createdDate", sortby:"dsc"){
    
    articletitle
    article{
    id
    slug
    articleType
    }
    featuredImage

    articledescription
  }

}
`;
    } else {
      GET_ARTICLES = gql`
{
  
  getArticles(language:"${lang}", section:"${this.props.section}", orderby:"createdDate", sortby:"dsc", limit:${this.props.limit}){
    
    articletitle
    article{
    id
    slug
    articleType
    }
    featuredImage
   
    articledescription
  }

}
`;
    }

    return (
      <Query query={GET_ARTICLES}>
        {({ loading, error, data }) => {
          if (loading) return <Loader />
          if (error) return <div>Error Loading Data</div>;

          if (data.getArticles.length === 0 && this.props.search) {
            return (
              <div className="no-data">
                We could not find any results for {this.props.search}
              </div>
            );
          }

          if (data.getArticles.length === 0) {
            return (
              <div className="no-data">
                No data to render in {this.props.section} section
              </div>
            );
          }
            totalRecords = data.getArticles.length;


          return <ArticleListItem articlelist={data.getArticles} />;
        }}
      </Query>
    );
  }
}

class ArticleListItem extends Component{

  constructor(props){

    super(props);

    this.state = {
      currentData: (articleList = this.props.articlelist),
      visible: false,
      article: ""
    };


    this.openModal = this.openModal.bind(this);
    this.closeModal = this.closeModal.bind(this);


  }

   componentDidMount() {
    this.setState({ currentData: articleList });
  }

  onPageChange = data => {
    const { currentPage, totalPages, pageLimit } = data;

    const offset = (currentPage - 1) * pageLimit;

    const currentList = articleList.slice(offset, offset + pageLimit);

    this.setState({ currentData: currentList });
  };


  openModal(slug) {
    this.setState({
      visible: true,
      article: slug
    });
  }

  closeModal() {
    this.setState({
      visible: false
    });
  }

  render() {

    var currentData = this.state;

    return(

        <div className="thumb-item-row">
    {currentData.currentData.map((article, index) => (
      <>
     {(() => {

      if(article.article.articleType === "GALLERY") {

          console.log(article.article.slug);
        return(

           <div className="list-item-container d-flex" onClick={() => this.openModal(article.article.slug)}>
          <div className="col-md-4 a-list-image-container"  >
            <Image
              src={article.featuredImage}
              className="content-image-placeholder"
              alt={article.articletitle}
              retry={{ count: -1 }}
            />
          </div>
          <div className="col-md-8">
            <p className="list-title">{article.articletitle}</p>
            <p
              className="list-description"
              dangerouslySetInnerHTML={{
                __html: article.articledescription
                .replace(/(.{150})..+/, "$1…")
                  .replace(/<[^>]*>?/gm, "")
                  
              }}
            />
          </div>
           <Modal
                visible={this.state.visible}
                width="80%"
                effect="fadeInUp"
                onClickAway={() => this.closeModal()}
              >
                <GalleryPost slug={this.state.article} />
              </Modal>
        </div>

            

          );
      }

      else if(article.article.articleType === "REVIEW"){

           return(

             <Link to={`/review/${article.article.slug}`} key={index} className="list-links">
        <div className="list-item-container d-flex">
          <div className="col-md-4 a-list-image-container">
            <Image
              src={article.featuredImage}
              className="content-image-placeholder"
              alt={article.articletitle}
              retry={{ count: -1 }}
            />
          </div>
          <div className="col-md-8">
            <p className="list-title">{article.articletitle}</p>
            <p
              className="list-description"
              dangerouslySetInnerHTML={{
                __html: article.articledescription
                .replace(/(.{150})..+/, "$1…")
                  .replace(/<[^>]*>?/gm, "")
                  
              }}
            />
          </div>
        </div>
      </Link>

          );

      }

      else{

        return(

             <Link to={`/article/${article.article.slug}`} key={index} className="list-links">
        <div className="list-item-container d-flex">
          <div className="col-md-4 a-list-image-container">
            <Image
              src={article.featuredImage}
              className="content-image-placeholder"
              alt={article.articletitle}
              retry={{ count: -1 }}
            />
          </div>
          <div className="col-md-8">
            <p className="list-title">{article.articletitle}</p>
            <p
              className="list-description"
              dangerouslySetInnerHTML={{
                __html: article.articledescription
                .replace(/(.{150})..+/, "$1…")
                  .replace(/<[^>]*>?/gm, "")
                  
              }}
            />
          </div>
        </div>
      </Link>

          );
      }



       })()}
     
      </>
    ))}
    <Pagination
                        totalRecords={totalRecords}
                        pageLimit={6}
                        pageNeighbours={1}
                        onPageChanged={this.onPageChange}
                      />
  </div>

      );
  }
  
}

export default ArticleList;
