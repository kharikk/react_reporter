import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import ArticleList from '../ArticleList';
import  { Loader } from '../../Loader';
import Sidebar from '../../Sidebar';
import Header from '../../App/Header';
import Footer from '../../App/Footer';







class TagNews extends Component {
  constructor() {
    super();
  }


  render() {

   console.log(this.props.match.params);

    return(
    
         <div className="the-body frontend">
          <Header />
    <div className="row">
      <div className="col-md-8">
         
        
          <ArticleList tag={this.props.match.params.tag} limit={999} />
      </div> 
      
         <Sidebar />

     
    
    </div>  
    <Footer />
     </div>

      );


  }
    
  
}

export default TagNews;