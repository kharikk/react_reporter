import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import ArticleList from '../ArticleList';
import  { Loader } from '../../Loader';
import Sidebar from '../../Sidebar';
import Header from '../../App/Header';
import Footer from '../../App/Footer';


class SearchArticles extends Component {
  constructor() {
    super();
   
  }



  render() {


    return(
    
         <div className="the-body frontend">
          <Header />
    <div className="row">
      <div className="col-md-8">
         
        
          <ArticleList search={decodeURIComponent(this.props.match.params.search)} />
      </div> 
      <div className="col-md-4">
         <Sidebar />

      </div> 
    
    </div>  
    <Footer />
     </div>

      );


  }
    
  
}

export default SearchArticles;