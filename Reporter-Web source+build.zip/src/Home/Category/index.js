import React, { Component } from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import ArticleList from '../ArticleList';
import  { Loader } from '../../Loader';
import Sidebar from '../../Sidebar';
import Header from '../../App/Header';
import Footer from '../../App/Footer';


class CategoryNews extends Component {
  render() {


    return(
    
         <div className="the-body frontend">
          <Header />
    <div className="row">
      <div className="col-md-8">
         
        
          <ArticleList category={this.props.match.params.cname} limit={999} />
      </div> 
     
         <Sidebar />

      
    </div>  
    <Footer />
     </div>

      );


  }
    
  
}

export default CategoryNews;