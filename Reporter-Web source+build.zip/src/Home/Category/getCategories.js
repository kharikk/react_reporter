import React, { Component } from 'react';
import { Query } from 'react-apollo';
import gql from 'graphql-tag';

var isGallery = false;

const GET_CATEGORIES = gql`
query Categories($isGallery: Boolean!){
    getCategories(isGallery: $isGallery){
    categoryname
    id
    slug
    isGallery
  }
  }
`;

class CategoryList extends Component {

  render() {

    console.log(this.props);
    isGallery = this.props.gallery;

    return(

        <Query asyncMode  query={GET_CATEGORIES} variables={{ isGallery: isGallery }}>
    
      

     {({ loading, error, data }) => {
          if (loading) return <div><br/></div>
          if (error) return <div>Error Loading Data</div>
      
          return (
            
             <ul className="dropdown-menu"  id="drop-nav" role="menu">
            {data.getCategories.map((category, index) =>


             <li key={index}><a  href={'/category/'+category.slug}>{category.categoryname}</a></li>
          
        


            )}

            </ul>
  
          );
        }}
  </Query>

      );


  }
    
  
}


export default CategoryList;