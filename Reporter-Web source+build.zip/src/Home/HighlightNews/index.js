import React, { Component } from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import {
  MDBCarousel,
  MDBCarouselCaption,
  MDBCarouselInner,
  MDBCarouselItem,
  MDBView
} from "mdbreact";
import Image from "react-graceful-image";
import { Loader } from "../../Loader";
import { slug } from '../../Helpers';
import Cookies from 'js-cookie';

class HighlightNews extends Component {
  render() {
    var section = slug(this.props.section);
    var limit = this.props.limit;
    var color = this.props.color;
     var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }

    const GET_SECTION_NEWS = gql`
  {
    getArticles(language:"${lang}", orderby:"createdDate", sortby:"dsc",limit:${limit}, section:"${section}") {
      articletitle
      article{
      slug
      id
      }
      featuredImage
      category {
        
          categoryname
        
      }
    }
  }
`;

    return (
      <Query query={GET_SECTION_NEWS}>
        {({ loading, error, data }) => {
          if (loading) return <Loader />;
          if (error) return <div>Error Loading Data</div>;

          if (data.getArticles.length === 0) {
            return (
              <div className="no-data">No data to render in {section} section</div>
            );
          }

          return (
            <div className="no-padding panel panel-default">
              <div className={"panel-header " + color }>
                {this.props.title}
                 <a href={'section/'+section}><i className="fas fa-ellipsis-v"></i></a>
              </div>
              <div className="panel-body">
                <div className="inf-container">
                  <HighlightNewsImage
                    articleData={data.getArticles}
                  />
                  <HighlightNewsList articleData={data.getArticles} limit={limit} />
                </div>
              </div>
            </div>
          );
        }}
      </Query>
    );
  }
}

const HighlightNewsList = ({ articleData, limit }) => (
  <ul>
    {articleData.slice(1, limit).map((article, index) => (
      <Link key={index} to={`/article/${article.article.slug}`} >
      <li >
        
          {article.articletitle}
        
      </li>
      </Link>
    ))}
  </ul>
);

class HighlightNewsImage extends Component {
  render() {
   
    return (
      <div className="inf-slider-container">
        <MDBCarousel
          activeItem={1}
          length={1}
          showControls={false}
          showIndicators={false}
          className="z-depth-1"
        >
          <MDBCarouselInner>
            {this.props.articleData.slice(0, 1).map((article, index) => (
              <MDBCarouselItem key={index} itemId={index + 1}>
                <Link to={`/article/${article.article.slug}`}>
                  <MDBView>
                   <Image
        src={article.featuredImage}
        className="content-image-placeholder d-block w-100"
        alt={article.articletitle}
        retry={{ count: -1 }}
      />
                  </MDBView>
                  <MDBCarouselCaption>
                    <p>{article.articletitle}</p>
                  </MDBCarouselCaption>
                </Link>
              </MDBCarouselItem>
            ))}
          </MDBCarouselInner>
        </MDBCarousel>
      </div>
    );
  }
}

export default HighlightNews;
