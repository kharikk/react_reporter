import React from 'react';
import { Query } from 'react-apollo';
import { Link } from "react-router-dom";
import gql from 'graphql-tag';
import  { Loader } from '../../Loader';
import Cookies from 'js-cookie';


var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }

const GET_TOP_STORIES = gql`
{
  
  getArticles(language:"${lang}", orderby:"createdDate", sortby:"dsc",limit:6,section:"top-stories")
  {
    articletitle
    article{
    id
    slug
    }
  }

}
`;



const TopStories = () => (
  
    <Query query={GET_TOP_STORIES}>
    
      

     {({ loading, error, data }) => {
          if (loading) return <Loader />
          if (error) return <div>Error Loading Data</div>
         
        if(data.getArticles.length === 0){

          return <div className="no-data">No data to render in this section</div>
        }
    	
          return (
            <TopStoriesList tplists={data.getArticles} />
          );
        }}
  </Query>
  
);

const TopStoriesList = ({ tplists }) => (
  <ul className="top-stories">
    {tplists.map(article => <Link key={article.articletitle} to={`/article/${article.article.slug}`} className=""><li>{article.articletitle}</li></Link>)}
  </ul>
);

export default TopStories;