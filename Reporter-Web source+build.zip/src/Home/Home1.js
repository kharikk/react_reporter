import React, { Component } from "react";
import TopStories from "./TopStories";
import InFocus from "./InFocus";
import TwitterWidget from "./TwitterWidget";
import PhotoFeature from "./PhotoFeature";
import HighlightNews from "./HighlightNews";
import ThumbnailNews from "./ThumbnailNews";
import { Loader } from "../Loader";
import Header from "../App/Header";
import Footer from "../App/Footer";

class Home1 extends Component {
  render() {
    return (
      <div className="the-alt-body frontend">
        <Header />
        <div className="root-sub-container">
          <section className="sub-container section1">
            <div className="row row-eq">
              <div className="col-md-4">
                <div className="panel panel-default">
                  <div className="panel-header cyan">
                    Top Stories
                    <a href="/section/top stories" className="to-links"><i className="fas fa-ellipsis-v"></i></a>
                  </div>
                  <div className="panel-body">
                    <TopStories />
                  </div>
                </div>
              </div>
              <div className="col-md-4 in-focus">
                <div className="panel panel-default">
                  <div className="panel-header green">
                    In Focus
                    <i className="fas fa-ellipsis-v"></i>
                  </div>
                  <div className="panel-body">
                    <InFocus />
                  </div>
                </div>
              </div>
              <div className="col-md-4 twitter-container">
                <HighlightNews
                  section="Top Stories"
                  limit={6}
                  color="pclay"
                />
              </div>
            </div>
          </section>
          <section className="sub-container section2">
            <div className="row row-eq">
              <div className="col-md-4">
              
                
                  <HighlightNews
                  section="Photo Feature"
                  limit={6}
                  color="red"
                />
              
              </div>
              <div className="col-md-4 panel-block nest-blocks">
               
       
                   <ThumbnailNews title="Most Popular" section="Most Popular" color="blue" limit={2} />
                   <ThumbnailNews title="Tv & Movies" section="Tv & Movies" color="info" limit={2} />
                
                </div>
              
              <div className="col-md-4">
              <div className="panel panel-default">
                <div className="panel-header pink">
                  Photos / Videos
                  <i className="fas fa-ellipsis-v"></i>
                </div>
                <div className="panel-body">
                  <Loader />
                </div>
                </div>
              </div>
            </div>
          </section>
          <section className="sub-container section3">
            <div className="row row-eq">
              <div className="col-md-4 mt7">
                <HighlightNews
                  section="Business & Technology"
                  limit={6}
                  color="mpurple"
                />
              </div>

              <div className="col-md-4 mt7">
                <HighlightNews
                  section="Around the World"
                  limit={6}
                  color="sushi"
                />
              </div>
              <div className="col-md-4 mt7">
                <HighlightNews
                  section="Astrology"
                  limit={6}
                  color="gold-drop"
                />
              </div>
            </div>
          </section>
          <section className="sub-container section4">
            <div className="row">
              <div className="col-md-4 mt7">
                <HighlightNews
                  section="Health & Lifestyle"
                  limit={6}
                  color="pclay"
                />
              </div>

              <div className="col-md-4 mt7">
                <HighlightNews
                  section="Travel & Religious"
                  limit={6}
                  color="matrix"
                />
              </div>

              <div className="col-md-4 mt7">
                <div className="ad-container ad-home">
                  <img
                    className="img-fluid w-100" 
src="https://via.placeholder.com/400x330"
                    alt="Ad banner"
                  />
                </div>
              </div>
            </div>
          </section>
        </div>
        <Footer />
      </div>
    );
  }
}
export default Home1;
