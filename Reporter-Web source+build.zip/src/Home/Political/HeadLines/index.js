import React, { Component } from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import {
  MDBCarousel,
  MDBCarouselCaption,
  MDBCarouselInner,
  MDBCarouselItem,
  MDBView,
  MDBContainer
} from "mdbreact";
import  { Loader } from '../../../Loader';
import Cookies from 'js-cookie';


var limit = 9;
 var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }


const GET_INFOCUS_STORIES = gql`
 {
  
 
  
  getArticles(language:"${lang}"){
    
    articletitle
    article{
    id
    slug
    }
    featuredImage
  }


}
`;



class HeadLines extends Component {


render() {




  return(

    <Query query={GET_INFOCUS_STORIES}>
    {({ loading, error, data }) => {
      if (loading) return <Loader />;
      if (error) return <div>Error Loading Data</div>;
      if(data.getArticles.length === 0){

          return <div className="no-data">No data to render in this section</div>
        }

      return (
         <div className="panel panel-default">
                  <div className={'panel-header '+ this.props.color}>
                    {this.props.title}
                    <i className="fas fa-ellipsis-v"></i>
                  </div>
                  <div className="panel-body">
                   <div className="row row-eq no-margin">
                   <div className="col-md-8 no-padding">
                    <HeadLinesSlider sldierlists={data.getArticles} />
                   </div>
                   <div className="col-md-4 bl no-padding">
                       <HeadLinesList hllists={data.getArticles} />
                   </div>
                   
                  
                     </div>
                  </div>
                </div>
          

        
        
      );
    }}
  </Query>



    );
}

  
}

const HeadLinesList = ({ hllists }) => (
  <ul>
    {hllists.slice(3,9).map((article, index) => (
      <li key={article.articletitle}>
        <Link to={`/article/${article.slug}`} className="">
          {article.articletitle}
        </Link>
      </li>
    ))}
  </ul>
);

class HeadLinesSlider extends React.Component {
  render() {
  
    return (
      <div className="pol-slider-hl">
      
          <MDBCarousel
            activeItem={1}
            length={2}
            showControls={true}
            showIndicators={false}
            className="z-depth-1"
          >
            <MDBCarouselInner>
              {this.props.sldierlists.slice(0,3).map((article, index) => (
                <MDBCarouselItem key={index} itemId={index + 1}>
                <Link to={`/article/${article.slug}`}>
                  <MDBView>
                    <img
                      className="d-block w-100"
                      src={article.featuredImage}
                      alt={index}
                    />
                  </MDBView>
                  <MDBCarouselCaption>
                    <p>{article.articletitle}</p>
                  </MDBCarouselCaption>
                
                  </Link>
                </MDBCarouselItem>
              ))}
            </MDBCarouselInner>
          </MDBCarousel>
      
      </div>
    );
  }
}

export default HeadLines;
