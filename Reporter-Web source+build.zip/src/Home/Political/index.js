import React, { Component } from "react";
import ThumbnailNews from "../ThumbnailNews";
import HeadLines from "./HeadLines";
import ColumnNews from "../ColumnNews";
import HighlightNews from "../HighlightNews";
import Sidebar from "../../Sidebar";
import Header from "../../App/Header";
import Footer from "../../App/Footer";
import Trending from "../Trending";
import strings from '../../Locale';

class PoliticalNews extends Component {
  render() {
    return (
      <div className="the-body frontend">
        <Header />

        <section className="sub-container political-page">
          <div className="row">
            <div className="col-md-12 col-lg-8">
              <div className="d-flex">
                <div className="col-md-12 no-padding">
                  <HeadLines title={strings.headlines} color="green" />
                </div>
              </div>
              <div className="row d-flex mt7 d2">
                <div className="col-md-6">
                  <ThumbnailNews
                    title="Andhra News"
                    color="red"
                    subcategory="Andhra Pradesh"
                    limit={5}
                  />
                </div>
                <div className="col-md-6">
                  <ThumbnailNews
                    title="Telengana News"
                    color="blue"
                    subcategory="Telangana"
                    limit={5}
                  />
                </div>
              </div>

              <div className="d-flex mt7">
                <div className="col-md-12 no-padding">
                  <ColumnNews title={strings.nationalnews} color="matrix" />
                </div>
              </div>

              <div className="d-flex mt7">
                <div className="col-md-12 no-padding">
                  <ColumnNews title={strings.internationalnews} color="pclay" />
                </div>
              </div>
            </div>
            <div className="col-md-12 col-lg-4">
             
                <div className="ad-holder">
                  <img className="img-fluid w-100" 
src="https://via.placeholder.com/500x550" alt="asd" />
                </div>

                <div className="d-flex mt14">
                  {/* <ThumbnailNews
                    title="Related Articles"
                    section="Top Stories"
                    limit={4}
                    color="pink"
                  /> */}
                  <Trending
                  title={strings.trending}
                  limit ={4}
                  color ="pink"
                  />
                </div>
                <div className="ad-holder mt14">
                  <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x100" alt="asd" />
                </div>

                <div className="d-flex mt14 w-100">
                <HighlightNews
                    section="Astrology"
                    limit={6}
                    color="gold-drop"
                    title={strings.astrology}
                  />
                </div>
                <div className="d-flex mt14 w-100">
                <ThumbnailNews
                    title={strings.recommendedforyou}
                    section="Most Popular"
                    limit={6}
                    color="pink"
                  />
                        </div>
                <div className="ad-holder mt14 w-100">
                   <img className="img-fluid w-100" 
src="https://via.placeholder.com/400x250" alt="asd" />
                   </div>
               
                
                  
            
               
              </div>
            </div>
        
        </section>

        <Footer />
      </div>
    );
  }
}
export default PoliticalNews;
