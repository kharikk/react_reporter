import React from "react";
import { Query } from "react-apollo";
import { Link } from "react-router-dom";
import gql from "graphql-tag";
import {
  MDBCarousel,
  MDBCarouselCaption,
  MDBCarouselInner,
  MDBCarouselItem,
  MDBView,
  MDBContainer
} from "mdbreact";
import Image from "react-graceful-image";
import  { Loader } from '../../Loader';
import Cookies from 'js-cookie';


var limit = 6;
 var lang = Cookies.get('language');
    if(!Cookies.get('language')){

      lang = 'english';
    }

const GET_INFOCUS_STORIES = gql`
 {
  
  getArticles(language:"${lang}", orderby:"createdDate", sortby:"dsc",limit:${limit},section:"in-focus")
  {
    articletitle
    article{
    id
    slug
    }
    featuredImage
    category{

      categoryname
    }
  }

}
`;

const InFocus = () => (
  <Query query={GET_INFOCUS_STORIES}>
    {({ loading, error, data }) => {
      if (loading) return <Loader />;
      if (error) return <div>Error Loading Data</div>;
      if(data.getArticles.length === 0){

          return <div className="no-data">No data to render in this section</div>
        }

      return (
        <div className="inf-container">
          <InFocusSlider sldierlists={data.getArticles} />

          <InFocusList iflists={data.getArticles} />
        </div>
      );
    }}
  </Query>
);

const InFocusList = ({ iflists }) => (
  <ul>
    {iflists.slice(1,3).map((article, index) => (
      <li key={article.articletitle}>
        <Link to={`/article/${article.article.slug}`} className="">
          {article.articletitle}
        </Link>
      </li>
    ))}
  </ul>
);

class InFocusSlider extends React.Component {
  render() {
  
    return (
      <div className="inf-slider-container">
       
          <MDBCarousel
            activeItem={1}
            length={3}
            showControls={true}
            showIndicators={false}
            className="z-depth-1"
          >
            <MDBCarouselInner>
              {this.props.sldierlists.slice(0,1).map((article, index) => (
                <MDBCarouselItem key={index} itemId={index + 1}>
                <Link to={`/article/${article.article.slug}`}>
                  <MDBView>
                   <Image
        src={article.featuredImage}
        className="content-image-placeholder d-block w-100"
        alt={article.articletitle}
        retry={{ count: -1 }}
      />
                  </MDBView>
                  <MDBCarouselCaption>
                    <p>{article.articletitle}</p>
                  </MDBCarouselCaption>
                  <MDBCarouselCaption>
                    <p className="category-tag">
                      {article.category.categoryname}
                    </p>
                  </MDBCarouselCaption>
                  </Link>
                </MDBCarouselItem>
              ))}
            </MDBCarouselInner>
          </MDBCarousel>
       
      </div>
    );
  }
}

export default InFocus;
