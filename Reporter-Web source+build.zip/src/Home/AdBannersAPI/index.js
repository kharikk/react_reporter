import React, { Component } from 'react';
import { Query } from 'react-apollo';
import gql from 'graphql-tag';


const GET_AD_BANNER = gql`

query getAd($adsLocation: String){
  ads(adsLocation: $adsLocation){
    image
    location
  }
 }

`;

class AdBanner extends Component {

  render() {

    return(

        <Query asyncMode  query={GET_AD_BANNER} variables={{ adsLocation: this.props.position }}>
    
      

     {({ loading, error, data }) => {
          if (loading) return <div><br/></div>
          if (error) return <div>Error Loading Data</div>
          
      
          return (
            
            <img src={data.ads[0].image} alt="asd" />
          
  
          );
        }}
  </Query>

      );


  }
    
  
}


export default AdBanner;