import React from 'react';
import pageloader from './page-loader.svg'; 
import placeholderimage from './placeholder.gif'; 


export const PageLoader = () => (
	
		<div className="page-loader">
                  <img src={pageloader} alt="Loading" />
            </div>


);


export const PlaceholderImage = () => (

    <img src={placeholderimage} alt="Placeholder Image"/>
 
)