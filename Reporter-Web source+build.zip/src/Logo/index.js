import React from 'react';
import logo1 from  './logo.png'

export const Logo = () => (

    <img src="https://s3.us-east-2.amazonaws.com/totaltelugu/Logo.jpg" alt="TotalTelugu Logo"/>
 
)

export const DashLogo = () => (

    <img src={logo1} alt="Dash Logo"/>
 
)