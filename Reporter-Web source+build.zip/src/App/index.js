import React, { Component } from "react";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect
} from "react-router-dom";
import { createBrowserHistory } from "history";
import  Page404  from './Page404';
import Home from "../Home";
import Home1 from "../Home/Home1";
import PoliticalNews from "../Home/Political";
import SearchArticles from "../Home/Search";
import MiscPage from "../Home/Misc";
import Article from "../Article";
import Dashboard from "../Dashboard";
import StatusArticles from "../Dashboard/statusArticles";
import CreateArticle from "../Dashboard/Article";
import ViewArticle from "../Dashboard/viewArticle";
import CreateMoviewReview from "../Dashboard/Article/createReview";
import CreateGallery from "../Dashboard/Article/createGallery";
import EditMovieReview from "../Dashboard/Article/editReview";
import EditArticle from "../Dashboard/Article/editArticle";
import EditGallery from "../Dashboard/Article/editGallery";
import Register from "../Dashboard/user/Register";
import Login from "../Dashboard/user/Login";
import ForgotPassword from "../Dashboard/user/ForgotPassword";
import Profile from "../Dashboard/user/Profile";
import SearchArticlesDashboard from "../Dashboard/SearchArticles";
import EditProfile from "../Dashboard/user/Profile/edit";
import SingleMovieReview from "../Home/MovieReviews/single";
import MovieNewsLanding from "../Home/MovieReviews";
import Gallery from "../Home/Gallery";
import CategoryNews from "../Home/Category";
import SectionNews from "../Home/Section";
import TagNews from "../Home/TagNews";
import UsersList from "../Dashboard/user/List";
import UserProfile from "../Dashboard/user/List/profile";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import "../main.css";

const history = createBrowserHistory();

if(!window.localStorage.getItem('language')){

window.localStorage.setItem('language', 'en');

}


toast.configure({
  position: "top-right",
  autoClose: 5000,
  hideProgressBar: false,
  closeOnClick: true,
  pauseOnHover: true,
  draggable: true
});

const checkAuth = () => {
  const token = localStorage.getItem("token");
  const refreshToken = localStorage.getItem("token"); 
  console.log("token " + token);
  if (!token || !refreshToken || token === 'undefined' ) {
    console.log("token " + token);
    return false;
  }

  try {
    // { exp: 12903819203 }
    // const { exp } = decode(refreshToken);
    // if (exp < new Date().getTime() / 1000) {
    //   return false;
    // }
  } catch (e) {
    return false;
  }

  return true;
};

const AuthRoute = ({ component: Component, ...rest }) => (

  <Route
    {...rest}
    render={props =>
      checkAuth() ? (
        <Component {...props} />
      ) : (
        <Redirect to={{ pathname: "/login" }} />
      )
    }
  />
);

const LoginAuth = ({ component: Component, ...rest }) => (
  <Route
    {...rest}
    render={props =>
      checkAuth() ? (
        <Redirect to={{ pathname: "/dashboard" }} />
      ) : (
        <Component {...props} />
      )
    }
  />
);

class Logout extends React.Component {
  render() {
    window.localStorage.clear();
    window.location.href = "/login";

    return <p></p>;
  }
}

class App extends Component {

  constructor(){

    super();

    this.state = {

      lang: window.localStorage.getItem('language')

    }


  }

  componentDidMount() {

    

  }


 
  render() {
    
  return (
      <Router history={history}>
        <ToastContainer />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/Home1" component={Home1} />
          <Route path="/politics" component={PoliticalNews} />
          <Route exact path="/article/:slug" component={Article} />
          <Route path="/register" component={Register} />
          <Route path="/reset-password" component={ForgotPassword} />
          <Route exact path="/review/:slug" component={SingleMovieReview} />
          <Route exact path="/reviews" component={MovieNewsLanding} />
          <Route path="/category/:cname" component={CategoryNews} />
          <Route path="/section/:section" component={SectionNews} />
          <Route path="/tag/:tag" component={TagNews} />
          <Route exact path="/gallery" component={Gallery} />
          <Route path="/search/:search" component={SearchArticles} />
          <Route path="/misc/" component={MiscPage} />



          <AuthRoute exact path="/dashboard" component={Dashboard} />
          <AuthRoute exact path="/dashboard/search" component={SearchArticlesDashboard} />
          <AuthRoute path="/dashboard/:status" component={StatusArticles} />
          <AuthRoute exact path="/add/article" component={CreateArticle} />
          <AuthRoute exact path="/add/review" component={CreateMoviewReview} />
          <AuthRoute exact path="/add/gallery" component={CreateGallery} />
          <AuthRoute exact path="/edit/article/:id" component={EditArticle} />
          <AuthRoute exact path="/edit/gallery/:id" component={EditGallery} />
          <AuthRoute
            exact
            path="/edit/review/:id"
            component={EditMovieReview}
          />
          <AuthRoute exact path="/view/:id" component={ViewArticle} />
          <LoginAuth path="/login" component={Login} />
          <AuthRoute exact path="/logout" component={Logout} />
          <AuthRoute exact path="/profile" component={Profile} />
           <AuthRoute exact path="/profile/edit/:id" component={EditProfile} />
          <AuthRoute exact path="/profile/:userType/:userSlug" component={UserProfile} />
         

          <AuthRoute
            path="/reporters"
            component={() => <UsersList list="Reporter" />}
          />
          <AuthRoute
            path="/editors"
            component={() => <UsersList list="Content Editor" />}
          />
          <Route component={Page404} />
        </Switch>
      </Router>
    );


    
  }
}

export default App;
