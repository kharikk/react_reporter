import React, { Component } from 'react';
import { Logo } from "../Logo";
import moment from "moment";






export default class Page404 extends Component {
  constructor(){

    super();


    var timeleft = 10;
var downloadTimer = setInterval(function(){
  if(document.getElementById("landing-page-timer")){
    document.getElementById("landing-page-timer").innerText =  timeleft;

  }

  timeleft -= 1;
  if(timeleft <= 0)
    clearInterval(downloadTimer);
}, 1000);
  
this.handleClick=this.handleClick.bind(this);
  }


  handleClick =()=> {
    
   
      this.props.onChange(false);


    // 1000ms = 1 second


}
  componentDidMount() {
  
  }

  
  render(){

  return(

  <section className="common-header">
        <div className="row logo-banner">
          <div className="col-md-3">
            <div className="logo-container">
              <Logo />
            </div>
            <div className="date-container">{moment().format("dddd, LL")}</div>
          </div>
          <div className="col-md-9">
            <span className="header-ad-holder">
              <img
                src="https://via.placeholder.com/1920x200"
                alt="Advertisement"
              />
            </span>
          </div>
        </div>

        <span className="link-to-main">
          <a href="#" onClick={this.handleClick} >click here to go to main page</a>
          <p> or else you will be directed to main page in <span id="landing-page-timer">10</span> seconds</p>

        </span>
        <div className="row nav-row">
          <div className="col-md-6 landing-page-poster">
              <img src="https://timesofindia.indiatimes.com/thumb/msid-69822180,imgsize-131114,width-800,height-600,resizemode-4/69822180.jpg" alt="" />
          </div>
        
        {/* <div className="row nav-row"> */}
          <div className="col-md-6 landing-page-poster1">
              <img src="https://cdn.thelivemirror.com/wp-content/uploads/2019/08/Rakshasudu-Full-HD-Movie-Leaked.jpg" alt="" />
          </div>
          </div>
        {/* </div> */}
       
       
      </section>

  );
  }
}