import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Logo } from "../../Logo";
import moment from "moment";
import BreakingNews from "../../Home/BreakingNews";
import CategoryList from "../../Home/Category/getCategories";
import { string } from "prop-types";
import strings from "../../Locale";
import Cookies from "js-cookie";
import LocalizedStrings from 'react-localization';

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {
      search: "",
      language: "english"
    };

    if(Cookies.get('language')){
        strings.setLanguage(Cookies.get('language'));
    
    }

    this.submitSearchForm = this.submitSearchForm.bind(this);
    this.handleSearchChange = this.handleSearchChange.bind(this);
    this.expandSearch = this.expandSearch.bind(this);
    this.handleLanguage = this.handleLanguage.bind(this);
  }

  componentDidMount() {
      console.log(strings.getLanguage());
    if(Cookies.get('language')){

      this.setState({
          language: Cookies.get('language')

      }, () => {
        //  console.log(this.state.language)
        strings.setLanguage(Cookies.get('language'));
      })
    }
  }

  submitSearchForm = event => {
    event.preventDefault();

    let url = "/search/" + this.state.search;
    window.location = url;
  };

  handleSearchChange = e => {
    this.setState({ search: e.target.value });
  };

  expandSearch = () => {
    var element = document.getElementById("exp-search");
    element.classList.toggle("expanded");
  };

  handleLanguage = e => {

    

let lang = e.target.value;
    this.setState({
       language: lang
    }, () => {

    Cookies.set('language', lang);
    strings.setLanguage(lang);
    window.location.reload();
    })
    


    //window.localStorage.setItem('language','telugu');
    
  };
  render() {
    return (
      <section className="common-header">
        <div className="row logo-banner">
          <div className="col-md-3">
            <div className="logo-container">
              <Logo />
            </div>
            <div className="date-container">{moment().format("dddd, LL")}</div>
          </div>
          <div className="col-md-9">
            <span className="header-ad-holder">
              <img
                className="img-fluid w-100"
                src="https://via.placeholder.com/1920x200"
                alt="Advertisement"
              />
            </span>
          </div>
        </div>
        <div className="row nav-row">
          <div className="col-md-12">
            <nav className="custom-navbar navbar navbar-expand-sm navbar-light">
              <button
                className="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarTogglerDemo03"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div
                className="collapse navbar-collapse "
                id="navbarTogglerDemo03"
              >
                <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
                  <li className="nav-item">
                    <Link to={"/"} className="nav-link">
                      {" "}
                      <i className="fa fa-home" aria-hidden="true"></i>{" "}
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to={"/category/movies"} className="nav-link">
                      {strings.movies}
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to={"/politics"} className="nav-link">
                      {strings.politics}
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to={"/gallery"} className="nav-link">
                      {strings.gallery}
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to={"/reviews"} className="nav-link">
                      {strings.moviereviews}
                    </Link>
                  </li>
                  <li className="dropdown nav-item cat-drop">
                    <a
                      href="#"
                      className="dropdown-toggle nav-link"
                      data-toggle="dropdown"
                    >
                      {strings.more}
                      <span className="caret"></span>
                    </a>

                    <CategoryList gallery={false} />
                  </li>
                </ul>
                <div className="header-rightbar">
                  <select name="select" class="lang-select" onChange={this.handleLanguage} value={this.state.language}>
                    <option value="english">English</option>
                     <option value="telugu">తెలుగు</option>
                  </select>
                  <a href="">
                    <i className="fa fa-share-alt" aria-hidden="true"></i>
                  </a>
                  <div className="search-container" id="exp-search">
                    <form onSubmit={this.submitSearchForm}>
                      <input
                        type="text"
                        name="search"
                        value={this.state.search}
                        className="search-input"
                        onChange={this.handleSearchChange}
                      />
                      <i
                        className="fa fa-search"
                        aria-hidden="true"
                        onClick={this.expandSearch}
                      ></i>
                    </form>
                  </div>
                </div>
              </div>
            </nav>
          </div>
        </div>
        <div className="row breaking-news-container">
          <div className="col-md-2 col-sm-12 text-center">
            <span className="container-title">
              <span>{strings.breakingnews} </span>
            </span>
          </div>
          <div className="col-md-10 col-sm-12">
            <BreakingNews />
          </div>
        </div>
        <div className="row ad-row">
          <div className="col-md-4">
            <div className="ad-banner-holder">
              <img
                className="img-fluid w-100"
                className="img-fluid w-100"
                src="https://via.placeholder.com/400x100"
                alt="ad1"
              />
            </div>
          </div>

          <div className="col-md-4">
            <div className="ad-banner-holder">
              <img
                className="img-fluid w-100"
                className="img-fluid w-100"
                src="https://via.placeholder.com/400x100"
                alt="ad2"
              />
            </div>
          </div>
          <div className="col-md-4">
            <div className="ad-banner-holder">
              <img
                className="img-fluid w-100"
                className="img-fluid w-100"
                src="https://via.placeholder.com/400x100"
                alt="ad3"
              />
            </div>
          </div>
        </div>
      </section>
    );
  }
}

export default Header;
