import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Logo } from "../../Logo";
import moment from "moment";

//footer component in every page where we let the end user to join our community 
class Footer extends Component {
  render() {
    return (
      <div className="footer">
        <div className="row footer-section-1">
          <div className="col-md-4 br-white pt10">
            <span className="j-text">Join the community</span>
            <span className="footer-social">
              <i className="fab fa-facebook-f"></i>
              <i className="fab fa-twitter"></i>
              <i className="fab fa-youtube"></i>
            </span>
          </div>
          <div className="col-md-8 pl40">
            <div className="row row-eq">
              <div className="col-md-4 pl20">
                <div className="mail-text">
                  Join our mailing list for exclusive updates and tips
                </div>
              </div>
              <div className="col-md-8">
                <div className="mailing-form">
                  <input
                    type="email"
                    className="mailing-email"
                    placeholder="Enter Email"
                  />
                  <button
                    type="submit"
                    className="btn btn-custom-submit"
                    value="Submit"
                  >
                    <i className="fa fa-chevron-right" aria-hidden="true"></i>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="row footer-section-2">
          <div className="col">
            <ul className="footer-links">
              <li>
                <a href="/misc/">About Us </a>
              </li>
              <li>
                <a href="/misc/">Privacy Policy </a>
              </li>
              <li>
                <a href="/misc/">Disclaimer </a>
              </li>
              <li>
                <a href="/misc/">Contact Us </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="row footer-section-2-copyright">
          <div className="col">
            <span>&copy; TotalTelugu </span>
          </div>
        </div>
      </div>
    );
  }
}

export default Footer;
